#!/bin/sh

/localhome/rnouacer/TestMATLAB/cosim_lib/bin/unisim-loader /localhome/rnouacer/TestMATLAB/cosim_lib/lib/libunisim-star12x-simulator-1.0.so -c bench_conf.xml


