#!/bin/sh

/localhome/rnouacer/TestMATLAB/cosim_lib/bin/unisim-loader /localhome/rnouacer/TestMATLAB/bench001/Test_Case1.xml


