
#include <unisim/service/monitor/monitor.hh>
#include <unisim/service/monitor/monitor.tcc>

namespace unisim {
namespace service {
namespace monitor {

template class Monitor<uint32_t>;
template class Monitor<uint64_t>;

} // end of namespace monitor
} // end of namespace service
} // end of namespace unisim

