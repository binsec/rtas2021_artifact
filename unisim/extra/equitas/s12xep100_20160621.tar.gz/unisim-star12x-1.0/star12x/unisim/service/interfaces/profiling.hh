/*
 *  Copyright (c) 2012,
 *  Commissariat a l'Energie Atomique (CEA)
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *   - Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   - Neither the name of CEA nor the names of its contributors may be used to
 *     endorse or promote products derived from this software without specific prior
 *     written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.
 *  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 *  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 *  OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Gilles Mouchard (gilles.mouchard@cea.fr)
 */
 
#ifndef __UNISIM_SERVICE_INTERFACES_PROFILING_HH__
#define __UNISIM_SERVICE_INTERFACES_PROFILING_HH__

#include <unisim/kernel/service/service.hh>
#include <unisim/util/debug/profile.hh>

namespace unisim {
namespace service {
namespace interfaces {

template <class ADDRESS>
class Profiling : public unisim::kernel::service::ServiceInterface
{
public:
	typedef enum
	{
		OPT_MIN_PROF_ADDR,
		OPT_MAX_PROF_ADDR,
		OPT_ENABLE_PROF
	} Option;
	
	typedef enum
	{
		PROF_DATA_READ = 0,
		PROF_DATA_WRITE = 1,
		PROF_INSN_FETCH = 2,
		PROF_INSN_EXEC = 3,
		NUM_PROFILE_TYPES
	} ProfileType;

	virtual void SetProfileOption(ProfileType prof_type, Option opt, bool flag) = 0;
	virtual void SetProfileOption(ProfileType prof_type, Option opt, ADDRESS addr) = 0;
	virtual void GetProfileOption(ProfileType prof_type, Option opt, bool& flag) const = 0;
	virtual void GetProfileOption(ProfileType prof_type, Option opt, ADDRESS& addr) const = 0;
	virtual void ClearProfile(ProfileType prof_type) = 0;
	virtual const unisim::util::debug::Profile<ADDRESS>& GetProfile(ProfileType prof_type) const = 0;
};

} // end of namespace interfaces
} // end of namespace service
} // end of namespace unisim

#endif
