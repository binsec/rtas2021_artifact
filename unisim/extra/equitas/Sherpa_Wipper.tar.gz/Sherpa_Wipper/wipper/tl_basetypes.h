/**************************************************************************************************\
 *** 
 *** Simulink model       : WiperControl_Sherpa4CodeGeneration_R2009b
 *** TargetLink subsystem : WiperControl_Sherpa4CodeGeneration_R2009b/WiperControl_Sherpa
 *** Codefile             : tl_basetypes.h
 ***
 *** Generation date: 2016-07-01 15:28:45
 ***
 *** TargetLink version      : 3.1 from 01-Dec-2009
 *** Code generator version  : Build Id 3.1.0.19 from 2009-11-12 13:31:41
 *** Copyright (c) 2009 dSPACE GmbH
\**************************************************************************************************/

#ifndef _TL_BASETYPES_H_
#define _TL_BASETYPES_H_

typedef unsigned char Bool; /* boolean basetype */
typedef float Float32; /* 32 bit floating-point basetype */
typedef double Float64; /* 64 bit floating-point basetype */
typedef signed short int Int16; /* 16 bit signed integer basetype */
typedef signed long int Int32; /* 32 bit signed integer basetype */
typedef signed char Int8; /* 8 bit signed integer basetype */
typedef unsigned short int UInt16; /* 16 bit unsigned integer basetype */
typedef unsigned long int UInt32; /* 32 bit unsigned integer basetype */
typedef unsigned char UInt8; /* 8 bit unsigned integer basetype */
typedef void Void; /* void basetype */

#endif/*_TL_BASETYPES_H_ */
