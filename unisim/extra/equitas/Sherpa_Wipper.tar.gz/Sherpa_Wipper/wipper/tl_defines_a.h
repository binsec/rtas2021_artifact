/**************************************************************************************************\
 *** 
 *** Simulink model       : WiperControl_Sherpa4CodeGeneration_R2009b
 *** TargetLink subsystem : WiperControl_Sherpa4CodeGeneration_R2009b/WiperControl_Sherpa
 *** Codefile             : tl_defines_a.h
 ***
 *** Generation date: 2016-07-01 15:28:45
 ***
 *** TargetLink version      : 3.1 from 01-Dec-2009
 *** Code generator version  : Build Id 3.1.0.19 from 2009-11-12 13:31:41
 *** Copyright (c) 2009 dSPACE GmbH
\**************************************************************************************************/

#ifndef _TL_DEFINES_A_H_
#define _TL_DEFINES_A_H_

#ifdef TL_FRAME
#include "WiperControl_Sherpa_frm.h"
#endif

/******************************************************************************\
   TL_CG_MACROCL_GLOBAL: Default macro class for macros with module extent
\******************************************************************************/
#ifndef TL_FX_GROUND
#define TL_FX_GROUND 0
#endif /* TL_FX_GROUND */


/******************************************************************************\
   TL_CG_MACROCL_GLOBAL: Default macro class for macros with module extent
\******************************************************************************/
#define MERGEABLE_GLOBAL 


#endif/*_TL_DEFINES_A_H_ */
