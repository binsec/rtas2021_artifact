/**************************************************************************************************\
 *** 
 *** Simulink model       : WiperControl_Sherpa4CodeGeneration_R2009b
 *** TargetLink subsystem : WiperControl_Sherpa4CodeGeneration_R2009b/WiperControl_Sherpa
 *** Codefile             : tl_types.h
 ***
 *** Generation date: 2016-07-01 15:28:45
 ***
 *** TargetLink version      : 3.1 from 01-Dec-2009
 *** Code generator version  : Build Id 3.1.0.19 from 2009-11-12 13:31:41
 *** Copyright (c) 2009 dSPACE GmbH
\**************************************************************************************************/

#ifndef _TL_TYPES_H_
#define _TL_TYPES_H_

#include "tl_basetypes.h"

#endif/*_TL_TYPES_H_ */
