#include <hcs12xdp512.h>
//#include <dbug12.h>

#include <WiperControlSherpa.h>

#define TRUE 1
#define FALSE 0

/****************************************RTI STARTS******************************/
/**
 * here are the methods and variables for real-time-interrupt
 */


/**
 * when a real-time interrupt happens, HC12 will go through this method
 */
void INTERRUPT rti_isr( void );
void INTERRUPT rti_isr( void )
{
  //clear the RTI - don't block the other interrupts
  CRGFLG = 0x80;

  Sa1_WiperControl_Sherpa();

}

/**
 * initilize the rti: rti_ctl_value will set the prescaler ...
 */
void rti_init(unsigned char rti_ctl_value);
void rti_init(unsigned char rti_ctl_value)
{
  UserRTI = (unsigned int) & rti_isr; //register the ISR unit

  /**
   * RTICTL can be calculated like:
   * i.e: RTICTL == 0x63 == set rate to 32.768ms:
   * The clock divider is set in register RTICTL and is: (N+1)*2^(M+9), 
   * where N is the bit field RTR3 through RTR0 
   * and M is the bit field RTR6 through RTR4. 
   * 0110 0011 = 0x63 ==> 1 / (4MHz / 4*2^15) == 4*2^15 / 4,000 = 32.768ms
   * 0111 1111 = 0x7F ==> 1 / (4MHz / 16*2^16) == 2^20  / 4,000 = 262.144ms
   */
  RTICTL = rti_ctl_value;

  // Enable RTI interrupts
  CRGINT |= 0x80;
  // Clear RTI Flag
  CRGFLG = 0x80;
}
/**************************************RTI DONE***********************************/

int main(void)
{

//  rti_init(0x11); // 256 us at 8MHZ
//  rti_init(0x63);   // 16384 us at 8MHZ
//	rti_init(0x53);  // 8192 us at 8MHZ

//	rti_init(0x54); // 10240 us at 8MHZ

//	rti_init(0x48); // 9216 us at 8MHZ

//	rti_init(0x49); // 10240 us at 8MHZ

	rti_init(0x39); // 10240 us at 4MHZ

  for (;;);

}


