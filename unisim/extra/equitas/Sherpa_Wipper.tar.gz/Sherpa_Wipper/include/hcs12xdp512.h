#ifndef HCS12_IO_H
#define HCS12_IO_H

/* *************************************************************************/
/* This file contains the address definitions for all peripheral registers */
/* and most of the bits of status registers and control registers.         */
/* Author: Dr. Han-Way Huang                                               */
/* Date: July 1, 2004                                                      */
/* 			                                                   */
/* Modified by Navid Mohaghegh (MC9S912DP256 - 2006/12/13)		   */
/***************************************************************************/

//define "byte" and "word"
#ifndef byte
typedef unsigned char byte;
#endif
#ifndef word
typedef unsigned int word;
#endif


#define     IOREGS_BASE  0x0000

#define     _IO8(off)    *(unsigned char  volatile *)(IOREGS_BASE + off)
#define     _IO16(off)   *(unsigned short volatile *)(IOREGS_BASE + off)

#define     PORTA        _IO8(0x00)     //port a = address lines a8 - a15
#define     PORTB        _IO8(0x01)     //port b = address lines a0 - a7
#define     DDRA         _IO8(0x02)     //port a direction register
#define     DDRB         _IO8(0x03)     //port a direction register

#define     PORTC        _IO8(0x04)
#define     PORTD        _IO8(0x05)
#define     DDRC         _IO8(0x06)
#define     DDRD         _IO8(0x07)

#define     PORTE        _IO8(0x08)     //port e = mode,irqandcontrolsignals
#define     DDRE         _IO8(0x09)     //port e direction register
//#define     PEAR         _IO8(0x0A)     //port e assignments
#define     MMCCTL0      _IO8(0x0A)     //mmc control register 0
#define     MODE         _IO8(0x0B)     //mode register
#define     PUCR         _IO8(0x0C)     //port pull-up control register
#define     RDRIV        _IO8(0x0D)     //port reduced drive control register
#define     EBICTL0       _IO8(0x0E)     //External Bus Interface control Register 0
#define     EBICTL1       _IO8(0x0F)     //External Bus control Register 1
#define     GPAGE         _IO8(0x10)     //Global Page Index Register
#define     DIRECT        _IO8(0x11)     //Direct Page Register
#define     MMCCTL1       _IO8(0x13)     //MMC Control Register 1
#define     RPAGE         _IO8(0x16)     //RAM Page Index Register
#define     EPAGE         _IO8(0x17)     //EEPROM Page Index Register
#define     PARTIDH       _IO8(0x1A)     //Part ID High Register
#define     PARTIDL       _IO8(0x1B)     //Part ID Low Register
#define     ECLKCTL       _IO8(0x1C)     //ECLK Control Register
#define     IRQCR         _IO8(0x1E)     //Part ID Register
#define     DBGC1         _IO8(0x20)     //Debug Control Register
#define     DBGSR         _IO8(0x21)     //Debug Status Register
#define     DBGTCR        _IO8(0x22)     //Debug Trace Control Register
#define     DBGC2         _IO8(0x23)     //Debug Control Register 2
#define     DBGTBH        _IO8(0x24)     //Debug Trace Buffer Register High
#define     DBGTBL        _IO8(0x25)     //Debug Trace Buffer Register Low
#define     DBGCNT        _IO8(0x26)     //Debug Count Register
#define     DBGSCRX       _IO8(0x27)     //Debug State Control Register 0
#define     DBGXCTL       _IO8(0x28)     //Debug Comparator Control Register
#define     DBGXAH        _IO8(0x29)     //Debug Comparator Address High Register
#define     DBGXAM        _IO8(0x2A)     //Debug Comparator Address Mid Register
#define     DBGXAL        _IO8(0x2B)     //Debug Comparator Address Low Register
#define     DBGXDH        _IO8(0x2C)     //Debug Comparator Data High Register
#define     DBGXDL        _IO8(0x2D)     //Debug Comparator Data Low Register
#define     DBGXDHM       _IO8(0x2E)     //Debug Comparator Data High Mask Register
#define     DBGXDLM       _IO8(0x2F)     //Debug Comparator Data Low Mask Register

//#define     INITRM       _IO8(0x10)     //ram location register
//#define     INITRG       _IO8(0x11)     //register location register
//#define     INITEE       _IO8(0x12)     //eeprom location register
//#define     MISC         _IO8(0x13)     //miscellaneous mapping control
//#define     MTST0        _IO8(0x14)     //reserved
//#define     ITCR         _IO8(0x15)     //interrupt test control register
//#define     ITEST        _IO8(0x16)     //interrupt test register
//#define     MTST1        _IO8(0x17)     //reserved

//#define     MEMSIZ0      _IO8(0x1c)     //memory size
//#define     MEMSIZ1	     _IO8(0x1d)     //memory size
//#define     INTCR        _IO8(0x1e)     //interrupt control register
//#define     HPRIO        _IO8(0x1f)     //high priority reg


//#define     BKPCT0       _IO8(0x28)     //break control register
//#define     BKPCT1       _IO8(0x29)     //break control register
//#define     BKP0X        _IO8(0x2a)     //break 0 index register
//#define     BKP0H        _IO8(0x2b)     //break 0 pointer high
//#define     BKP0L        _IO8(0x2c)     //break 0 pointer low
//#define     BKP1X        _IO8(0x2d)     //break 1 index register
//#define     BKP1H        _IO8(0x2e)     //break 1 pointer high
//#define     BKP1L        _IO8(0x2f)     //break 1 pointer low
#define     PPAGE		_IO8(0x30)     //program page register

#define     PORTK		_IO8(0x32)     //port k data
#define     DDRK		_IO8(0x33)     //port k direction
#define     SYNR         _IO8(0x34)     //CRG synthesizer / multiplier register
#define     REFDV        _IO8(0x35)     //reference divider register
#define     CTFLG        _IO8(0x36)     //reserved
#define     CRGFLG       _IO8(0x37)     //CRG flags register
#define     CRGINT       _IO8(0x38)     //CRG interrupt register
#define     CLKSEL       _IO8(0x39)     //clock select register
#define     PLLCTL       _IO8(0x3a)     //pll control register
#define     RTICTL       _IO8(0x3b)     //real time interrupt control
#define     COPCTL       _IO8(0x3c)     //watchdog control
#define     FORBYP       _IO8(0x3d)     //
#define     CTCTL        _IO8(0x3e)     //
#define     ARMCOP       _IO8(0x3f)     //cop reset register

#define     TIOS         _IO8(0x40)     //timer input/output select
#define     CFORC        _IO8(0x41)     //timer compare force
#define     OC7M         _IO8(0x42)     //timer output compare 7 mask
#define     OC7D         _IO8(0x43)     //timer output compare 7 data
#define     TCNT         _IO16(0x44)    //timer counter register hi
#define     TCNTLO       _IO16(0x45)    //timer counter register Low
#define     TSCR1        _IO8(0x46)     //timer system control register
#define     TTOV         _IO8(0x47)     //Timer Toggle On Overflow Register
#define     TCTL1        _IO8(0x48)     //timer control register 1
#define     TCTL2        _IO8(0x49)     //timer control register 2
#define     TCTL3        _IO8(0x4a)     //timer control register 3
#define     TCTL4        _IO8(0x4b)     //timer control register 4
#define     TIE          _IO8(0x4c)     //timer interrupt Enable Register
#define     TMSK1        _IO8(0x4c)     ////timer interrupt mask 1 - added by Navid
#define     TSCR2        _IO8(0x4d)     //timer System Control Register 2
#define     TMSK2        _IO8(0x4d)     //timer interrupt mask 2 - added by Navid
#define     TFLG1        _IO8(0x4e)     //Main Timer Interrupt Flag 1
#define     TFLG2        _IO8(0x4f)     //Main Timer Unterrupt Flag 2
#define     TC0          _IO16(0x50)    //timer capture/compare register 0
#define     TC1          _IO16(0x52)    //timer capture/compare register 1
#define     TC2          _IO16(0x54)    //timer capture/compare register 2
#define     TC3          _IO16(0x56)    //timer capture/compare register 3
#define     TC4          _IO16(0x58)    //timer capture/compare register 4
#define     TC5          _IO16(0x5a)    //timer capture/compare register 5
#define     TC6          _IO16(0x5c)    //timer capture/compare register 6
#define     TC7          _IO16(0x5e)    //timer capture/compare register 7
#define     TC7Lo        _IO16(0x5F)    //timer capture/compare register 7 Low
#define     TACTL        _IO8(0x60)     //pulse accumulator controls
#define     PACTL        _IO8(0x60)     //pulse accumulator controls - added by Navid
#define     PAFLG        _IO8(0x61)     //pulse accumulator flags
#define     PACNT        _IO16(0x62)     //pulse accumulator counter 3 --added by Navid
#define     PACN3        _IO8(0x62)     //pulse accumulator counter 3
#define     PACN2        _IO8(0x63)     //pulse accumulator counter 2
#define     PACN1        _IO8(0x64)     //pulse accumulator counter 1
#define     PACN0        _IO8(0x65)     //pulse accumulator counter 0
#define     MCCTL        _IO8(0x66)     //modulus down conunter control
#define     MCFLG        _IO8(0x67)     //down counter flags
#define     ICPAR        _IO8(0x68)     //input pulse accumulator control
#define     DLYCT        _IO8(0x69)     //delay count to down counter
#define     ICOVW        _IO8(0x6a)     //input control overwrite register
#define     ICSYS        _IO8(0x6b)     //input control system control

//#define     TIMTST       _IO8(0x6d)     //timer test register
#define     PTPSR        _IO8(0x6E)     //precision Timer Prescaler
#define     PTMCPSR      _IO8(0x6F)     //precision Timer Counter Prescaler Select Register

#define     PBCTL        _IO8(0x70)     //pulse accumulator b control
#define     PBFLG        _IO8(0x71)     //pulse accumulator b flags
#define     PA3H         _IO8(0x72)     //pulse accumulator holding register 3
#define     PA2H         _IO8(0x73)     //pulse accumulator holding register 2
#define     PA1H         _IO8(0x74)     //pulse accumulator holding register 1
#define     PA0H         _IO8(0x75)     //pulse accumulator holding register 0
#define     MCCNT        _IO8(0x76)     //modulus down counter register
#define     MCCNTL       _IO8(0x77)     //low byte
#define     TC0H         _IO16(0x78)    //capture 0 holding register high
#define     TC0L         _IO16(0x79)    //capture 0 holding register low
#define     TC1H         _IO16(0x7a)    //capture 1 holding register high
#define     TC1L         _IO16(0x7B)    //capture 1 holding register low
#define     TC2H         _IO16(0x7c)    //capture 2 holding register high
#define     TC2L         _IO16(0x7d)    //capture 2 holding register low
#define     TC3H         _IO16(0x7e)    //capture 3 holding register high
#define     TC3L         _IO16(0x7f)    //capture 3 holding register low

#define     ATD1CTL0     _IO8(0x80)     //adc control 0
#define     ATD1CTL1     _IO8(0x81)     //adc control 1
#define     ATD1CTL2     _IO8(0x82)     //adc control 2
#define     ATD1CTL3     _IO8(0x83)     //adc control 3
#define     ATD1CTL4     _IO8(0x84)     //adc control 4
#define     ATD1CTL5     _IO8(0x85)     //adc control 5
#define     ATD1STAT0    _IO8(0x86)     //adc status register 0
#define     ATD1STAT     _IO16(0x86)    //adc status register 0 - added by Navid
#define     ATD1TEST0    _IO8(0x88)     //adc test
#define     ATD1TEST1    _IO8(0x89)     //adc test
#define     ATD1STAT2    _IO8(0x8a)     //adc status register 2
#define     ATD1STAT1    _IO8(0x8b)     //adc status register 1
#define     ATD1DIEN0	 _IO8(0x8c)      //adc Input Enable Register 0
#define     ATD1DIEN	 _IO8(0x8d)
#define     ATD1DIEN1	 _IO8(0x8d)      //adc Input Enable Register 1
#define     ATD1PTAD    _IO8(0x8e)      //adc Port AD0 Register
#define     ATD1PTAD0    _IO8(0x8e)      //adc Port AD0 Register
#define     ATD1PTAD1    _IO8(0x8f)      //adc Port AD1 Register
//#define     PORTAD0      _IO8(0x8f)     //port adc = input only
#define     ATD1DR0      _IO16(0x90)    //adc result 0 register
#define     ATD1DR1      _IO16(0x92)    //adc result 1 register
#define     ATD1DR2      _IO16(0x94)    //adc result 2 register
#define     ATD1DR3      _IO16(0x96)    //adc result 3 register
#define     ATD1DR4      _IO16(0x98)    //adc result 4 register
#define     ATD1DR5      _IO16(0x9a)    //adc result 5 register
#define     ATD1DR6      _IO16(0x9c)    //adc result 6 register
#define     ATD1DR7      _IO16(0x9e)    //adc result 7 register
#define     ATD1DR8      _IO16(0xA0)    //adc result 8 register
#define     ATD1DR9      _IO16(0xA2)    //adc result 9 register
#define     ATD1DR10     _IO16(0xA4)    //adc result 10 register
#define     ATD1DR11     _IO16(0xA6)    //adc result 11 register
#define     ATD1DR12     _IO16(0xA8)    //adc result 12 register
#define     ATD1DR13     _IO16(0xAa)    //adc result 13 register
#define     ATD1DR14     _IO16(0xAc)    //adc result 14 register
#define     ATD1DR15     _IO16(0xAe)    //adc result 15 register

#define     IIC1_IBAD    _IO8(0xB0)     //IIC 1 Address Register
#define     IIC1_IBFD    _IO8(0xB1)     //IIC 1 Frequency divider Register
#define     IIC1_IBCR    _IO8(0xB2)     //IIC 1 Control Register
#define     IIC1_IBSR    _IO8(0xB3)     //IIC 1 Status Register
#define     IIC1_IBDR    _IO8(0xB4)     //IIC 1 Data I/O Register

#define     SCI2BD       _IO16(0xB8)    //SCI2 Baud Rate Register
#define     SCI2BDH      _IO8(0xB8)     //SCI2 Baud Rate Register High
#define     SCI2ASR1     _IO8(0xB8)     //SCI2 Alternative Status Register 1
#define     SCI2BDL      _IO8(0xB9)     //SCI2 Baud Rate Register Low
#define     SCI2ACR1     _IO8(0xB9)     //SCI2 Alternative Control Register 1
#define     SCI2CR1      _IO8(0xBA)     //SCI2 Control Register 1
#define     SCI2ACR2     _IO8(0xBA)     //SCI2 Alternative Control Register 2
#define     SCI2CR2      _IO8(0xBB)     //SCI2 Control Register 2
#define     SCI2SR1      _IO8(0xBC)     //SCI2 Status Register 1
#define     SCI2SR2      _IO8(0xBD)     //SCI2 Status Register 2
#define     SCI2DR       _IO16(0xBE)    //SCI2 Data Register
#define     SCI2DRH      _IO8(0xBE)     //SCI2 Data Register High
#define     SCI2DRL      _IO8(0xBF)     //SCI2 Data Register Low

#define     SCI3BD       _IO16(0xC0)    //SCI3 Baud Rate Register
#define     SCI3BDH      _IO8(0xC0)     //SCI3 Baud Rate Register High
#define     SCI3ASR1     _IO8(0xC0)     //SCI3 Alternative Status Register 1
#define     SCI3BDL      _IO8(0xC1)     //SCI3 Baud Rate Register Low
#define     SCI3ACR1     _IO8(0xC1)     //SCI3 Alternative Control Register 1
#define     SCI3CR1      _IO8(0xC2)     //SCI3 Control Register 1
#define     SCI3ACR2     _IO8(0xC2)     //SCI3 Alternative Control Register 2
#define     SCI3CR2      _IO8(0xC3)     //SCI3 Control Register 2
#define     SCI3SR1      _IO8(0xC4)     //SCI3 Status Register 1
#define     SCI3SR2      _IO8(0xC5)     //SCI3 Status Register 2
#define     SCI3DR       _IO16(0xC6)    //SCI3 Data Register
#define     SCI3DRH      _IO8(0xC6)     //SCI3 Data Register High
#define     SCI3DRL      _IO8(0xC7)     //SCI3 Data Register Low

#define     SCI0BD       _IO16(0xC8)    //SCI0 Baud Rate Register
#define     SCI0BDH      _IO8(0xC8)     //SCI0 Baud Rate Register High
#define     SCI0ASR1     _IO8(0xC8)     //SCI0 Alternative Status Register 1
#define     SCI0BDL      _IO8(0xC9)     //SCI0 Baud Rate Register Low
#define     SCI0ACR1     _IO8(0xC9)     //SCI0 Alternative Control Register 1
#define     SCI0CR1      _IO8(0xCa)     //SCI0 Control Register 1
#define     SCI0ACR2     _IO8(0xCa)     //SCI0 Alternative Control Register 2
#define     SCI0CR2      _IO8(0xCb)     //SCI0 Control Register 2
#define     SCI0SR1      _IO8(0xCc)     //SCI0 Status Register 1
#define     SCI0SR2      _IO8(0xCd)     //SCI0 Status Register 2
#define     SCI0DR       _IO16(0xCe)    //SCI0 Data Register
#define     SCI0DRH      _IO8(0xCe)     //SCI0 Data Register High
#define     SCI0DRL      _IO8(0xCf)     //SCI0 Data Register Low

#define     SCI1BD       _IO16(0xD0)    //SCI1 Baud Rate Register
#define     SCI1BDH      _IO8(0xD0)     //SCI1 Baud Rate Register High
#define     SCI1ASR1     _IO8(0xD0)     //SCI1 Alternative Status Register 1
#define     SCI1BDL      _IO8(0xD1)     //SCI1 Baud Rate Register Low
#define     SCI1ACR1     _IO8(0xD1)     //SCI1 Alternative Control Register 1
#define     SCI1CR1      _IO8(0xD2)     //SCI1 Control Register 1
#define     SCI1ACR2     _IO8(0xD2)     //SCI1 Alternative Control Register 2
#define     SCI1CR2      _IO8(0xD3)     //SCI1 Control Register 2
#define     SCI1SR1      _IO8(0xD4)     //SCI1 Status Register 1
#define     SCI1SR2      _IO8(0xD5)     //SCI1 Status Register 2
#define     SCI1DR       _IO16(0xD6)    //SCI1 Data Register
#define     SCI1DRH      _IO8(0xD6)     //SCI1 Data Register High
#define     SCI1DRL      _IO8(0xD7)     //SCI1 Data Register Low

#define     SPI0CR1      _IO8(0xd8)     //spi 0 control1 reg
#define     SPI0CR2      _IO8(0xd9)     //spi 0 control2 reg
#define     SPI0BR       _IO8(0xda)     //spi 0 baud reg
#define     SPI0SR       _IO8(0xdb)     //spi 0 status reg hi
#define     SPI0DR       _IO8(0xdd)     //spi 0 data reg

#define     IIC0_IBAD    _IO8(0xE0)     //IIC 0 Address Register
#define     IIC0_IBFD    _IO8(0xE1)     //IIC 0 Frequency divider Register
#define     IIC0_IBCR    _IO8(0xE2)     //IIC 0 Control Register
#define     IIC0_IBSR    _IO8(0xE3)     //IIC 0 Status Register
#define     IIC0_IBDR    _IO8(0xE4)     //IIC 0 Data I/O Register

#define     SPI1CR1      _IO8(0xF0)     //spi 1 control1 reg
#define     SPI1CR2      _IO8(0xF1)     //spi 1 control2 reg
#define     SPI1BR       _IO8(0xF2)     //spi 1 baud reg
#define     SPI1SR       _IO8(0xF3)     //spi 1 status reg hi
#define     SPI1DR       _IO8(0xF5)     //spi 1 data reg

#define     SPI2CR1      _IO8(0xF8)     //spi 2 control1 reg
#define     SPI2CR2      _IO8(0xF9)     //spi 2 control2 reg
#define     SPI2BR       _IO8(0xFa)     //spi 2 baud reg
#define     SPI2SR       _IO8(0xFb)     //spi 2 status reg hi
#define     SPI2DR       _IO8(0xFd)     //spi 2 data reg

#define     FCLKDIV	     _IO8(0x100)    //flash clock divider
#define     FSEC		_IO8(0x101)    //flash security register
#define     FTSTMOD		_IO8(0x102)
#define     FCNFG		_IO8(0x103)    //flash configuration register
#define     FPROT		_IO8(0x104)    //flash protection register
#define     FSTAT		_IO8(0x105)    //flash status register
#define     FCMD		_IO8(0x106)    //flash command register
#define     FADDRHI      _IO8(0x108)    //flash address high byte
#define     FADDRLO      _IO8(0x109)    //flash address low byte
#define     FDATAHI      _IO8(0x10a)    //flash data high byte
#define     FDATALO      _IO8(0x10b)

#define     ECLKDIV	     _IO8(0x110)    //eeprom clock divider
#define     ECNFG		_IO8(0x113)    //eeprom configuration register
#define     EPROT		_IO8(0x114)    //eeprom protection register
#define     ESTAT		_IO8(0x115)    //eeprom status register
#define     ECMD		_IO8(0x116)    //eeprom command register
#define     EADDRHI    _IO8(0x118)    //eeprom address high byte
#define     EADDRLO    _IO8(0x119)    //eeprom address low byte
#define     EDATAHI    _IO8(0x11a)    //eeprom data high byte
#define     EDATALO    _IO8(0x11b)    //eeprom data low byte

#define     RAMWPC     _IO8(0x11C)    //RAM Write Protection Control Register
#define     RAMXGU     _IO8(0x11D)    //RAM XGATE Upper Boundary Register
#define     RAMSHL     _IO8(0x11E)    //RAM Shared Region Lower Boundary Register
#define     RAMSHU     _IO8(0x11F)    //RAM Shared Region Upper Boundary Register

#define     IVBR       _IO8(0x121)    //Interrupt Vector Base Register
#define     INT_XGPRIO _IO8(0x126)    //XGATE Interrupt Priority Configuration Register
#define     INT_CFADDR _IO8(0x127)    //Interrupt Configuration Address Register
#define     INT_CFDATA0 _IO8(0x128)   //Interrupt Configuration Data Register 0
#define     INT_CFDATA1 _IO8(0x129)   //Interrupt Configuration Data Register 1
#define     INT_CFDATA2 _IO8(0x12A)   //Interrupt Configuration Data Register 2
#define     INT_CFDATA3 _IO8(0x12B)   //Interrupt Configuration Data Register 3
#define     INT_CFDATA4 _IO8(0x12C)   //Interrupt Configuration Data Register 4
#define     INT_CFDATA5 _IO8(0x12D)   //Interrupt Configuration Data Register 5
#define     INT_CFDATA6 _IO8(0x12E)   //Interrupt Configuration Data Register 6
#define     INT_CFDATA7 _IO8(0x12F)   //Interrupt Configuration Data Register 7

#define     SCI4BD       _IO16(0x130)    //SCI4 Baud Rate Register
#define     SCI4BDH      _IO8(0x130)     //SCI4 Baud Rate Register High
#define     SCI4ASR1     _IO8(0x130)     //SCI4 Alternative Status Register 1
#define     SCI4BDL      _IO8(0x131)     //SCI4 Baud Rate Register Low
#define     SCI4ACR1     _IO8(0x131)     //SCI4 Alternative Control Register 1
#define     SCI4CR1      _IO8(0x132)     //SCI4 Control Register 1
#define     SCI4ACR2     _IO8(0x132)     //SCI4 Alternative Control Register 2
#define     SCI4CR2      _IO8(0x133)     //SCI4 Control Register 2
#define     SCI4SR1      _IO8(0x134)     //SCI4 Status Register 1
#define     SCI4SR2      _IO8(0x135)     //SCI4 Status Register 2
#define     SCI4DR       _IO16(0x136)    //SCI4 Data Register
#define     SCI4DRH      _IO8(0x136)     //SCI4 Data Register High
#define     SCI4DRL      _IO8(0x137)     //SCI4 Data Register Low

#define     SCI5BD       _IO16(0x138)    //SCI5 Baud Rate Register
#define     SCI5BDH      _IO8(0x138)     //SCI5 Baud Rate Register High
#define     SCI5ASR1     _IO8(0x138)     //SCI5 Alternative Status Register 1
#define     SCI5BDL      _IO8(0x139)     //SCI5 Baud Rate Register Low
#define     SCI5ACR1     _IO8(0x139)     //SCI5 Alternative Control Register 1
#define     SCI5CR1      _IO8(0x13A)     //SCI5 Control Register 1
#define     SCI5ACR2     _IO8(0x13A)     //SCI5 Alternative Control Register 2
#define     SCI5CR2      _IO8(0x13B)     //SCI5 Control Register 2
#define     SCI5SR1      _IO8(0x13C)     //SCI5 Status Register 1
#define     SCI5SR2      _IO8(0x13d)     //SCI5 Status Register 2
#define     SCI5DR       _IO16(0x13E)    //SCI5 Data Register
#define     SCI5DRH      _IO8(0x13E)     //SCI5 Data Register High
#define     SCI5DRL      _IO8(0x13F)     //SCI5 Data Register Low

#define     CAN0CTL0	_IO8(0x140)    //can0 control register 0
#define     CAN0CTL1	_IO8(0x141)    //can0 control register 1
#define     CAN0BTR0	_IO8(0x142)    //can0 bus timing register 0
#define     CAN0BTR1	_IO8(0x143)    //can0 bus timing register 1
#define     CAN0RFLG	_IO8(0x144)    //can0 receiver flags
#define     CAN0RIER	_IO8(0x145)    //can0 receiver interrupt enables
#define     CAN0TFLG	_IO8(0x146)    //can0 transmit flags
#define     CAN0TIER	_IO8(0x147)    //can0 transmit interrupt enables
#define     CAN0TARQ	_IO8(0x148)    //can0 transmit message abort control
#define     CAN0TAAK	_IO8(0x149)    //can0 transmit message abort status
#define     CAN0TBSEL	_IO8(0x14a)    //can0 transmit buffer select
#define     CAN0IDAC	_IO8(0x14b)    //can0 identfier acceptance control
#define     CAN0MISC   _IO8(0x14d)    //can0 miscellaneous Register
#define     CAN0RXERR	_IO8(0x14e)    //can0 receive error counter
#define     CAN0TXERR	_IO8(0x14f)    //can0 transmit error counter
#define     CAN0IDAR0	_IO8(0x150)    //can0 identifier acceptance register 0
#define     CAN0IDAR1	_IO8(0x151)    //can0 identifier acceptance register 1
#define     CAN0IDAR2	_IO8(0x152)    //can0 identifier acceptance register 2
#define     CAN0IDAR3	_IO8(0x153)    //can0 identifier acceptance register 3
#define     CAN0IDMR0	_IO8(0x154)    //can0 identifier mask register 0
#define     CAN0IDMR1	_IO8(0x155)    //can0 identifier mask register 1
#define     CAN0IDMR2	_IO8(0x156)    //can0 identifier mask register 2
#define     CAN0IDMR3	_IO8(0x157)    //can0 identifier mask register 3
#define     CAN0IDAR4	_IO8(0x158)    //can0 identifier acceptance register 4
#define     CAN0IDAR5	_IO8(0x159)    //can0 identifier acceptance register 5
#define     CAN0IDAR6	_IO8(0x15a)    //can0 identifier acceptance register 6
#define     CAN0IDAR7	_IO8(0x15b)    //can0 identifier acceptance register 7
#define     CAN0IDMR4	_IO8(0x15c)    //can0 identifier mask register 4
#define     CAN0IDMR5	_IO8(0x15d)    //can0 identifier mask register 5
#define     CAN0IDMR6	_IO8(0x15e)    //can0 identifier mask register 6
#define     CAN0IDMR7	_IO8(0x15f)    //can0 identifier mask register 7
#define     CAN0RXIDR0	_IO8(0x160)    //can0 Receiver Identifier Register 0
#define     CAN0RXIDR1	_IO8(0x161)    //can0 Receiver Identifier Register 1
#define     CAN0RXIDR2	_IO8(0x162)    //can0 Receiver Identifier Register 2
#define     CAN0RXIDR3	_IO8(0x163)    //can0 Receiver Identifier Register 3
#define     CAN0RXDSR0 _IO8(0x164)    //can0 Receiver Data Segment Register 0
#define     CAN0RXDSR1 _IO8(0x165)    //can0 Receiver Data Segment Register 1
#define     CAN0RXDSR2 _IO8(0x166)    //can0 Receiver Data Segment Register 2
#define     CAN0RXDSR3 _IO8(0x167)    //can0 Receiver Data Segment Register 3
#define     CAN0RXDSR4 _IO8(0x168)    //can0 Receiver Data Segment Register 4
#define     CAN0RXDSR5 _IO8(0x169)    //can0 Receiver Data Segment Register 5
#define     CAN0RXDSR6 _IO8(0x16A)    //can0 Receiver Data Segment Register 6
#define     CAN0RXDSR7 _IO8(0x16B)    //can0 Receiver Data Segment Register 7
#define     CAN0RXDLR  _IO8(0x16C)    //can0 Receiver Data Length Register
#define     CAN0RXTSR  _IO16(0x16E)   //can0 Receiver Time Stamp Register
#define     CAN0RXTSRH _IO16(0x16E)   //can0 Receiver Time Stamp Register high
#define     CAN0RXTSRL _IO16(0x16F)   //can0 Receiver Time Stamp Register low
#define     CAN0TXIDR0	_IO8(0x170)    //can0 tx Identifier Register 0
#define     CAN0TXIDR1	_IO8(0x171)    //can0 tx Identifier Register 1
#define     CAN0TXIDR2	_IO8(0x172)    //can0 tx Identifier Register 2
#define     CAN0TXIDR3	_IO8(0x173)    //can0 tx Identifier Register 3
#define     CAN0TXDSR0 _IO8(0x174)    //can0 tx Data Segment Register 0
#define     CAN0TXDSR1 _IO8(0x175)    //can0 tx Data Segment Register 1
#define     CAN0TXDSR2 _IO8(0x176)    //can0 tx Data Segment Register 2
#define     CAN0TXDSR3 _IO8(0x177)    //can0 tx Data Segment Register 3
#define     CAN0TXDSR4 _IO8(0x178)    //can0 tx Data Segment Register 4
#define     CAN0TXDSR5 _IO8(0x179)    //can0 tx Data Segment Register 5
#define     CAN0TXDSR6 _IO8(0x17a)    //can0 tx Data Segment Register 6
#define     CAN0TXDSR7 _IO8(0x17b)    //can0 tx Data Segment Register 7
#define     CAN0TXDLR  _IO8(0x17C)    //can0 tx Data Length Register
#define     CAN0TXTBPR _IO8(0x17D)    //can0 tx Buffer Priority Register
#define     CAN0TXTSR  _IO16(0x17E)   //can0 tx Time Stamp Register
#define     CAN0TXTSRH _IO16(0x17E)   //can0 tx Time Stamp Register high
#define     CAN0TXTSRL _IO16(0x17F)   //can0 tx Time Stamp Register low

#define     CAN1CTL0	_IO8(0x180)    //can1 control register 0
#define     CAN1CTL1	_IO8(0x181)    //can1 control register 1
#define     CAN1BTR0	_IO8(0x182)    //can1 bus timing register 0
#define     CAN1BTR1	_IO8(0x183)    //can1 bus timing register 1
#define     CAN1RFLG	_IO8(0x184)    //can1 receiver flags
#define     CAN1RIER	_IO8(0x185)    //can1 receiver interrupt enables
#define     CAN1TFLG	_IO8(0x186)    //can1 transmit flags
#define     CAN1TIER	_IO8(0x187)    //can1 transmit interrupt enables
#define     CAN1TARQ	_IO8(0x188)    //can1 transmit message abort control
#define     CAN1TAAK	_IO8(0x189)    //can1 transmit message abort status
#define     CAN1TBSEL	_IO8(0x18a)    //can1 transmit buffer select
#define     CAN1IDAC	_IO8(0x18b)    //can1 identfier acceptance control
#define     CAN1MISC   _IO8(0x18d)    //can1 miscellaneous Register
#define     CAN1RXERR	_IO8(0x18e)    //can1 receive error counter
#define     CAN1TXERR	_IO8(0x18f)    //can1 transmit error counter
#define     CAN1IDAR0	_IO8(0x190)    //can1 identifier acceptance register 0
#define     CAN1IDAR1	_IO8(0x191)    //can1 identifier acceptance register 1
#define     CAN1IDAR2	_IO8(0x192)    //can1 identifier acceptance register 2
#define     CAN1IDAR3	_IO8(0x193)    //can1 identifier acceptance register 3
#define     CAN1IDMR0	_IO8(0x194)    //can1 identifier mask register 0
#define     CAN1IDMR1	_IO8(0x195)    //can1 identifier mask register 1
#define     CAN1IDMR2	_IO8(0x196)    //can1 identifier mask register 2
#define     CAN1IDMR3	_IO8(0x197)    //can1 identifier mask register 3
#define     CAN1IDAR4	_IO8(0x198)    //can1 identifier acceptance register 4
#define     CAN1IDAR5	_IO8(0x199)    //can1 identifier acceptance register 5
#define     CAN1IDAR6	_IO8(0x19a)    //can1 identifier acceptance register 6
#define     CAN1IDAR7	_IO8(0x19b)    //can1 identifier acceptance register 7
#define     CAN1IDMR4	_IO8(0x19c)    //can1 identifier mask register 4
#define     CAN1IDMR5	_IO8(0x19d)    //can1 identifier mask register 5
#define     CAN1IDMR6	_IO8(0x19e)    //can1 identifier mask register 6
#define     CAN1IDMR7	_IO8(0x19f)    //can1 identifier mask register 7
#define     CAN1RXIDR0	_IO8(0x1A0)    //can1 Receiver Identifier Register 0
#define     CAN1RXIDR1	_IO8(0x1A1)    //can1 Receiver Identifier Register 1
#define     CAN1RXIDR2	_IO8(0x1A2)    //can1 Receiver Identifier Register 2
#define     CAN1RXIDR3	_IO8(0x1A3)    //can1 Receiver Identifier Register 3
#define     CAN1RXDSR0 _IO8(0x1A4)    //can1 Receiver Data Segment Register 0
#define     CAN1RXDSR1 _IO8(0x1A5)    //can1 Receiver Data Segment Register 1
#define     CAN1RXDSR2 _IO8(0x1A6)    //can1 Receiver Data Segment Register 2
#define     CAN1RXDSR3 _IO8(0x1A7)    //can1 Receiver Data Segment Register 3
#define     CAN1RXDSR4 _IO8(0x1A8)    //can1 Receiver Data Segment Register 4
#define     CAN1RXDSR5 _IO8(0x1A9)    //can1 Receiver Data Segment Register 5
#define     CAN1RXDSR6 _IO8(0x1AA)    //can1 Receiver Data Segment Register 6
#define     CAN1RXDSR7 _IO8(0x1AB)    //can1 Receiver Data Segment Register 7
#define     CAN1RXDLR  _IO8(0x1AC)    //can1 Receiver Data Length Register
#define     CAN1RXTSR  _IO16(0x1AE)   //can1 Receiver Time Stamp Register
#define     CAN1RXTSRH _IO16(0x1AE)   //can1 Receiver Time Stamp Register high
#define     CAN1RXTSRL _IO16(0x1AF)   //can1 Receiver Time Stamp Register low
#define     CAN1TXIDR0	_IO8(0x1B0)    //can1 tx Identifier Register 0
#define     CAN1TXIDR1	_IO8(0x1B1)    //can1 tx Identifier Register 1
#define     CAN1TXIDR2	_IO8(0x1B2)    //can1 tx Identifier Register 2
#define     CAN1TXIDR3	_IO8(0x1B3)    //can1 tx Identifier Register 3
#define     CAN1TXDSR0 _IO8(0x1B4)    //can1 tx Data Segment Register 0
#define     CAN1TXDSR1 _IO8(0x1B5)    //can1 tx Data Segment Register 1
#define     CAN1TXDSR2 _IO8(0x1B6)    //can1 tx Data Segment Register 2
#define     CAN1TXDSR3 _IO8(0x1B7)    //can1 tx Data Segment Register 3
#define     CAN1TXDSR4 _IO8(0x1B8)    //can1 tx Data Segment Register 4
#define     CAN1TXDSR5 _IO8(0x1B9)    //can1 tx Data Segment Register 5
#define     CAN1TXDSR6 _IO8(0x1Ba)    //can1 tx Data Segment Register 6
#define     CAN1TXDSR7 _IO8(0x1Bb)    //can1 tx Data Segment Register 7
#define     CAN1TXDLR  _IO8(0x1BC)    //can1 tx Data Length Register
#define     CAN1TXTBPR _IO8(0x1BD)    //can1 tx Buffer Priority Register
#define     CAN1TXTSR  _IO16(0x1BE)   //can1 tx Time Stamp Register
#define     CAN1TXTSRH _IO16(0x1BE)   //can1 tx Time Stamp Register high
#define     CAN1TXTSRL _IO16(0x1BF)   //can1 tx Time Stamp Register low

#define     CAN2CTL0	_IO8(0x1C0)    //can2 control register 0
#define     CAN2CTL1	_IO8(0x1C1)    //can2 control register 1
#define     CAN2BTR0	_IO8(0x1C2)    //can2 bus timing register 0
#define     CAN2BTR1	_IO8(0x1C3)    //can2 bus timing register 1
#define     CAN2RFLG	_IO8(0x1C4)    //can2 receiver flags
#define     CAN2RIER	_IO8(0x1C5)    //can2 receiver interrupt enables
#define     CAN2TFLG	_IO8(0x1C6)    //can2 transmit flags
#define     CAN2TIER	_IO8(0x1C7)    //can2 transmit interrupt enables
#define     CAN2TARQ	_IO8(0x1C8)    //can2 transmit message abort control
#define     CAN2TAAK	_IO8(0x1C9)    //can2 transmit message abort status
#define     CAN2TBSEL	_IO8(0x1Ca)    //can2 transmit buffer select
#define     CAN2IDAC	_IO8(0x1Cb)    //can2 identfier acceptance control
#define     CAN2MISC   _IO8(0x1Cd)    //can2 miscellaneous Register
#define     CAN2RXERR	_IO8(0x1Ce)    //can2 receive error counter
#define     CAN2TXERR	_IO8(0x1Cf)    //can2 transmit error counter
#define     CAN2IDAR0	_IO8(0x1D0)    //can2 identifier acceptance register 0
#define     CAN2IDAR1	_IO8(0x1D1)    //can2 identifier acceptance register 1
#define     CAN2IDAR2	_IO8(0x1D2)    //can2 identifier acceptance register 2
#define     CAN2IDAR3	_IO8(0x1D3)    //can2 identifier acceptance register 3
#define     CAN2IDMR0	_IO8(0x1D4)    //can2 identifier mask register 0
#define     CAN2IDMR1	_IO8(0x1D5)    //can2 identifier mask register 1
#define     CAN2IDMR2	_IO8(0x1D6)    //can2 identifier mask register 2
#define     CAN2IDMR3	_IO8(0x1D7)    //can2 identifier mask register 3
#define     CAN2IDAR4	_IO8(0x1D8)    //can2 identifier acceptance register 4
#define     CAN2IDAR5	_IO8(0x1D9)    //can2 identifier acceptance register 5
#define     CAN2IDAR6	_IO8(0x1Da)    //can2 identifier acceptance register 6
#define     CAN2IDAR7	_IO8(0x1Db)    //can2 identifier acceptance register 7
#define     CAN2IDMR4	_IO8(0x1Dc)    //can2 identifier mask register 4
#define     CAN2IDMR5	_IO8(0x1Dd)    //can2 identifier mask register 5
#define     CAN2IDMR6	_IO8(0x1De)    //can2 identifier mask register 6
#define     CAN2IDMR7	_IO8(0x1Df)    //can2 identifier mask register 7
#define     CAN2RXIDR0	_IO8(0x1E0)    //can2 Receiver Identifier Register 0
#define     CAN2RXIDR1	_IO8(0x1E1)    //can2 Receiver Identifier Register 1
#define     CAN2RXIDR2	_IO8(0x1E2)    //can2 Receiver Identifier Register 2
#define     CAN2RXIDR3	_IO8(0x1E3)    //can2 Receiver Identifier Register 3
#define     CAN2RXDSR0 _IO8(0x1E4)    //can2 Receiver Data Segment Register 0
#define     CAN2RXDSR1 _IO8(0x1E5)    //can2 Receiver Data Segment Register 1
#define     CAN2RXDSR2 _IO8(0x1E6)    //can2 Receiver Data Segment Register 2
#define     CAN2RXDSR3 _IO8(0x1E7)    //can2 Receiver Data Segment Register 3
#define     CAN2RXDSR4 _IO8(0x1E8)    //can2 Receiver Data Segment Register 4
#define     CAN2RXDSR5 _IO8(0x1E9)    //can2 Receiver Data Segment Register 5
#define     CAN2RXDSR6 _IO8(0x1EA)    //can2 Receiver Data Segment Register 6
#define     CAN2RXDSR7 _IO8(0x1EB)    //can2 Receiver Data Segment Register 7
#define     CAN2RXDLR  _IO8(0x1EC)    //can2 Receiver Data Length Register
#define     CAN2RXTSR  _IO16(0x1EE)   //can2 Receiver Time Stamp Register
#define     CAN2RXTSRH _IO16(0x1EE)   //can2 Receiver Time Stamp Register high
#define     CAN2RXTSRL _IO16(0x1EF)   //can2 Receiver Time Stamp Register low
#define     CAN2TXIDR0	_IO8(0x1F0)    //can2 tx Identifier Register 0
#define     CAN2TXIDR1	_IO8(0x1F1)    //can2 tx Identifier Register 1
#define     CAN2TXIDR2	_IO8(0x1F2)    //can2 tx Identifier Register 2
#define     CAN2TXIDR3	_IO8(0x1F3)    //can2 tx Identifier Register 3
#define     CAN2TXDSR0 _IO8(0x1F4)    //can2 tx Data Segment Register 0
#define     CAN2TXDSR1 _IO8(0x1F5)    //can2 tx Data Segment Register 1
#define     CAN2TXDSR2 _IO8(0x1F6)    //can2 tx Data Segment Register 2
#define     CAN2TXDSR3 _IO8(0x1F7)    //can2 tx Data Segment Register 3
#define     CAN2TXDSR4 _IO8(0x1F8)    //can2 tx Data Segment Register 4
#define     CAN2TXDSR5 _IO8(0x1F9)    //can2 tx Data Segment Register 5
#define     CAN2TXDSR6 _IO8(0x1Fa)    //can2 tx Data Segment Register 6
#define     CAN2TXDSR7 _IO8(0x1Fb)    //can2 tx Data Segment Register 7
#define     CAN2TXDLR  _IO8(0x1FC)    //can2 tx Data Length Register
#define     CAN2TXTBPR _IO8(0x1FD)    //can2 tx Buffer Priority Register
#define     CAN2TXTSR  _IO16(0x1FE)   //can2 tx Time Stamp Register
#define     CAN2TXTSRH _IO16(0x1FE)   //can2 tx Time Stamp Register high
#define     CAN2TXTSRL _IO16(0x1FF)   //can2 tx Time Stamp Register low

#define     CAN3CTL0	_IO8(0x200)    //can3 control register 0
#define     CAN3CTL1	_IO8(0x201)    //can3 control register 1
#define     CAN3BTR0	_IO8(0x202)    //can3 bus timing register 0
#define     CAN3BTR1	_IO8(0x203)    //can3 bus timing register 1
#define     CAN3RFLG	_IO8(0x204)    //can3 receiver flags
#define     CAN3RIER	_IO8(0x205)    //can3 receiver interrupt enables
#define     CAN3TFLG	_IO8(0x206)    //can3 transmit flags
#define     CAN3TIER	_IO8(0x207)    //can3 transmit interrupt enables
#define     CAN3TARQ	_IO8(0x208)    //can3 transmit message abort control
#define     CAN3TAAK	_IO8(0x209)    //can3 transmit message abort status
#define     CAN3TBSEL	_IO8(0x20a)    //can3 transmit buffer select
#define     CAN3IDAC	_IO8(0x20b)    //can3 identfier acceptance control
#define     CAN3MISC   _IO8(0x20d)    //can3 miscellaneous Register
#define     CAN3RXERR	_IO8(0x20e)    //can3 receive error counter
#define     CAN3TXERR	_IO8(0x20f)    //can3 transmit error counter
#define     CAN3IDAR0	_IO8(0x210)    //can3 identifier acceptance register 0
#define     CAN3IDAR1	_IO8(0x211)    //can3 identifier acceptance register 1
#define     CAN3IDAR2	_IO8(0x212)    //can3 identifier acceptance register 2
#define     CAN3IDAR3	_IO8(0x213)    //can3 identifier acceptance register 3
#define     CAN3IDMR0	_IO8(0x214)    //can3 identifier mask register 0
#define     CAN3IDMR1	_IO8(0x215)    //can3 identifier mask register 1
#define     CAN3IDMR2	_IO8(0x216)    //can3 identifier mask register 2
#define     CAN3IDMR3	_IO8(0x217)    //can3 identifier mask register 3
#define     CAN3IDAR4	_IO8(0x218)    //can3 identifier acceptance register 4
#define     CAN3IDAR5	_IO8(0x219)    //can3 identifier acceptance register 5
#define     CAN3IDAR6	_IO8(0x21a)    //can3 identifier acceptance register 6
#define     CAN3IDAR7	_IO8(0x21b)    //can3 identifier acceptance register 7
#define     CAN3IDMR4	_IO8(0x21c)    //can3 identifier mask register 4
#define     CAN3IDMR5	_IO8(0x21d)    //can3 identifier mask register 5
#define     CAN3IDMR6	_IO8(0x21e)    //can3 identifier mask register 6
#define     CAN3IDMR7	_IO8(0x21f)    //can3 identifier mask register 7
#define     CAN3RXIDR0	_IO8(0x220)    //can3 Receiver Identifier Register 0
#define     CAN3RXIDR1	_IO8(0x221)    //can3 Receiver Identifier Register 1
#define     CAN3RXIDR2	_IO8(0x222)    //can3 Receiver Identifier Register 2
#define     CAN3RXIDR3	_IO8(0x223)    //can3 Receiver Identifier Register 3
#define     CAN3RXDSR0 _IO8(0x224)    //can3 Receiver Data Segment Register 0
#define     CAN3RXDSR1 _IO8(0x225)    //can3 Receiver Data Segment Register 1
#define     CAN3RXDSR2 _IO8(0x226)    //can3 Receiver Data Segment Register 2
#define     CAN3RXDSR3 _IO8(0x227)    //can3 Receiver Data Segment Register 3
#define     CAN3RXDSR4 _IO8(0x228)    //can3 Receiver Data Segment Register 4
#define     CAN3RXDSR5 _IO8(0x229)    //can3 Receiver Data Segment Register 5
#define     CAN3RXDSR6 _IO8(0x22A)    //can3 Receiver Data Segment Register 6
#define     CAN3RXDSR7 _IO8(0x22B)    //can3 Receiver Data Segment Register 7
#define     CAN3RXDLR  _IO8(0x22C)    //can3 Receiver Data Length Register
#define     CAN3RXTSR  _IO16(0x22E)   //can3 Receiver Time Stamp Register
#define     CAN3RXTSRH _IO16(0x22E)   //can3 Receiver Time Stamp Register high
#define     CAN3RXTSRL _IO16(0x22F)   //can3 Receiver Time Stamp Register low
#define     CAN3TXIDR0	_IO8(0x230)    //can3 tx Identifier Register 0
#define     CAN3TXIDR1	_IO8(0x231)    //can3 tx Identifier Register 1
#define     CAN3TXIDR2	_IO8(0x232)    //can3 tx Identifier Register 2
#define     CAN3TXIDR3	_IO8(0x233)    //can3 tx Identifier Register 3
#define     CAN3TXDSR0 _IO8(0x234)    //can3 tx Data Segment Register 0
#define     CAN3TXDSR1 _IO8(0x235)    //can3 tx Data Segment Register 1
#define     CAN3TXDSR2 _IO8(0x236)    //can3 tx Data Segment Register 2
#define     CAN3TXDSR3 _IO8(0x237)    //can3 tx Data Segment Register 3
#define     CAN3TXDSR4 _IO8(0x238)    //can3 tx Data Segment Register 4
#define     CAN3TXDSR5 _IO8(0x239)    //can3 tx Data Segment Register 5
#define     CAN3TXDSR6 _IO8(0x23a)    //can3 tx Data Segment Register 6
#define     CAN3TXDSR7 _IO8(0x23b)    //can3 tx Data Segment Register 7
#define     CAN3TXDLR  _IO8(0x23C)    //can3 tx Data Length Register
#define     CAN3TXTBPR _IO8(0x23D)    //can3 tx Buffer Priority Register
#define     CAN3TXTSR  _IO16(0x23E)   //can3 tx Time Stamp Register
#define     CAN3TXTSRH _IO16(0x23E)   //can3 tx Time Stamp Register high
#define     CAN3TXTSRL _IO16(0x23F)   //can3 tx Time Stamp Register low

#define     PTT		    _IO8(0x240)    //portt data register
#define     PTIT		_IO8(0x241)    //portt input register
#define     DDRT		_IO8(0x242)    //portt direction register
#define     RDRT		_IO8(0x243)    //portt reduced drive register
#define     PERT		_IO8(0x244)    //portt pull device enable
#define     PPST		_IO8(0x245)    //portt pull polarity select

#define     PTS		    _IO8(0x248)    //ports data register
#define     PTIS		_IO8(0x249)    //ports input register
#define     DDRS		_IO8(0x24a)    //ports direction register
#define     RDRS		_IO8(0x24b)    //ports reduced drive register
#define     PERS		_IO8(0x24c)    //ports pull device enable
#define     PPSS		_IO8(0x24d)    //ports pull polarity select
#define     WOMS		_IO8(0x24e)    //ports wired or mode register

#define     PTM		_IO8(0x250)    //portm data register
#define     PTIM		_IO8(0x251)    //portm input register
#define     DDRM		_IO8(0x252)    //portm direction register
#define     RDRM		_IO8(0x253)    //portm reduced drive register
#define     PERM		_IO8(0x254)    //portm pull device enable
#define     PPSM		_IO8(0x255)    //portm pull polarity select
#define     WOMM		_IO8(0x256)    //portm wired or mode register
#define     MODRR		_IO8(0x257)    //portm module routing register

#define     PTP		    _IO8(0x258)    //portp data register
#define     PTIP		_IO8(0x259)    //portp input register
#define     DDRP		_IO8(0x25a)    //portp direction register
#define     RDRP		_IO8(0x25b)    //portp reduced drive register
#define     PERP		_IO8(0x25c)    //portp pull device enable
#define     PPSP		_IO8(0x25d)    //portp pull polarity select
#define     PIEP		_IO8(0x25e)    //portp interrupt enable register
#define     PIFP		_IO8(0x25f)    //portp interrupt flag register

#define     PTH		    _IO8(0x260)    //porth data register
#define     PTIH		_IO8(0x261)    //porth input register
#define     DDRH		_IO8(0x262)    //porth direction register
#define     RDRH		_IO8(0x263)    //porth reduced drive register
#define     PERH		_IO8(0x264)    //porth pull device enable
#define     PPSH		_IO8(0x265)    //porth pull polarity select
#define     PIEH		_IO8(0x266)    //porth interrupt enable register
#define     PIFH		_IO8(0x267)    //porth interrupt flag register

#define     PTJ		_IO8(0x268)    //portp data register
#define     PTIJ		_IO8(0x269)    //portp input register
#define     DDRJ		_IO8(0x26a)    //portp direction register
#define     RDRJ		_IO8(0x26b)    //portp reduced drive register
#define     PERJ		_IO8(0x26c)    //portp pull device enable
#define     PPSJ		_IO8(0x26d)    //portp pull polarity select
#define     PIEJ		_IO8(0x26e)    //portp interrupt enable register
#define     PIFJ		_IO8(0x26f)    //portp interrupt flag register

#define     PT1AD0     _IO8(0x271)    //Port AD0 Data Register 1
#define     DDR1AD0    _IO8(0x273)    // Port AD0 Data Direction Register 1
#define     RDR1AD0    _IO8(0x275)    //Port AD0 Reduced Drive Register 1
#define     PER1AD0    _IO8(0x277)    //Port AD0 Pull Up enable Register 1

#define     PT01AD1    _IO16(0x278)   //Port AD1 Data Register
#define     PT0AD1     _IO8(0x278)    //Port AD1 Data Register 0
#define     PT1AD1     _IO8(0x279)    //Port AD1 Data Register 1
#define     DDR01AD1   _IO16(0x27A)   // Port AD1 Data Direction Register
#define     DDR0AD1    _IO8(0x27A)    // Port AD1 Data Direction Register 0
#define     DDR1AD1    _IO8(0x27B)    // Port AD1 Data Direction Register 1
#define     RDR01AD1   _IO16(0x27C)   //Port AD1 Reduced Drive Register
#define     RDR0AD1    _IO8(0x27C)    //Port AD1 Reduced Drive Register 0
#define     RDR1AD1    _IO8(0x27D)    //Port AD1 Reduced Drive Register 1
#define     PER01AD1   _IO16(0x27E)   //Port AD1 Pull Up Enable Register
#define     PER0AD1    _IO8(0x27E)   //Port AD1 Pull Up Enable Register 0
#define     PER1AD1    _IO8(0x27F)   //Port AD1 Pull Up Enable Register 1

#define     CAN4CTL0	_IO8(0x280)    //can4 control register 0
#define     CAN4CTL1	_IO8(0x281)    //can4 control register 1
#define     CAN4BTR0	_IO8(0x282)    //can4 bus timing register 0
#define     CAN4BTR1	_IO8(0x283)    //can4 bus timing register 1
#define     CAN4RFLG	_IO8(0x284)    //can4 receiver flags
#define     CAN4RIER	_IO8(0x285)    //can4 receiver interrupt enables
#define     CAN4TFLG	_IO8(0x286)    //can4 transmit flags
#define     CAN4TIER	_IO8(0x287)    //can4 transmit interrupt enables
#define     CAN4TARQ	_IO8(0x288)    //can4 transmit message abort control
#define     CAN4TAAK	_IO8(0x289)    //can4 transmit message abort status
#define     CAN4TBSEL	_IO8(0x28a)    //can4 transmit buffer select
#define     CAN4IDAC	_IO8(0x28b)    //can4 identfier acceptance control
#define     CAN4MISC   _IO8(0x28d)    //can4 miscellaneous Register
#define     CAN4RXERR	_IO8(0x28e)    //can4 receive error counter
#define     CAN4TXERR	_IO8(0x28f)    //can4 transmit error counter
#define     CAN4IDAR0	_IO8(0x290)    //can4 identifier acceptance register 0
#define     CAN4IDAR1	_IO8(0x291)    //can4 identifier acceptance register 1
#define     CAN4IDAR2	_IO8(0x292)    //can4 identifier acceptance register 2
#define     CAN4IDAR3	_IO8(0x293)    //can4 identifier acceptance register 3
#define     CAN4IDMR0	_IO8(0x294)    //can4 identifier mask register 0
#define     CAN4IDMR1	_IO8(0x295)    //can4 identifier mask register 1
#define     CAN4IDMR2	_IO8(0x296)    //can4 identifier mask register 2
#define     CAN4IDMR3	_IO8(0x297)    //can4 identifier mask register 3
#define     CAN4IDAR4	_IO8(0x298)    //can4 identifier acceptance register 4
#define     CAN4IDAR5	_IO8(0x299)    //can4 identifier acceptance register 5
#define     CAN4IDAR6	_IO8(0x29a)    //can4 identifier acceptance register 6
#define     CAN4IDAR7	_IO8(0x29b)    //can4 identifier acceptance register 7
#define     CAN4IDMR4	_IO8(0x29c)    //can4 identifier mask register 4
#define     CAN4IDMR5	_IO8(0x29d)    //can4 identifier mask register 5
#define     CAN4IDMR6	_IO8(0x29e)    //can4 identifier mask register 6
#define     CAN4IDMR7	_IO8(0x29f)    //can4 identifier mask register 7
#define     CAN4RXIDR0	_IO8(0x2a0)    //can4 Receiver Identifier Register 0
#define     CAN4RXIDR1	_IO8(0x2a1)    //can4 Receiver Identifier Register 1
#define     CAN4RXIDR2	_IO8(0x2a2)    //can4 Receiver Identifier Register 2
#define     CAN4RXIDR3	_IO8(0x2a3)    //can4 Receiver Identifier Register 3
#define     CAN4RXDSR0 _IO8(0x2a4)    //can4 Receiver Data Segment Register 0
#define     CAN4RXDSR1 _IO8(0x2a5)    //can4 Receiver Data Segment Register 1
#define     CAN4RXDSR2 _IO8(0x2A6)    //can4 Receiver Data Segment Register 2
#define     CAN4RXDSR3 _IO8(0x2A7)    //can4 Receiver Data Segment Register 3
#define     CAN4RXDSR4 _IO8(0x2A8)    //can4 Receiver Data Segment Register 4
#define     CAN4RXDSR5 _IO8(0x2A9)    //can4 Receiver Data Segment Register 5
#define     CAN4RXDSR6 _IO8(0x2AA)    //can4 Receiver Data Segment Register 6
#define     CAN4RXDSR7 _IO8(0x2AB)    //can4 Receiver Data Segment Register 7
#define     CAN4RXDLR  _IO8(0x2AC)    //can4 Receiver Data Length Register
#define     CAN4RXTSR  _IO16(0x2AE)   //can4 Receiver Time Stamp Register
#define     CAN4RXTSRH _IO16(0x2AE)   //can4 Receiver Time Stamp Register high
#define     CAN4RXTSRL _IO16(0x2AF)   //can4 Receiver Time Stamp Register low
#define     CAN4TXIDR0	_IO8(0x2b0)    //can4 tx Identifier Register 0
#define     CAN4TXIDR1	_IO8(0x2b1)    //can4 tx Identifier Register 1
#define     CAN4TXIDR2	_IO8(0x2b2)    //can4 tx Identifier Register 2
#define     CAN4TXIDR3	_IO8(0x2b3)    //can4 tx Identifier Register 3
#define     CAN4TXDSR0 _IO8(0x2b4)    //can4 tx Data Segment Register 0
#define     CAN4TXDSR1 _IO8(0x2b5)    //can4 tx Data Segment Register 1
#define     CAN4TXDSR2 _IO8(0x2b6)    //can4 tx Data Segment Register 2
#define     CAN4TXDSR3 _IO8(0x2b7)    //can4 tx Data Segment Register 3
#define     CAN4TXDSR4 _IO8(0x2b8)    //can4 tx Data Segment Register 4
#define     CAN4TXDSR5 _IO8(0x2b9)    //can4 tx Data Segment Register 5
#define     CAN4TXDSR6 _IO8(0x2ba)    //can4 tx Data Segment Register 6
#define     CAN4TXDSR7 _IO8(0x2bb)    //can4 tx Data Segment Register 7
#define     CAN4TXDLR  _IO8(0x2bC)    //can4 tx Data Length Register
#define     CAN4TXTBPR _IO8(0x2bD)    //can4 tx Buffer Priority Register
#define     CAN4TXTSR  _IO16(0x2bE)   //can4 tx Time Stamp Register
#define     CAN4TXTSRH _IO16(0x2bE)   //can4 tx Time Stamp Register high
#define     CAN4TXTSRL _IO16(0x2bF)   //can4 tx Time Stamp Register low

#define     ATD0CTL0     _IO8(0x2C0)     //adc 0 control 0
#define     ATD0CTL1     _IO8(0x2C1)     //adc 0 control 1
#define     ATD0CTL2     _IO8(0x2C2)     //adc 0 control 2
#define     ATD0CTL3     _IO8(0x2C3)     //adc 0 control 3
#define     ATD0CTL4     _IO8(0x2C4)     //adc 0 control 4
#define     ATD0CTL5     _IO8(0x2C5)     //adc 0 control 5
#define     ATD0STAT0    _IO8(0x2C6)     //adc 0 status register 0
#define     ATD0STAT     _IO16(0x2C6)    //adc 0 status register 0 - added by Navid
#define     ATD0TEST1    _IO8(0x2C9)     //adc 0 test
#define     ATD0STAT1    _IO8(0x2Cb)     //adc 0 status register 1
#define     ATD0DIEN     _IO8(0x2Cd)
#define     ATD0PTAD0    _IO8(0x2Cf)      //adc 0 Port AD1 Register
#define     ATD0DR0      _IO16(0x2D0)    //adc 0 result 0 register
#define     ATD0DR0H     _IO8(0x2D0)    //adc 0 result 0 register
#define     ATD0DR0L     _IO8(0x2D1)    //adc 0 result 0 register
#define     ATD0DR1      _IO16(0x2D2)    //adc 0 result 1 register
#define     ATD0DR1H     _IO8(0x2D2)    //adc 0 result 1 register
#define     ATD0DR1L     _IO8(0x2D3)    //adc 0 result 1 register
#define     ATD0DR2      _IO16(0x2D4)    //adc 0 result 2 register
#define     ATD0DR2H     _IO8(0x2D4)    //adc 0 result 2 register
#define     ATD0DR2L     _IO8(0x2D5)    //adc 0 result 2 register
#define     ATD0DR3      _IO16(0x2D6)    //adc0 result 3 register
#define     ATD0DR3H     _IO8(0x2D6)    //adc 0 result 3 register
#define     ATD0DR3L     _IO8(0x2D7)    //adc0 result 3 register
#define     ATD0DR4      _IO16(0x2D8)    //adc0 result 4 register
#define     ATD0DR4H     _IO8(0x2D9)    //adc0 result 4 register
#define     ATD0DR4L     _IO8(0x2DA)    //adc0 result 4 register
#define     ATD0DR5      _IO16(0x2Da)    //adc0 result 5 register
#define     ATD0DR5H     _IO8(0x2Da)    //adc0 result 5 register
#define     ATD0DR5L     _IO8(0x2Db)    //adc0 result 5 register
#define     ATD0DR6      _IO16(0x2Dc)    //adc0 result 6 register
#define     ATD0DR6H     _IO8(0x2Dc)    //adc0 result 6 register
#define     ATD0DR6L     _IO8(0x2DD)    //adc0 result 6 register
#define     ATD0DR7      _IO16(0x2De)    //adc0 result 7 register
#define     ATD0DR7H     _IO8(0x2De)    //adc0 result 7 register
#define     ATD0DR7L     _IO8(0x2Df)    //adc0 result 7 register

#define     VREGCTRL     _IO8(0x2F1)    // VREG_3V3 Control Register
#define     VREGAPICL    _IO8(0x2F2)    // VREG_3V3 - Autonomous Periodical Interrupt Control Register
#define     VREGAPITR    _IO8(0x2F3)    // VREG_3V3 - Autonomous Periodical Interrupt Trimming Register
#define     VREGAPIR     _IO8(0x2F4)    // VREG_3V3 - Autonomous Periodical Interrupt Rate Register
#define     VREGAPIRH    _IO8(0x2F4)    // VREG_3V3 - Autonomous Periodical Interrupt Rate Register High
#define     VREGAPIRL    _IO8(0x2F5)    // VREG_3V3 - Autonomous Periodical Interrupt Rate Register Low

#define     PWME		  _IO8(0x300)     //pwm enable
#define     PWMPOL       _IO8(0x301)     //pwm polarity
#define     PWMCLK       _IO8(0x302)     //pwm clock select register
#define     PWMPRCLK     _IO8(0x303)     //pwm prescale clock select register
#define     PWMCAE       _IO8(0x304)     //pwm center align select register
#define     PWMCTL       _IO8(0x305)     //pwm control register
#define     PWMTST       _IO8(0x306)     //reserved
#define     PWMPRSC      _IO8(0x307)     //reserved
#define     PWMSCLA      _IO8(0x308)     //pwm scale a
#define     PWMSCLB      _IO8(0x309)     //pwm scale b
#define     PWMSCNTA     _IO8(0x30a)     //reserved
#define     PWMSCNTB     _IO8(0x30b)     //reserved
#define     PWMCNT0      _IO8(0x30c)     //pwm channel 0 counter
#define     PWMCNT1      _IO8(0x30d)     //pwm channel 1 counter
#define     PWMCNT2      _IO8(0x30e)     //pwm channel 2 counter
#define     PWMCNT3      _IO8(0x30f)     //pwm channel 3 counter
#define     PWMCNT4      _IO8(0x310)     //pwm channel 4 counter
#define     PWMCNT5      _IO8(0x311)     //pwm channel 5 counter
#define     PWMCNT6      _IO8(0x312)     //pwm channel 6 counter
#define     PWMCNT7      _IO8(0x313)     //pwm channel 7 counter
#define     PWMPER0      _IO8(0x314)     //pwm channel 0 period
#define     PWMPER1      _IO8(0x315)     //pwm channel 1 period
#define     PWMPER2      _IO8(0x316)     //pwm channel 2 period
#define     PWMPER3      _IO8(0x317)     //pwm channel 3 period
#define     PWMPER4      _IO8(0x318)     //pwm channel 4 period
#define     PWMPER5      _IO8(0x319)     //pwm channel 5 period
#define     PWMPER6      _IO8(0x31a)     //pwm channel 6 period
#define     PWMPER7      _IO8(0x31b)     //pwm channel 7 period
#define     PWMDTY0      _IO8(0x31c)     //pwm channel 0 duty cycle
#define     PWMDTY1      _IO8(0x31d)     //pwm channel 1 duty cycle
#define     PWMDTY2      _IO8(0x31e)     //pwm channel 2 duty cycle
#define     PWMDTY3      _IO8(0x31f)     //pwm channel 3 duty cycle
#define     PWMDTY4      _IO8(0x320)     //pwm channel 0 duty cycle
#define     PWMDTY5      _IO8(0x321)     //pwm channel 1 duty cycle
#define     PWMDTY6      _IO8(0x322)     //pwm channel 2 duty cycle
#define     PWMDTY7      _IO8(0x323)     //pwm channel 3 duty cycle
#define     PWMSDN       _IO8(0x324)     //pwm shutdown register

#define     PITCFLMT     _IO8(0x340)     //PIT Control and Force Load Micro Timer Register
#define     PITFLT       _IO8(0x341)     //PIT Force Load Timer Register
#define     PITCE        _IO8(0x342)     //PIT Channel Enable Register
#define     PITMUX       _IO8(0x343)     //PIT Multiplex Register
#define     PITINTE      _IO8(0x344)     //PIT Interrupt Enable Register
#define     PITTF        _IO8(0x345)     //PIT Time-out Flag Register
#define     PITMTLD0     _IO8(0x346)     //PIT Micro Timer Load Register 0
#define     PITMTLD1     _IO8(0x347)     //PIT Micro Timer Load Register 1
#define     PITLD0       _IO16(0x348)     //PIT Load Register 0
#define     PITCNT0      _IO16(0x34A)     //PIT Count Register 0
#define     PITLD1       _IO16(0x34C)     //PIT Load Register 1
#define     PITCNT1      _IO16(0x34E)     //PIT Count Register 1
#define     PITLD2       _IO16(0x350)     //PIT Load Register 2
#define     PITCNT2      _IO16(0x352)     //PIT Count Register 2
#define     PITLD3       _IO16(0x354)     //PIT Load Register 3
#define     PITCNT3      _IO16(0x356)     //PIT Count Register 3

#define     XGMCTL       _IO16(0x380)     //XGATE Module Control Register
#define     XGCHID       _IO8(0x382)      //XGATE Channel ID Register
#define     XGVBR        _IO16(0x386)     //XGATE Vector Base Address Register
#define     XGIF0        _IO16(0x388)     //XGATE Channel Interrupt Flag Vector 0
#define     XGIF1        _IO16(0x38A)     //XGATE Channel Interrupt Flag Vector 1
#define     XGIF2        _IO16(0x38C)     //XGATE Channel Interrupt Flag Vector 2
#define     XGIF3        _IO16(0x38E)     //XGATE Channel Interrupt Flag Vector 3
#define     XGIF4        _IO16(0x390)     //XGATE Channel Interrupt Flag Vector 4
#define     XGIF5        _IO16(0x392)     //XGATE Channel Interrupt Flag Vector 5
#define     XGIF6        _IO16(0x394)     //XGATE Channel Interrupt Flag Vector 6
#define     XGIF7        _IO16(0x396)     //XGATE Channel Interrupt Flag Vector 7
#define     XGSWT        _IO16(0x398)     //XGATE Software Trigger Register
#define     XGSEM        _IO16(0x39A)     //XGATE Semaphore Register
#define     XGPC         _IO16(0x39E)     //XGATE Program Counter Register
#define     XGR1         _IO16(0x3A2)     //XGATE Register 1
#define     XGR2         _IO16(0x3A4)     //XGATE Register 2
#define     XGR3         _IO16(0x3A6)     //XGATE Register 3
#define     XGR4         _IO16(0x3A8)     //XGATE Register 4
#define     XGR5         _IO16(0x3AA)     //XGATE Register 5
#define     XGR6         _IO16(0x3AC)     //XGATE Register 6
#define     XGR7         _IO16(0x3AE)     //XGATE Register 7

#define     BAKEY0       _IO16(0xFF00)    //Flash Backdoor Access Key 0
#define     BAKEY1       _IO16(0xFF02)    //Flash Backdoor Access Key 1
#define     BAKEY2       _IO16(0xFF04)    //Flash Backdoor Access Key 2
#define     BAKEY3       _IO16(0xFF06)    //Flash Backdoor Access Key 3
#define     NVFPROT      _IO8(0xFF0D)     //Flash Non volatile Flash Protection Register
#define     NVFSEC       _IO8(0xFF0F)     //Flash Non volatile Flash Security Register

////same as above -- added by Navid
//#define  PORTAD     _IO8(0x8f)
//#define  ADR00H     _IO8(0x90)
//#define  ADR01H     _IO8(0x92)
//#define  ADR02H     _IO8(0x94)
//#define  ADR03H     _IO8(0x96)
//#define  ADR04H     _IO8(0x98)
//#define  ADR05H     _IO8(0x9a)
//#define  ADR06H     _IO8(0x9c)
//#define  ADR07H     _IO8(0x9e)
//
//
//#define     IBAD		_IO8(0xe0)     //i2c bus address register
//#define     IBFD		_IO8(0xe1)     //i2c bus frequency divider
//#define     IBCR		_IO8(0xe2)     //i2c bus control register
//#define     IBSR		_IO8(0xe3)     //i2c bus status register
//#define     IBDR	    	_IO8(0xe4)     //i2c bus message data register
//
//#define     DLCBCR1      _IO8(0xe8)     //bdlc control regsiter 1
//#define     DLCBSVR	     _IO8(0xe9)     //bdlc state vector register
//#define     DLCBCR2	     _IO8(0xea)     //bdlc control register 2
//#define     DLCBDR	  	_IO8(0xeb)     //bdlc data register
//#define     DLCBARD	     _IO8(0xec)     //bdlc analog delay register
//#define     DLCBRSR	     _IO8(0xed)     //bdlc rate select register
//#define     DLCSCR		_IO8(0xee)     //bdlc control register
//#define     DLCBSTAT	_IO8(0xef)     //bdlc status register



/*end of registers */

/* definitions of bits */
#define     BIT7         0x80
#define     BIT6         0x40
#define     BIT5         0x20
#define     BIT4         0x10
#define     BIT3         0x08
#define     BIT2         0x04
#define     BIT1         0x02
#define     BIT0         0x01
#define     NOACCE       0x80
#define     PIPOE        0x20
#define     NECLK        0x10
#define     LSTRE        0x08
#define     RDWE         0x04
#define     MODC         0x80
#define     MODB         0x40
#define     MODA         0x20
#define     IVIS         0x08
#define     EMK          0x02
#define     EME          0x01
#define     PUPKE        0x80
#define     PUPEE        0x10
#define     PUPBE        0x02
#define     PUPAE        0x01
#define     RDPK         0x80
#define     RDPE         0x10
#define     RDPB         0x02
#define     RDPA         0x01
#define     ESTR         0x01
#define     EXSTR1       0x08
#define     EXSTR0       0x04
#define     ROMHM        0x02
#define     ROMON        0x01
#define     WRINT        0x10
#define     INTE         0x80
#define     INTC         0x40
#define     INTA         0x20
#define     INT8         0x10
#define     INT6         0x08
#define     INT4         0x04
#define     INT2         0x02
#define     INT0         0x01
#define     IRQE         0x80
#define     IRQEN        0x40
#define     BKEN         0x80
#define     BKFULL       0x40
#define     BKBDM        0x20
#define     BKTAG        0x10
#define     BK0RWE       0x08
#define     BK0RW        0x04
#define     BK1RWE       0x02
#define     BK1RW        0x01
#define     RTIF         0x80
#define     PROF         0x40
#define     LOCKIF       0x10
#define     LOCK         0x08
#define     TRACK        0x04
#define     SCMIF        0x02
#define     SCM          0x01
#define     RTIE         0x80
#define     LOCKIE       0x10
#define     SCMIE        0x02
#define     PLLSEL       0x80
#define     PSTP         0x40
#define     SYSWAI       0x20
#define     ROAWAI       0x10
#define     PLLWAI       0x08
#define     CWAI         0x04
#define     RTIWAI       0x02
#define     COPWAI       0x01
#define     CME          0x80
#define     PLLON        0x40
#define     AUTO         0x20
#define     ACQ          0x10
#define     PRE          0x04
#define     PCE          0x02
#define     SCME         0x01
#define     WCOP         0x80
#define     RSBCK        0x40
#define     RTIBYP       0x80
#define     COPBYP       0x40
#define     PLLBYP       0x10
#define     FCM          0x02
#define     TEN          0x80
#define     TSWAI        0x40
#define     TSFRZ        0x20
#define     TFFCA        0x10
#define     TOI          0x80           ; TCNT overflow interrupt enable
#define     TOF          0x80           ; TCNT overflow flag
#define     C7I          0x80
#define     C6I          0x40
#define     C5I          0x20
#define     C4I          0x10
#define     C3I          0x08
#define     C2I          0x04
#define     C1I          0x02
#define     C0I          0x01
#define     C7F          0x80
#define     C6F          0x40
#define     C5F          0x20
#define     C4F          0x10
#define     C3F          0x08
#define     C2F          0x04
#define     C1F          0x02
#define     C0F          0x01
#define     TCRE         0x08
#define     PAEN         0x40
#define     PAMOD        0x20
#define     PEDGE        0x10
#define     CLK1         0x08
#define     CLK0         0x04
#define     PAOVI        0x02
#define     PAI          0x01
#define     PAOVF        0x02
#define     PAIF         0x01
#define     MCZI         0x80
#define     MODMC        0x40
#define     RDMCL        0x20
#define     ICLAT        0x10
#define     FLMC         0x08
#define     MCEN         0x04
#define     MCPR1        0x02
#define     MCPR0        0x01
#define     MCZF         0x80
#define     POLF3        0x08
#define     POLF2        0x04
#define     POLF1        0x02
#define     POLF0        0x01
#define     PAEN3        0x08
#define     PAEN2        0x04
#define     PAEN1        0x02
#define     PAEN0        0x01
#define     TFMOD        0x08
#define     PACMX        0x04
#define     BUFEN        0x02
#define     LATQ         0x01
#define     TCBYP        0x02
#define     PBEN         0x40
#define     PBOVI        0x02
#define     PBOVF        0x02
#define     ADPU         0x80
#define     AFFC         0x40
#define     AWAI         0x20
#define     ETRIGLE      0x10
#define     ETRIGP       0x08
#define     ETRIG        0x04
#define     ASCIE        0x02
#define     ASCIF        0x01
#define     SCF          0x80
#define     ETORF        0x20
#define     FIFOR        0x10
#define     CON67        0x80
#define     CON45        0x40
#define     CON23        0x20
#define     CON01        0x10
#define     PSWAI        0x08
#define     PFRZ         0x04
#define     PWMIF        0x80
#define     PWMIE        0x40
#define     PWMRSTRT     0x20
#define     PWMLVL       0x10
#define     PWM7IN       0x04
#define     PWM7INL      0x02
#define     PWM7ENA      0x01
#define     TIEN         0x80   /* changed to TIEN to avoid duplication with the register TIE */
#define     TCIE         0x40
#define     RIE          0x20
#define     ILIE         0x10
#define     TE           0x08
#define     RE           0x04
#define     RWU          0x02
#define     SBK          0x01
#define     TDRE         0x80
#define     TC           0x40
#define     RDRF         0x20
#define     IDLE         0x10
#define     OR           0x08
#define     NF           0x04
#define     FE           0x02
#define     PF           0x01
#define     BRK13        0x04
#define     TXDIR        0x02
#define     RAF          0x01
#define     R8           0x80
#define     T8           0x40
#define     SPIF         0x80
#define     SPTEF        0x20
#define     MODF         0x10
#define     IBEN         0x80
#define     IBIE         0x40
#define     TXAK         0x08
#define     RSTA         0x04
#define     IBSWAI       0x01
#define     TCF          0x80
#define     IAAS         0x40
#define     IBB          0x20
#define     IBAL         0x10
#define     SRW          0x04
#define     IBIF         0x02
#define     RXAK         0x01
#define     IMSG         0x80
#define     CLKS         0x40
#define     IE           0x02
#define     WCM          0x01
#define     BDLCE        0x10
#define     BIDLE        0x01           /* idle bit of BDLC */
#define     WUPIF        0x80
#define     CSCIF        0x40
#define     RSTAT1       0x20
#define     RSTAT0       0x10
#define     TSTAT1       0x08
#define     TSTAT0       0x04
#define     OVRIF        0x02
#define     RXF          0x01
#define     WUPIE        0x80
#define     CSCIE        0x40
#define     RSTATE1      0x20
#define     RSTATE0      0x10
#define     TSTATE1      0x08
#define     TSTATE0      0x04
#define     OVRIE        0x02
#define     RXFIE        0x01
#define     TXE2         0x04
#define     TXE1         0x02
#define     TXE0         0x01
#define     TXEIE2       0x04
#define     TXEIE1       0x02
#define     TXEIE0       0x01
#define     TX2          0x04
#define     TX1          0x02
#define     TX0          0x01
/* end of bit definitions for 9s12DP256b */
#include <vectors12xdp.h>

#endif
