/*
 * AMBA-PV: amba_pv_unordered_map.h - Includes unordered_map class header in a
 *                                    controlled manner.
 *
 * Copyright 2014 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_UNORDERED_MAP__H
#define AMBA_PV_UNORDERED_MAP__H

/**
 * @file        amba_pv_unordered_map.h
 *
 * @brief       Includes unordered_map class header in a controlled manner.
 *
 *  The template class std::unordered_map<K, T> is a C++ (TR1 extension)
 *  collection that controls a varying-length sequence of elements of type
 *  std::pair<const K, T>.
 *  The sequence is weakly ordered by a hash function.
 *
 *  This class is available with both Visual Studio and GCC, but via possibly
 *  different headers.
 *
 *  This file is not part of a stable public API and it may
 *  change without notice.
 */

/* Includes */
#if defined(_MSC_VER)
    #include <unordered_map>
    #if ! defined(_HAS_CPP0X)
        /* Ensure unordered_map<> comes into the std namespace. */
        namespace std {
            using tr1::unordered_map;
        }
    #endif
#elif __GNUC__ >= 4
    #if defined(__GXX_EXPERIMENTAL_CXX0X__) || __cplusplus >= 201103L
        #include <unordered_map>
    #else
        #include <tr1/unordered_map>

        namespace std {
        #if __GNUC__ == 4 && __GNUC_MINOR__ < 4
            /* GCC 4.1.2 seems to lack (unsigned) long long version of
             * std::tr1:hash<>. */
            namespace tr1 {
                template<>
                struct hash<long long>:
                    public std::unary_function<long long, std::size_t> {
                    std::size_t
                    operator()(long long val) const {
                        return static_cast<std::size_t>(val);
                    }
                };
                template<>
                struct hash<unsigned long long>:
                    public std::unary_function<unsigned long long,
                                               std::size_t> {
                    std::size_t
                    operator()(unsigned long long val) const {
                        return static_cast<std::size_t>(val);
                    }
                };
            }
        #endif
            /* Ensure unordered_map<> comes into the std namespace. */
            using tr1::unordered_map;
        }
    #endif
#else
    #error "Unsupported Compiler"
#endif

#endif  /* defined(AMBA_PV_UNORDERED_MAP__H) */
