/*
 * AMBA-PV: amba_pv.h - AMBA-PV main header file.
 *
 * Copyright 2007-2014 ARM Limited.
 * All rights reserved.
 */

/*
 * This file has been patched by Synopsys to force the selection of the
 * hierarchically bindable socket classes that are declared in the amba_pv::ext
 * namespace but appear in the amba_pv namespace due to the 'using namespace ext'
 * statement in amba_pv.h. It is expected that the hierarchically-bindable sockets
 * will become the standard definition, at which time the selectable behaviour
 * in the original version of this file will be removed. This patch anticipates
 * that update and aims to be compatible with future AMBA-PV versions.
 * Compatibility with future versions cannot, however, be guaranteed.
 *
 * The original behaviour of this header can be restored by defining the compiler
 * macro SNPS_DISABLE_AMBAPV_PATCHES. This is likely to lead to incompatibilities
 * with pre-built model libraries and is not recommended.
 */

#ifndef AMBA_PV__H
#define AMBA_PV__H

/**
 * @file        amba_pv.h
 *
 * @brief       AMBA-PV main header file.
 */

/* Defines */

/* The current implementation of AMBA-PV<->TLM bridges make use of TLM 2.0 convenience sockets.
 * Hence, when compiling applications that use AMBA-PV <->TLM bridges with SystemC, it is necessary to define the macro
 * SC_INCLUDE_DYNAMIC_PROCESSES before including the SystemC header file.
 */
#if ! defined(SC_INCLUDE_DYNAMIC_PROCESSES)
#if defined(SYSTEMC_INCLUDED)
#error "SC_INCLUDE_DYNAMIC_PROCESSES must be defined before #include <systemc>"
#else
#define SC_INCLUDE_DYNAMIC_PROCESSES
#endif
#endif

#if ! defined(SNPS_DISABLE_AMBAPV_PATCHES)
#if ! defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING)
#define AMBA_PV_INCLUDE_HIERARCHICAL_BINDING
#endif
#endif

 /* Includes */
#include <systemc>
using sc_core::SC_ID_ASSERTION_FAILED_; /* sc_assert() misses sc_core:: */
#include <tlm.h>

/* Version definitions */
#include "amba_pv_ver.h"

/* Utilities-related includes */
#include "utils/amba_pv_unordered_map.h"

/* TLM extension-related includes */
#include "tlmx/tlmx_bw_ifs.h"
#include "tlmx/tlmx_initiator_socket.h"
#include "tlmx/tlmx_target_socket.h"

/* Bus-related includes */
#include "bus/amba_pv_control.h"
#include "bus/amba_pv_attributes.h"
#include "bus/amba_pv_extension.h"

/* Core interfaces-related includes */
#include "core/amba_pv_types.h"
#if ! defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING)
#include "core/amba_pv_core_ifs.h"
#else
#include "core/amba_pv_ext_core_ifs.h"
#endif  /* defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING) */

#if defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING)
namespace amba_pv {
    using namespace ext;
}
#endif  /* defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING) */

/* User-related includes */
#include "user/amba_pv_if.h"
#if ! defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING)
#include "user/amba_pv_slave_base.h"
#include "user/amba_pv_master_base.h"
#include "user/amba_pv_ace_master_base.h"
#else
#include "user/amba_pv_ext_slave_base.h"
#include "user/amba_pv_ext_master_base.h"
#include "user/amba_pv_ext_ace_slave_base.h"
#include "user/amba_pv_ext_ace_master_base.h"
#endif  /* defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING) */
#include "user/amba_pv_mm.h"

/* Sockets-related includes */
#include "sockets/amba_pv_socket_base.h"
#include "sockets/amba_pv_socket_array.h"
#if ! defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING)
#include "sockets/amba_pv_master_socket.h"
#include "sockets/amba_pv_slave_socket.h"
#include "sockets/amba_pv_ace_master_socket.h"
#include "sockets/amba_pv_ace_slave_socket.h"
#else
#include "sockets/amba_pv_ext_master_socket.h"
#include "sockets/amba_pv_ext_slave_socket.h"
#include "sockets/amba_pv_ext_ace_master_socket.h"
#include "sockets/amba_pv_ext_ace_slave_socket.h"
#endif  /* defined(AMBA_PV_INCLUDE_HIERARCHICAL_BINDING) */

/* Signal-related includes */
#include "signal/signal_core_ifs.h"
#include "signal/signal_master_port.h"
#include "signal/signal_slave_export.h"
#include "signal/signal_if.h"
#include "signal/signal_slave_base.h"
#include "signal/signal_bridges.h"

/* Models-related includes */
#include "models/amba_pv_bridges.h"
#include "models/amba_pv_exclusive_monitor.h"
#include "models/amba_pv_memory_base.h"
#include "models/amba_pv_simple_memory.h"
#include "models/amba_pv_memory.h"
#include "models/amba_pv_address_map.h"
#include "models/amba_pv_decoder.h"
#include "models/amba_pv_simple_probe_base.h"
#include "models/amba_pv_simple_probe.h"
#include "models/amba_pv_ace_simple_probe.h"
#include "models/amba_pv_protocol_checker_base.h"
#include "models/amba_pv_protocol_checker.h"
#include "models/amba_pv_ace_protocol_checker.h"

#if ! defined(SNPS_DISABLE_AMBAPV_PATCHES)
#if defined(CWR_SYSTEMC)
/* Define specializations of tlm_base_initiator_socket and tlm_base_target_socket for
** AMBA-PV protocol types which support the TLM tracing IPT */
#include "../../include/cwrambapv_tracing_master.hpp"
#include "../../include/cwrambapv_tracing_slave.hpp"
#endif
#endif

#endif  /* defined(AMBA_PV__H) */
