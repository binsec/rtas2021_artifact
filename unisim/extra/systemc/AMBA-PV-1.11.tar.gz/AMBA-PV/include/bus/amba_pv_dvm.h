/*
 * AMBA-PV: amba_pv_dvm.h - AMBA-PV additional information for DVM messages.
 *
 * Copyright 2007-2009 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_DVM__H
#define AMBA_PV_DVM__H

/**
 * @file        amba_pv_dvm.h
 *
 * @brief       AMBA-PV additional information for DVM messages.
 */

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief     DVM Message type.
 *
 * The bit representation of this type matches the encoding of the DVM message type field
 * in the AxADDR AMBA4 signal.
 *
 * @see       amba_pv_dvm, amba_pv_dvm_os_t, amba_pv_dvm_security_t, amba_pv_dvm_stage_t
 */
enum amba_pv_dvm_message_t {
    AMBA_PV_TLB_INVALIDATE                        = 0x0, /**< TLB invalidate */
    AMBA_PV_BRANCH_PREDICTOR_INVALIDATE           = 0x1, /**< Branch predictor invalidate */
    AMBA_PV_PHYSICAL_INSTRUCTION_CACHE_INVALIDATE = 0x2, /**< Physical instruction cache invalidate */
    AMBA_PV_VIRTUAL_INSTRUCTION_CACHE_INVALIDATE  = 0x3, /**< Virtual instruction cache invalidate */
    AMBA_PV_SYNC                                  = 0x4, /**< Synchronisation message */
    AMBA_PV_HINT                                  = 0x6  /**< Reserved message type for future Hint messages */
};


/**
 * @brief     DVM message Guest OS or hypervisor type.
 *
 * The bit representation of this type matches the encoding of the DVM guest OS or 
 * hypervisor field in the AxADDR AMBA4 signal.
 *
 * @see       amba_pv_dvm, amba_pv_dvm_message_t, amba_pv_dvm_security_t, amba_pv_dvm_stage_t
 */
enum amba_pv_dvm_os_t {
    AMBA_PV_HYPERVISOR_OR_GUEST = 0x0, /**< Transaction applies to hypervisor and all Guest OS*/
    AMBA_PV_EL3                 = 0x1, /**< Transaction applies to EL3 */
    AMBA_PV_GUEST               = 0x2, /**< Transaction applies to Guest OS */
    AMBA_PV_HYPERVISOR          = 0x3  /**< Transaction applies to hypervisor */
};


/**
 * @brief     DVM message security type.
 *
 * The bit representation of this type matches the encoding of the DVM security field
 * in the AxADDR AMBA4 signal.
 *
 * @see       amba_pv_dvm, amba_pv_dvm_message_t, amba_pv_dvm_os_t, amba_pv_dvm_stage_t
 */
enum amba_pv_dvm_security_t {
    AMBA_PV_SECURE_AND_NON_SECURE = 0x0, /**< Transaction applies to Secure and Non-secure */
    AMBA_PV_SECURE_ONLY           = 0x2, /**< Transaction applies to Secure only */
    AMBA_PV_NON_SECURE_ONLY       = 0x3  /**< Transaction applies to Non-secure only */
};


/**
 * @brief     DVM message Staged Invalidation.
 *
 * The bit representation of this type matches the encoding of the DVM Staged
 * Invalidation field in the AxADDR AMBA4 signal.
 *
 * @see       amba_pv_dvm, amba_pv_dvm_message_t, amba_pv_dvm_os_t, amba_pv_dvm_security_t, amba_pv_dvm_stage_t
 */
enum amba_pv_dvm_stage_t {
    AMBA_PV_DVM_V7       = 0x0, /**< Used for DVMv7 transactions */
    AMBA_PV_STAGE_1_ONLY = 0x1, /**< Stage 1 only invalidation required */
    AMBA_PV_STAGE_2_ONLY = 0x2  /**< Stage 2 only invalidation required */
};

/**
 * @brief    Provides DVM message information used by the AMBA ACE buses.
 *
 * This class is used as a base class for the AMBA-PV extension type
 * (amba_pv_extension).
 *
 * @see         amba_pv_extension
 */
class amba_pv_dvm {

    /* Construction */
    public:
        amba_pv_dvm();

    /* Accessors */

        /* Encoded transaction(s) */
        void set_dvm_encoded_transaction(sc_dt::uint64);
        sc_dt::uint64 get_dvm_encoded_transaction() const;
        void set_dvm_encoded_additional_transaction(sc_dt::uint64);
        sc_dt::uint64 get_dvm_encoded_additional_transaction() const;
        bool has_dvm_additional_transaction() const;

        /* Address */
        void set_dvm_address(sc_dt::uint64);
        sc_dt::uint64 get_dvm_address() const;

        /* VMID */
        void set_dvm_vmid(unsigned int);
        bool is_dvm_vmid_set() const;
        unsigned int get_dvm_vmid() const;

        /* ASID */
        void set_dvm_asid(unsigned int);
        bool is_dvm_asid_set() const;
        unsigned int get_dvm_asid() const;

        /* Virtual Index */
        void set_dvm_virtual_index(unsigned int);
        bool is_dvm_virtual_index_set() const;
        unsigned int get_dvm_virtual_index() const;

        /* Message type */
        void set_dvm_message_type(amba_pv_dvm_message_t);
        amba_pv_dvm_message_t get_dvm_message_type() const;

        /* Guest OS or hypervisor */
        void set_dvm_os(amba_pv_dvm_os_t);
        amba_pv_dvm_os_t get_dvm_os() const;

        /* Security */
        void set_dvm_security(amba_pv_dvm_security_t);
        amba_pv_dvm_security_t get_dvm_security() const;

        /* Leaf Entry Invalidation */
        void set_dvm_tlb_leaf(bool);
        bool is_dvm_tlb_leaf_set() const;

        /* Staged Invalidation */
        void set_dvm_stage(amba_pv_dvm_stage_t);
        amba_pv_dvm_stage_t get_dvm_stage() const;

        /* Resetting */
        void reset();

        /* Deprecated interface */
        void set_dvm_transaction(unsigned int);
        unsigned int get_dvm_transaction() const;
        void set_dvm_additional_address(sc_dt::uint64);
        bool is_dvm_additional_address_set() const;
        sc_dt::uint64 get_dvm_additional_address() const;

    /* Implementation */
    private:
        enum {
            VMID_MASK              = 0xFF,
            VMID_LSB               = 24,
            VMID_SET               = 1<<6,
            ASID_HI_MASK           = 0xFF00,
            ASID_HI_SHIFT          = 32-8,
            ASID_LO_MASK           = 0xFF,
            ASID_LO_SHIFT          = 16,
            ASID_SET               = 1<<5,
            VIRTUAL_INDEX_MASK     = 0xFFFF,
            VIRTUAL_INDEX_LSB      = 16,
            VIRTUAL_INDEX_SET      = (1<<6) | (1<<5),
            TYPE_MASK              = 0x7,
            TYPE_LSB               = 12,
            OS_MASK                = 0x3,
            OS_LSB                 = 10,
            SECURITY_MASK          = 0x3,
            SECURITY_LSB           = 8,
            LEAF_ENTRY_ONLY        = 1<<4,
            STAGE_MASK             = 0x3,
            STAGE_LSB              = 2,
            ADDITIONAL_ADDRESS_SET = 1<<0
        };

        /* Variable members */
        sc_dt::uint64  m_dvm_encoded_transaction;
        sc_dt::uint64  m_dvm_encoded_additional_transaction;
};

/* Functions */

/**
 * @brief       Returns the text string representation of the specified 
 *              DVM message type.
 *
 * @param       message_type DVM message type 
 *
 * @return      the text string representation of @a message_type.
 */
inline std::string
amba_pv_dvm_message_string(amba_pv_dvm_message_t message_type) {
    switch (message_type) {
        case AMBA_PV_TLB_INVALIDATE:
            return "AMBA_PV_TLB_INVALIDATE";
        case AMBA_PV_BRANCH_PREDICTOR_INVALIDATE:
            return "AMBA_PV_BRANCH_PREDICTOR_INVALIDATE";
        case AMBA_PV_PHYSICAL_INSTRUCTION_CACHE_INVALIDATE:
            return "AMBA_PV_PHYSICAL_INSTRUCTION_CACHE_INVALIDATE";
        case AMBA_PV_VIRTUAL_INSTRUCTION_CACHE_INVALIDATE:
            return "AMBA_PV_VIRTUAL_INSTRUCTION_CACHE_INVALIDATE";
        case AMBA_PV_SYNC:
            return "AMBA_PV_SYNC";
        case AMBA_PV_HINT:
            return "AMBA_PV_HINT";
        default:
            return "AMBA_PV_UNKNOWN";
    };
}

/**
 * @brief       Returns the text string representation of the specified 
 *              DVM Guest OS or hypervisor type.
 *
 * @param       os DVM Guest OS or hypervisor type 
 *
 * @return      the text string representation of @a os.
 */
inline std::string
amba_pv_dvm_os_string(amba_pv_dvm_os_t os) {
    switch (os) {
        case AMBA_PV_HYPERVISOR_OR_GUEST:
            return "AMBA_PV_HYPERVISOR_OR_GUEST";
        case AMBA_PV_EL3:
            return "AMBA_PV_EL3";
        case AMBA_PV_GUEST:
            return "AMBA_PV_GUEST";
        case AMBA_PV_HYPERVISOR:
            return "AMBA_PV_HYPERVISOR";
        default:
            return "AMBA_PV_UNKNOWN";
    };
}

/**
 * @brief       Returns the text string representation of the specified 
 *              DVM security type.
 *
 * @param       security DVM security type 
 *
 * @return      the text string representation of @a security.
 */
inline std::string
amba_pv_dvm_security_string(amba_pv_dvm_security_t security) {
    switch (security) {
        case AMBA_PV_SECURE_AND_NON_SECURE:
            return "AMBA_PV_SECURE_AND_NON_SECURE";
        case AMBA_PV_SECURE_ONLY:
            return "AMBA_PV_SECURE_ONLY";
        case AMBA_PV_NON_SECURE_ONLY:
            return "AMBA_PV_NON_SECURE_ONLY";
        default:
            return "AMBA_PV_UNKNOWN";
    };
}

/**
 * @brief       Default constructor.
 */
inline
amba_pv_dvm::amba_pv_dvm():
    m_dvm_encoded_transaction(0x0),
    m_dvm_encoded_additional_transaction(0x0) {
}

/**
 * @deprecated  This method won't work with DVMv8. Use set_dvm_encoded_transaction(), instead.
 *
 * @brief       Set the encoded DVM transaction.
 *
 * @param       dvm_transaction DVM transaction, as encoded on AxADDR signal
 *
 * @see         set_dvm_encoded_transaction()
 *
 */
inline void
amba_pv_dvm::set_dvm_transaction(unsigned int dvm_transaction) {
    m_dvm_encoded_transaction = sc_dt::uint64(dvm_transaction);
}

/**
 * @deprecated  This method won't work with DVMv8. Use get_dvm_encoded_transaction(), instead.
 *
 * @brief       Return the encoded DVM transaction.
 *
 * @see         get_dvm_encoded_transaction()
 */
inline unsigned int
amba_pv_dvm::get_dvm_transaction() const {
    return unsigned(m_dvm_encoded_transaction);
}

/**
 * @deprecated  This method was used in a deprecated interface to achieve two distinct purposes. Use either set_dvm_encoded_additional_transaction() or set_dvm_address(), instead.
 *
 * @brief       Set the DVM additional address for this transaction.
 *
 * @see         set_dvm_encoded_additional_transaction(), set_dvm_address()
 */
inline void
amba_pv_dvm::set_dvm_additional_address(sc_dt::uint64 additional_address) {
    m_dvm_encoded_transaction |= ADDITIONAL_ADDRESS_SET;
    m_dvm_encoded_additional_transaction = additional_address;
}

/**
 * @deprecated  The name of this method refers to a deprecated interface. Use has_dvm_additional_transaction(), instead.
 *
 * @brief       Indicate whether there is an additional address for this DVM transaction.
 *
 * @see         has_dvm_additional_transaction()
 */
inline bool
amba_pv_dvm::is_dvm_additional_address_set() const {
    return (m_dvm_encoded_transaction & ADDITIONAL_ADDRESS_SET) != 0;
}

/**
 * @deprecated  This method was used in a deprecated interface to achieve two distinct purposes. Use either get_dvm_encoded_additional_transaction() or get_dvm_address(), instead.
 *
 * @brief       Return the DVM additional address for this transaction.
 *
 * @see         get_dvm_encoded_additional_transaction(), get_dvm_address()
 */
inline sc_dt::uint64
amba_pv_dvm::get_dvm_additional_address() const {
    return m_dvm_encoded_additional_transaction;
}

/**
 * @brief       Set the encoded DVM transaction.
 *
 * Set the DVM transaction for this DVM message, as encoded on AxADDR signal.
 *
 * @param       dvm_transaction DVM transaction, as encoded on AxADDR signal
 *
 * @see         get_dvm_encoded_transaction(), get_dvm_encoded_additional_transaction(), set_dvm_encoded_additional_transaction(), has_dvm_additional_transaction()
 */
inline void
amba_pv_dvm::set_dvm_encoded_transaction(sc_dt::uint64 dvm_transaction) {
    m_dvm_encoded_transaction = dvm_transaction;
}

/**
 * @brief       Return the encoded DVM transaction.
 *
 * Return the DVM transaction for this DVM message, as encoded on AxADDR signal.
 *
 * @see         set_dvm_encoded_transaction(), get_dvm_encoded_additional_transaction(), set_dvm_encoded_additional_transaction(), has_dvm_additional_transaction()
 */
inline sc_dt::uint64
amba_pv_dvm::get_dvm_encoded_transaction() const {
    return m_dvm_encoded_transaction;
}

/**
 * @brief       Set the encoded additional DVM transaction.
 *
 * Set the additional DVM transaction for this DVM message, as encoded on AxADDR
 * signal.
 *
 * Please note that this method does not alter the first DVM transaction for
 * this DVM message: in particular, its LSB (indicating that there is an
 * additional transaction) is not set. set_dvm_encoded_transaction() must be
 * called with the appropriate value, instead.
 *
 * @param       encoded_additional_transaction additional DVM transaction, as encoded on AxADDR signal
 *
 * @see         get_dvm_encoded_additional_transaction(), has_dvm_additional_transaction(), get_dvm_encoded_transaction(), set_dvm_encoded_transaction()
 */
inline void
amba_pv_dvm::set_dvm_encoded_additional_transaction(sc_dt::uint64 encoded_additional_transaction) {
    m_dvm_encoded_additional_transaction = encoded_additional_transaction;
}

/**
 * @brief       Return the encoded additional DVM transaction.
 *
 * Return the additional DVM transaction for this DVM message, as encoded on
 * AxADDR signal.
 *
 * @see         set_dvm_encoded_additional_transaction(), has_dvm_additional_transaction(), get_dvm_encoded_transaction(), set_dvm_encoded_transaction()
 */
inline sc_dt::uint64
amba_pv_dvm::get_dvm_encoded_additional_transaction() const {
    return m_dvm_encoded_additional_transaction;
}

/**
 * @brief       Indicate whether there is an additional transaction for this DVM message.
 *
 * @see         get_dvm_encoded_transaction(), set_dvm_encoded_transaction(), get_dvm_encoded_additional_transaction(), set_dvm_encoded_additional_transaction()
 */
inline bool
amba_pv_dvm::has_dvm_additional_transaction() const {
    return (m_dvm_encoded_transaction & ADDITIONAL_ADDRESS_SET) != 0;
}

/**
 * @brief       Set the DVM address.
 *
 * @param       address DVM address
 *
 * @see         get_dvm_address()
 */
inline void
amba_pv_dvm::set_dvm_address(sc_dt::uint64 address) {
    m_dvm_encoded_transaction |= ADDITIONAL_ADDRESS_SET;

    // address[31:4] -> m_dvm_encoded_additional_transaction[31:4]
    m_dvm_encoded_additional_transaction  = (((address >>  4) & 0xFFFFFFF) <<  4);

    // address[39:32] -> m_dvm_encoded_additional_transaction[39:32]
    m_dvm_encoded_additional_transaction |= (((address >> 32) &      0xFF) << 32);

    // address[40] -> m_dvm_encoded_additional_transaction[3]
    m_dvm_encoded_additional_transaction |= (((address >> 40) &       0x1) <<  3);

    // address[44:41] -> m_dvm_encoded_additional_transaction[43:40]
    m_dvm_encoded_additional_transaction |= (((address >> 41) &       0xF) << 40);

    // address[48:45] -> m_dvm_encoded_transaction[43:40]
    m_dvm_encoded_transaction            |= (((address >> 45) &       0xF) << 40);

    // address[52:49] -> m_dvm_encoded_additional_transaction[47:44]
    m_dvm_encoded_additional_transaction |= (((address >> 49) &       0xF) << 44);

    // address[56:53] -> m_dvm_encoded_transaction[47:44]
    m_dvm_encoded_transaction            |= (((address >> 53) &       0xF) << 44);
}

/**
 * @brief       Return the DVM address.
 *
 * @see         set_dvm_address()
 */
inline sc_dt::uint64
amba_pv_dvm::get_dvm_address() const {
    // address[31:4] <- m_dvm_encoded_additional_transaction[31:4]
    sc_dt::uint64 address = (((m_dvm_encoded_additional_transaction >>  4) & 0xFFFFFFF) <<  4);

    // address[39:32] <- m_dvm_encoded_additional_transaction[39:32]
    address              |= (((m_dvm_encoded_additional_transaction >> 32) &      0xFF) << 32);

    // address[40] <- m_dvm_encoded_additional_transaction[3]
    address              |= (((m_dvm_encoded_additional_transaction >>  3) &       0x1) << 40);

    // address[44:41] <- m_dvm_encoded_additional_transaction[43:40]
    address              |= (((m_dvm_encoded_additional_transaction >> 40) &       0xF) << 41);

    // address[48:45] <- m_dvm_encoded_transaction[43:40]
    address              |= (((m_dvm_encoded_transaction            >> 40) &       0xF) << 45);

    // address[52:49] <- m_dvm_encoded_additional_transaction[47:44]
    address              |= (((m_dvm_encoded_additional_transaction >> 44) &       0xF) << 49);

    // address[56:53] <- m_dvm_encoded_transaction[47:44]
    address              |= (((m_dvm_encoded_transaction            >> 44) &       0xF) << 53);

    return address;
}

/**
 * @brief       Set the VMID for this DVM transaction.
 *
 * @param       vmid Virtual Machine IDentifier (VMID) [0-255]
 *
 * @see         get_dvm_vmid(), is_dvm_vmid_set()
 */
inline void
amba_pv_dvm::set_dvm_vmid(unsigned int vmid) {
    m_dvm_encoded_transaction &= ~(VMID_MASK << VMID_LSB);
    m_dvm_encoded_transaction |= ((vmid & VMID_MASK) << VMID_LSB) | VMID_SET;
}

/**
 * @brief       Indicate whether there is a VMID set for this DVM transaction.
 *
 * @see         get_dvm_vmid(), set_dvm_vmid()
 */
inline bool
amba_pv_dvm::is_dvm_vmid_set() const {
    return (m_dvm_encoded_transaction & VMID_SET) != 0;
}

/**
 * @brief       Return the VMID for this DVM transaction.
 *
 * @see         set_dvm_vmid(), is_dvm_vmid_set()
 */
inline unsigned int
amba_pv_dvm::get_dvm_vmid() const {
    return (m_dvm_encoded_transaction >> VMID_LSB) & VMID_MASK;
}

/**
 * @brief       Set the ASID for this DVM transaction.
 *
 * @param       asid Address Space IDentifier (ASID) [0-255]
 *
 * @see         get_dvm_asid(), is_dvm_asid_set()
 */
inline void
amba_pv_dvm::set_dvm_asid(unsigned int asid) {
    m_dvm_encoded_transaction &= ~((ASID_HI_MASK << ASID_HI_SHIFT) | (ASID_LO_MASK << ASID_LO_SHIFT));
    m_dvm_encoded_transaction |= (sc_dt::uint64(asid & ASID_HI_MASK) << ASID_HI_SHIFT) |
                         (sc_dt::uint64(asid & ASID_LO_MASK) << ASID_LO_SHIFT) |
                         ASID_SET;
}

/**
 * @brief       Indicate whether there is an ASID set for this DVM transaction.
 *
 * @see         get_dvm_asid(), set_dvm_asid()
 */
inline bool
amba_pv_dvm::is_dvm_asid_set() const {
    return (m_dvm_encoded_transaction & ASID_SET) != 0;
}

/**
 * @brief       Return the ASID for this DVM transaction.
 *
 * @see         set_dvm_asid(), is_dvm_asid_set()
 */
inline unsigned int
amba_pv_dvm::get_dvm_asid() const {
    return ((m_dvm_encoded_transaction >> ASID_HI_SHIFT) & ASID_HI_MASK) |
           ((m_dvm_encoded_transaction >> ASID_LO_SHIFT) & ASID_LO_MASK);
}

/**
 * @brief       Set the Virtual Index for this DVM transaction.
 *
 * @param       virtual_index Virtual index [0-0xFFFF]
 *
 * @see         get_dvm_virtual_index(), is_dvm_virtual_index_set()
 */
inline void
amba_pv_dvm::set_dvm_virtual_index(unsigned int virtual_index) {
    m_dvm_encoded_transaction &= ~(VIRTUAL_INDEX_MASK << VIRTUAL_INDEX_LSB);
    m_dvm_encoded_transaction |= ((virtual_index & VIRTUAL_INDEX_MASK) << VIRTUAL_INDEX_LSB) | VIRTUAL_INDEX_SET;
}

/**
 * @brief       Indicate whether there is a virtual index set for this DVM transaction.
 *
 * @see         get_dvm_virtual_index(), set_dvm_virtual_index()
 */
inline bool
amba_pv_dvm::is_dvm_virtual_index_set() const {
    return (m_dvm_encoded_transaction & VIRTUAL_INDEX_SET) == VIRTUAL_INDEX_SET;
}

/**
 * @brief       Return the virtual index for this DVM transaction.
 *
 * @see         set_dvm_virtual_index(), is_dvm_virtual_index_set()
 */
inline unsigned int
amba_pv_dvm::get_dvm_virtual_index() const {
    return (m_dvm_encoded_transaction >> VIRTUAL_INDEX_LSB) & VIRTUAL_INDEX_MASK;
}

/**
 * @brief       Set the message type for this DVM transaction.
 *
 * @param       message_type DVM message type
 *
 * @see         get_dvm_message_type()
 */
inline void
amba_pv_dvm::set_dvm_message_type(amba_pv_dvm_message_t message_type) {
    m_dvm_encoded_transaction &= ~(TYPE_MASK << TYPE_LSB);
    m_dvm_encoded_transaction |= ((unsigned(message_type) & TYPE_MASK) << TYPE_LSB);
}

/**
 * @brief       Return the message type for this DVM transaction.
 *
 * @see         set_dvm_message_type()
 */
inline amba_pv_dvm_message_t
amba_pv_dvm::get_dvm_message_type() const {
    return amba_pv_dvm_message_t((m_dvm_encoded_transaction >> TYPE_LSB) & TYPE_MASK);
}

/**
 * @brief       Set the OS type for this DVM transaction.
 *
 * @param       os guest OS or hypervisor type
 *
 * @see         get_dvm_os()
 */
inline void
amba_pv_dvm::set_dvm_os(amba_pv_dvm_os_t os) {
    m_dvm_encoded_transaction &= ~(OS_MASK << OS_LSB);
    m_dvm_encoded_transaction |= ((unsigned(os) & OS_MASK) << OS_LSB);
}

/**
 * @brief       Return the OS type for this DVM transaction.
 *
 * @see         set_dvm_os()
 */
inline amba_pv_dvm_os_t
amba_pv_dvm::get_dvm_os() const {
    return amba_pv_dvm_os_t((m_dvm_encoded_transaction >> OS_LSB) & OS_MASK);
}

/**
 * @brief       Set the security type for this DVM transaction.
 *
 * @param       security DVM security type
 *
 * @see         get_dvm_security()
 */
inline void
amba_pv_dvm::set_dvm_security(amba_pv_dvm_security_t security) {
    m_dvm_encoded_transaction &= ~(SECURITY_MASK << SECURITY_LSB);
    m_dvm_encoded_transaction |= ((unsigned(security) & SECURITY_MASK) << SECURITY_LSB);
}

/**
 * @brief       Return the security for this DVM transaction.
 *
 * @see         set_dvm_security()
 */
inline amba_pv_dvm_security_t
amba_pv_dvm::get_dvm_security() const {
    return amba_pv_dvm_security_t((m_dvm_encoded_transaction >> SECURITY_LSB) & SECURITY_MASK);
}

/**
 * @brief       Set Leaf Entry only invalidation for this DVM transaction.
 * 
 * @param       leaf_entry_only Leaf Entry only invalidation
 *
 * @see         is_dvm_tlb_leaf_set()
 */
inline void
amba_pv_dvm::set_dvm_tlb_leaf(bool leaf_entry_only) {
    if (leaf_entry_only)
        m_dvm_encoded_transaction |= LEAF_ENTRY_ONLY;
    else
        m_dvm_encoded_transaction &= ~LEAF_ENTRY_ONLY;
}

/**
 * @brief       Indicate whether Leaf Entry only invalidation is set for this DVM transaction.
 *
 * @see         set_dvm_tlb_leaf()
 */
inline bool
amba_pv_dvm::is_dvm_tlb_leaf_set() const {
    return (m_dvm_encoded_transaction & LEAF_ENTRY_ONLY) != 0;
}

/**
 * @brief       Set the Staged Invalidation for this DVM transaction.
 *
 * @param       stage DVM Staged Invalidation
 *
 * @see         get_dvm_stage()
 */
inline void
amba_pv_dvm::set_dvm_stage(amba_pv_dvm_stage_t stage) {
    m_dvm_encoded_transaction &= ~(STAGE_MASK << STAGE_LSB);
    m_dvm_encoded_transaction |= ((unsigned(stage) & STAGE_MASK) << STAGE_LSB);
}

/**
 * @brief       Return the Staged Invalidation for this DVM transaction.
 *
 * @see         set_dvm_stage()
 */
inline amba_pv_dvm_stage_t
amba_pv_dvm::get_dvm_stage() const {
    return amba_pv_dvm_stage_t((m_dvm_encoded_transaction >> STAGE_LSB) & STAGE_MASK);
}

/**
 * @brief       Reset DVM message to default value.
 */
inline void
amba_pv_dvm::reset() {
    m_dvm_encoded_transaction = 0x0;
    m_dvm_encoded_additional_transaction = 0x0;
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_DVM__H) */
