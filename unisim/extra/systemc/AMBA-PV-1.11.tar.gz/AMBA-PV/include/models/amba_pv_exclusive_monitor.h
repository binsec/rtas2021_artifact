/*
 * AMBA-PV: amba_pv_exclusive_monitor.h - AMBA-PV exclusive monitor model.
 *
 * Copyright 2007-2009, 2011-2014 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_EXCLUSIVE_MONITOR__H
#define AMBA_PV_EXCLUSIVE_MONITOR__H

/**
 * @file        amba_pv_exclusive_monitor.h
 *
 * @brief       AMBA-PV exclusive monitor model.
 */

/* Includes */
#include <utils/amba_pv_unordered_map.h>

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief       AMBA-PV exclusive monitor model.
 *
 * The amba_pv_exclusive_monitor model provides exclusive access support, and
 * can be added before any AMBA-PV slave.
 *
 * Exclusive accesses are <em>single aligned transfers</em>, for which
 * amba_pv_control::is_exclusive() returns @c true.
 *
 * The amba_pv_exclusive_monitor model can be configured to:
 * - either disable DMI (default behavior) and thus reject all DMI requests
 * - or enable DMI for non exclusive regions and thus reject DMI requests
 *   that intersects with exclusive regions and invalidate DMI pointers for the
 *   same.
 * - ignore non-exclusive write by the same master, that is to keep the monitor
 *   in exclusive state or not.
 *
 * @note        When DMI is enabled, the onus is on the master to not use DMI
 *              for exclusive accesses. If the master uses DMI for exclusive
 *              accesses, wrong behavior might be observed.
 *
 * @note        When configured to disable DMI, the amba_pv_exclusive_monitor
 *              model might have an impact on performance.
 *
 * @param       BUSWIDTH bus width in bits as one of 8, 16, 32, 64, 128, 256,
 *              512, or 1024. Defaults to 64.
 */
template<unsigned int BUSWIDTH = 64>
class amba_pv_exclusive_monitor:
    public virtual amba_pv_fw_transport_if,
    public virtual amba_pv_bw_transport_if,
    public sc_core::sc_module {

    /* Sockets */
    public:

        /**
         * @brief Slave socket.
         */
        amba_pv_slave_socket<BUSWIDTH> amba_pv_s;

        /**
         * @brief Master socket.
         */
        amba_pv_master_socket<BUSWIDTH> amba_pv_m;

        /**
         * @brief Global exclusive monitor clear event.
         */
        signal_master_port<bool, 0, sc_core::SC_ZERO_OR_MORE_BOUND> clr_ex_mon_out;

    /* Constructor */
        explicit amba_pv_exclusive_monitor(const sc_core::sc_module_name &);
        amba_pv_exclusive_monitor(const sc_core::sc_module_name &,
                                  unsigned int,
                                  bool = false);

    /* sc_object overridables */
        virtual const char * kind() const;

    /* Accessors */
        unsigned int get_erg() const;
        void set_erg(unsigned int);
        bool is_dmi_enabled() const;
        void set_dmi_enabled(bool = true);
        bool non_exclusive_writes_ignored() const;
        void ignore_non_exclusive_writes(bool = true);
        bool must_exclusive_accesses_match() const;
        void exclusive_accesses_must_match(bool = true);

    /* Forward interface */
    protected:
        virtual void b_transport(int,
                                 amba_pv_transaction &,
                                 sc_core::sc_time &);
        virtual unsigned int transport_dbg(int, amba_pv_transaction &);
        virtual bool get_direct_mem_ptr(int,
                                        amba_pv_transaction &,
                                        tlm::tlm_dmi &);

    /* Backward Interface */
        virtual void
        invalidate_direct_mem_ptr(int, sc_dt::uint64, sc_dt::uint64);

    /* Implementation */
    private:

        /* Typedefs*/
        typedef std::unordered_map<unsigned int, sc_dt::uint64> monitors_t;

        /* Member variables */
        monitors_t m_monitors;    /* Exclusive monitor */
            /* m_monitors[n]: tagged address for master(n):
             * - (m_monitors.find(n) == m_monitors.end()): monitor in open state
             * - (m_monitors.find(n) != m_monitors.end()): monitor in exclusive
             *   state
             * where n is given by amba_pv_extension::get_id() */
        unsigned int m_erg;     /* Exclusives Reservation Granule (ERG) */
        bool m_dmi_enabled;     /* DMI enabled */
        bool m_ignore_non_exclusive_writes;
            /* Whether a write-non-exclusive should re-open monitor
             * this behaviour is ImpDef in the ARM ARM */
        bool m_exclusive_accesses_must_match;
            /* Whether exclusive write address must match previous exclusive
             * read address
             * this behaviour is ImpDef in the ARM ARM */

        /* Helper functions */
        sc_dt::uint64 tagged_address(const sc_dt::uint64 &) const;
        sc_dt::uint64 address_from_tag(const sc_dt::uint64 &) const;
};

/* Functions */

/**
 * @brief       Constructor.
 *
 * @param       name monitor name.
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_exclusive_monitor<BUSWIDTH>::amba_pv_exclusive_monitor(const sc_core::sc_module_name & name):
    sc_core::sc_module(name),
    amba_pv_s("amba_pv_s"),
    amba_pv_m("amba_pv_m"),
    clr_ex_mon_out("clr_ex_mon_out"),
    m_erg(sc_dt::sc_max(3u,
                        static_cast<unsigned int>(log((BUSWIDTH + 7) / 8.0)
                                                  / log(2.0)))),
    m_dmi_enabled(false),
    m_ignore_non_exclusive_writes(false),
    m_exclusive_accesses_must_match(true) {

    /* Bindings... */
    amba_pv_s(* this);
    amba_pv_m(* this);
}

/**
 * @brief       Parameterized constructor.
 *
 * The <em>Exclusives Reservation Granule</em> (ERG) is set to:
 * max(@a erg , log2((@e BUSWIDTH + 7) / 8)).
 *
 * @param       name monitor name.
 * @param       erg the ERG of this monitor in [3..11].
 * @param       dmi_enabled @c true to enable DMI for non exclusive regions
 *              Defaults to @c false.
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_exclusive_monitor<BUSWIDTH>::amba_pv_exclusive_monitor(const sc_core::sc_module_name & name,
                                                               unsigned int erg,
                                                               bool dmi_enabled /* = false */):
    sc_core::sc_module(name),
    amba_pv_s("amba_pv_s"),
    amba_pv_m("amba_pv_m"),
    clr_ex_mon_out("clr_ex_mon_out"),
    m_erg(sc_dt::sc_max(erg,
                        static_cast<unsigned int>(log((BUSWIDTH + 7) / 8.0)
                                                  / log(2.0)))),
    m_dmi_enabled(dmi_enabled),
    m_ignore_non_exclusive_writes(false),
    m_exclusive_accesses_must_match(true) {
    sc_assert((erg >= 3) && (erg <= 11));

    /* Bindings... */
    amba_pv_s(* this);
    amba_pv_m(* this);
}

/**
 * @brief       Returns the kind string of this monitor.
 */
template<unsigned int BUSWIDTH>
inline const char *
amba_pv_exclusive_monitor<BUSWIDTH>::kind() const {
    return ("amba_pv_exclusive_monitor");
}

/**
 * @brief       Returns the ERG of this monitor.
 */
template<unsigned int BUSWIDTH>
inline unsigned int
amba_pv_exclusive_monitor<BUSWIDTH>::get_erg() const {
    return (m_erg);
}

/**
 * @brief       Sets the ERG of this monitor.
 *
 * The new ERG is set to: max(@a erg, log2((@e BUSWIDTH + 7) / 8)).
 *
 * @param       erg the new ERG as in [3..11].
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_exclusive_monitor<BUSWIDTH>::set_erg(unsigned int erg) {
    sc_assert((erg >=3) && (erg <= 11));
    m_erg = sc_dt::sc_max(erg,
                          static_cast<unsigned int>(log((BUSWIDTH + 7) / 8.0)
                                                    / log(2.0)));
}

/**
 * @brief       Returns whether or not DMI is enabled for non exclusive regions
 *              for this monitor.
 *
 * @return      @c true when DMI is enabled, @c false otherwise.
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_exclusive_monitor<BUSWIDTH>::is_dmi_enabled() const {
    return (m_dmi_enabled);
}

/**
 * @brief       Sets whether or not DMI is enabled for non exclusive regions
 *              for this monitor.
 *
 * When DMI is enabled, the monitor rejects DMI requests that intersect with
 * exclusive regions and invalidates DMI pointers for the same.
 *
 * When DMI is disabled, DMI is not allowed.
 *
 * @note        When DMI is disabled during simulation, DMI pointers previously
 *              acquired are not invalidated.
 *
 * @note        When DMI is enabled, the onus is on the master to not use DMI
 *              for exclusive accesses. If the master uses DMI for exclusive
 *              accesses, wrong behavior might be observed.
 *
 * @param       dmi_enabled @c true to enable DMI, @c false otherwise.
 *
 * @see         @c tlm::tlm_generic_payload::set_dmi_allowed() in the <em>TLM
 *              2.0 Language Reference Manual</em> for more information on DMI
 *              allowed.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_exclusive_monitor<BUSWIDTH>::set_dmi_enabled(bool dmi_enabled) {
    m_dmi_enabled = dmi_enabled;
}

/**
 * @brief       Returns whether or not a non-exclusive write to a monitored
 *              exclusive region by the same master should revoke the monitor.
 *
 * This behaviour is @c ImpDef in the ARM ARM.
 *
 * @return      @c true when non-exclusive writes are ignored, @c false otherwise.
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_exclusive_monitor<BUSWIDTH>::non_exclusive_writes_ignored() const {
    return (m_ignore_non_exclusive_writes);
}

/**
 * @brief       Sets whether or not a non-exclusive write to a monitored
 *              exclusive region by the same master should revoke the monitor.
 *
 * This behaviour is @c ImpDef in the ARM ARM.
 *
 * @param       ignore_non_exclusive_writes @c true to ignore non-exclusive
 *              writes, @c false otherwise.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_exclusive_monitor<BUSWIDTH>::ignore_non_exclusive_writes(bool ignore_non_exclusive_writes) {
    m_ignore_non_exclusive_writes = ignore_non_exclusive_writes;
}

/**
 * @brief       Returns whether or not exclusive write adress must match the
 *              preceeding exclusive read address from the same master.
 *
 * This behaviour is @c ImpDef in the ARM ARM.
 *
 * @return      @c true when exclusive accesses must match, @c false otherwise.
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_exclusive_monitor<BUSWIDTH>::must_exclusive_accesses_match() const {
    return (m_exclusive_accesses_must_match);
}

/**
 * @brief       Sets whether or not an exclusive write address must match the
 *              preceeding exclusive read address from the same master.
 *
 * This behaviour is @c ImpDef in the ARM ARM.
 *
 * @param       must_match @c true when exclusive access address must match, @c false
 *              otherwise.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_exclusive_monitor<BUSWIDTH>::exclusive_accesses_must_match(bool must_match) {
    m_exclusive_accesses_must_match = must_match;
}

/**
 * @brief       Blocking transport.
 *
 * This version of the method completes the specified transaction while
 * processing exclusive access.
 * amba_pv_extension::get_rsp() indicates the successful completion of the
 * exclusive access, or an error occured. The response @c AMBA_PV_EXOKAY is
 * returned to indicate a successful completion of the exclusive access, while
 * @c AMBA_PV_OKAY is returned in case of failure.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_exclusive_monitor<BUSWIDTH>::b_transport(int socket_id,
                                                 amba_pv_transaction & trans,
                                                 sc_core::sc_time & t) {
    monitors_t::iterator i;
    amba_pv_extension * ex = NULL;
    sc_dt::uint64 tag;
    bool dmi_allowed = true;

    /* Retrieve AMBA-PV extension */
    trans.get_extension(ex);
    if (ex == NULL) {
        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
        return;
    }

    /* Compute tagged address */
    tag = tagged_address(trans.get_address());
    if (trans.is_read()) {

        /* Read transaction */
        if (ex->is_exclusive()) {

            /* Monitor the exclusive read access, whether in open or exclusive
             * state, resetting the monitor possibly */
            m_monitors[ex->get_id()] = tag;

            /* Invalidate corresponding DMI region */
            if (is_dmi_enabled()) {
                amba_pv_s.invalidate_direct_mem_ptr(address_from_tag(tag),
                                                    address_from_tag(tag + 1)
                                                    - 1);
            }
        }

        /* (Exclusive) Read proceeds */
        amba_pv_m->b_transport(trans, t);
    } else if (trans.is_write()) {
        bool has_cleared_monitors = false;

        i = m_monitors.find(ex->get_id());

        /* Check monitor state */
        if (i != m_monitors.end()) {

            /* Monitor in exclusive state */
            if (i->second != tag) {

                /* Access to another region */
                if (ex->is_exclusive()) {
                    if (must_exclusive_accesses_match()) {

                        /* Exclusive write fails, monitor remains in exclusive state
                         *
                         * NOTE:    this is ImpDef in the ARM ARM */
                        ex->set_okay();
                        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
                        return;
                    }

                    /* Monitor back to open state
                     *
                     * NOTE:    this is ImpDef in the ARM ARM */
                    m_monitors.erase(i);
                    i = m_monitors.end();
                }
            } else {

                /* Access to same region */
                if (ex->is_exclusive() || (! non_exclusive_writes_ignored())) {

                    /* Monitor back to open state
                     *
                     * NOTE:    this is ImpDef in the ARM ARM */
                    m_monitors.erase(i);
                    i = m_monitors.end();
                }
            }
        } else {

            /* Monitor in open state */
            if (ex->is_exclusive()) {

                /* Exclusive write fails, monitor remains in open state */
                ex->set_okay();
                trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
                return;
            }
        }

        /* Other monitors back to open state for this region */
        while (true) {
            monitors_t::iterator j;

            for (j = m_monitors.begin(); (j != m_monitors.end()); j ++) {
                if ((j != i) && (j->second == tag)) {
                    break;
                }
            }
            if (j == m_monitors.end()) {
                break;
            }
            m_monitors.erase(j);
            has_cleared_monitors = true;
        }

        /* DMI not allowed if access still monitored, unless non-exclusive writes are ignored */
        if ((i != m_monitors.end()) && (i->second == tag)) {
            dmi_allowed = non_exclusive_writes_ignored();
        }

        /* (Exclusive) Write proceeds */
        amba_pv_m->b_transport(trans, t);

        /* Pulse clear event */
        if (has_cleared_monitors) {
            for (int i = 0; (i < clr_ex_mon_out.size()); i += 1) {
                clr_ex_mon_out.set_state(i, true);
                clr_ex_mon_out.set_state(i, false);
           }
        }

    } else {

        /* Unknown transaction proceeds */
        amba_pv_m->b_transport(trans, t);
        return;
    }

    /* DMI not allowed if DMI disabled or exclusive access */
    if ((! is_dmi_enabled()) || ex->is_exclusive()) {
        dmi_allowed = false;
    }

    /* Update response and DMI allowed */
    if (ex->is_exclusive()) {
        if (ex->is_okay()) {
            ex->set_exokay();
        }
    }
    trans.set_dmi_allowed(trans.is_dmi_allowed() && dmi_allowed);
}

/**
 * @brief       Debug access to a target.
 *
 * This version of the method forwards this debug access to the slave.
 */
template<unsigned int BUSWIDTH>
inline unsigned int
amba_pv_exclusive_monitor<BUSWIDTH>::transport_dbg(int socket_id,
                                                   amba_pv_transaction & trans) {
    return (amba_pv_m->transport_dbg(trans));
}

/**
 * @brief       Requests a DMI access based on the specified transaction.
 *
 * This version of the method returns @c false when DMI is disabled, @c false
 * for exclusive accesses, or when the DMI region intersects with an exclusive
 * region and the DMI region cannot be resized outside of the exclusive region.
 * It returns @c true when DMI access is granted.
 *
 * @note        Read-only DMI is allowed though as a potential performance
 *              optimization.
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_exclusive_monitor<BUSWIDTH>::get_direct_mem_ptr(int socket_id,
                                                        amba_pv_transaction & trans,
                                                        tlm::tlm_dmi & dmi) {
    monitors_t::iterator i;
    amba_pv_extension * ex = NULL;

    /* DMI not allowed if DMI disabled */
    if (! is_dmi_enabled()) {
        return false;
    }

    /* Retrieve AMBA-PV extension */
    trans.get_extension(ex);
    if (ex == NULL) {
        return false;
    }

    /* DMI not allowed for exclusive accesses */
    if (ex->is_exclusive()) {
        return false;
    }

    /* Forward DMI access request */
    if (! amba_pv_m->get_direct_mem_ptr(trans, dmi)) {
        return false;
    }

    /* DMI not allowed when DMI region intersects with an exclusive region and
     * DMI region cannot be resized outside of exclusive region and
     * non-exclusive writes to master's exclusive region are not ignored.
     *
     * NOTE:    Read-only DMI allowed though as a potential performance
     *          optimization. */
    if (dmi.is_write_allowed()) {
        sc_dt::uint64 dmi_start = dmi.get_start_address();
        sc_dt::uint64 dmi_end = dmi.get_end_address();

        for (i = m_monitors.begin(); (i != m_monitors.end()); i ++) {
            if ((i->first == ex->get_id()) && non_exclusive_writes_ignored()) {
                continue;
            }
            sc_dt::uint64 excl_start = address_from_tag(i->second);
            sc_dt::uint64 excl_end = address_from_tag(i->second + 1) - 1;

            if (((excl_start >= dmi_start) && (excl_start <= dmi_end))
                || ((excl_end >= dmi_start) && (excl_end <= dmi_end))) {

                /* Resize DMI region... */
                if ((trans.get_address() < excl_start)
                    && (dmi_end >= excl_start) && (dmi_start < excl_start)) {

                    /* ...from end... */
                    dmi.set_end_address(excl_start - 1);
                } else if ((trans.get_address() > excl_end)
                    && (dmi_start <= excl_end) && (dmi_end > excl_end)) {

                    /* ... from start */
                    dmi.set_start_address(excl_end + 1);
                    dmi.set_dmi_ptr(dmi.get_dmi_ptr() + excl_end + 1 - dmi_start);
                } else {

                    /* Cannot be resized */
                    return false;
                }
            }
        }
        sc_assert(dmi.get_start_address() <= dmi.get_end_address());
    }
    return true;
}

/**
 * @brief       Invalidates DMI pointers previously established for the given
 *              DMI region.
 *
 * This version of the method simply forwards the call backward to the master.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_exclusive_monitor<BUSWIDTH>::invalidate_direct_mem_ptr(int socket_id,
                                                               sc_dt::uint64 start_range,
                                                               sc_dt::uint64 end_range) {
    amba_pv_s->invalidate_direct_mem_ptr(start_range, end_range);
}

/*
 * Returns the tagged address of the given memory address.
 */
template<unsigned int BUSWIDTH>
inline sc_dt::uint64
amba_pv_exclusive_monitor<BUSWIDTH>::tagged_address(const sc_dt::uint64 & a) const {
    return (a >> m_erg);
}

/*
 * Returns the memory address from the given tag.
 */
template<unsigned int BUSWIDTH>
inline sc_dt::uint64
amba_pv_exclusive_monitor<BUSWIDTH>::address_from_tag(const sc_dt::uint64 & tag) const {
    return (tag << m_erg);
}

}   /* namepsace amba_pv */

#endif  /* defined(AMBA_PV_EXCLUSIVE_MONITOR__H) */
