/*
 * AMBA-PV: amba_pv_mm.h - AMBA-PV transaction memory manager classes.
 *
 * Copyright 2013-2014 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_MM__H
#define AMBA_PV_MM__H

/**
 * @file        amba_pv_mm.h
 *
 * @brief       AMBA-PV transaction memory manager classes.
 */

/* Includes */
#include <queue>
#include <algorithm>

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief       AMBA-PV transaction pool.
 *
 * This class implements the @c tlm::tlm_mm_interface and provides a memory
 * pool from which transaction can be (de)allocated.
 *
 * @note        amba_pv_trans_pool is not an @c sc_module.
 */
class amba_pv_trans_pool:
    public virtual tlm::tlm_mm_interface {

    /* Constructor */
    public:
        explicit amba_pv_trans_pool(size_t = 0);
        ~amba_pv_trans_pool();

    /* Accessors */
        amba_pv_transaction * allocate();
        amba_pv_transaction * allocate(unsigned int, const amba_pv_control *);
        amba_pv_transaction * allocate(unsigned int,
                                       unsigned int,
                                       const amba_pv_control *,
                                       amba_pv_burst_t);
        bool empty() const;
        size_t size() const;
        void reserve(size_t);

    /* Implementation */
    private:
        std::queue<amba_pv_transaction *> m_pool; /* Transaction pool */

        /* TLM memory manager interface */
        virtual void free(amba_pv_transaction *);

        /* Copying - disabled */
        amba_pv_trans_pool(const amba_pv_trans_pool &);
        amba_pv_trans_pool & operator =(const amba_pv_trans_pool &);
};

/**
 * @brief       AMBA-PV transaction smart pointer.
 *
 * amba_pv_trans_ptr is a smart pointer that retains sole ownership of a
 * transaction through a pointer and releases that transaction when the
 * amba_pv_trans_ptr goes out of scope.
 * 
 * @note        No two amba_pv_trans_ptr instances can manage the same
 *              transaction.
 *
 * @note        amba_pv_trans_ptr is not an @c sc_module.
 */
class amba_pv_trans_ptr {

    /* Constructor */
    public:
        explicit amba_pv_trans_ptr(amba_pv_transaction * = NULL);
        ~amba_pv_trans_ptr();

    /* Accessors */
        amba_pv_transaction * release();
        void reset(amba_pv_transaction * = NULL);
        void swap(amba_pv_trans_ptr &);
        amba_pv_transaction * get() const;
        operator bool() const;
        amba_pv_transaction & operator *() const;
        amba_pv_transaction * operator ->() const;

    /* Implementation */
    private:
        amba_pv_transaction * m_trans; /* Managed transaction */

        /* Copying - disabled */
        amba_pv_trans_ptr(const amba_pv_trans_ptr &);
        amba_pv_trans_ptr & operator =(const amba_pv_trans_ptr &);
};

/* Functions - amba_pv_trans_pool */

/**
 * @brief       Frees a previously allocated AMBA-PV transaction.
 */
inline void
amba_pv_trans_pool::reserve(size_t n) {
    while (m_pool.size() < n) {
        amba_pv_transaction * trans = NULL;

        trans = new amba_pv_transaction(this);
        trans->set_extension(new amba_pv_extension());
        m_pool.push(trans);
    }
}

/**
 * @brief       Constructor.
 *
 * @param       n number of transactions initially allocated in the pool.
 */
inline
amba_pv_trans_pool::amba_pv_trans_pool(size_t n /* = 0 */) {
    reserve(n);
}

/**
 * @brief       Destructor.
 */
inline
amba_pv_trans_pool::~amba_pv_trans_pool() {
    while (! m_pool.empty()) {
        amba_pv_transaction * trans = m_pool.front();

        sc_assert(trans->get_ref_count() == 0);
        delete trans;
        m_pool.pop();
    }
}

/**
 * @brief       Allocates and returns a new AMBA-PV transaction.
 *
 * allocate() will also (re)set the associated AMBA-PV extension.
 *
 * @param       length transaction burst length as in [1-256].
 * @param       size transaction burst size in bytes as one of [1, 2, 4, 8, 16,
 *              32, 64, 128].
 * @param       ctrl optional AMBA&nbsp;4 control information (set to @c NULL if
 *              unused).
 * @param       burst transaction burst type as one of @c AMBA_PV_INCR,
 *              @c AMBA_PV_FIXED, @c AMBA_PV_WRAP.
 */
inline amba_pv_transaction *
amba_pv_trans_pool::allocate(unsigned int length,
                             unsigned int size,
                             const amba_pv_control * ctrl,
                             amba_pv_burst_t burst)  {
    amba_pv_transaction * trans = NULL;

    if (m_pool.empty()) {
        trans = new amba_pv_transaction(this);
        trans->set_extension(new amba_pv_extension(length, size, ctrl, burst));
    } else {
        trans = m_pool.front();
        m_pool.pop();
        trans->get_extension<amba_pv_extension>()->reset(length, size, ctrl, burst);
    }
    return (trans);
}

/**
 * @brief       Allocates and returns a new AMBA-PV transaction with associated
 *              AMBA-PV extension.
 *
 * allocate() will also (re)set the associated AMBA-PV extension.
 */
inline amba_pv_transaction *
amba_pv_trans_pool::allocate()  {
    return (allocate(1, 8, NULL, AMBA_PV_INCR));
}

/**
 * @brief       Allocates and returns a new AMBA-PV transaction with associated
 *              AMBA-PV extension.
 *
 * allocate() will also (re)set the associated AMBA-PV extension.
 *
 * @param       size transaction size in bytes as one of [1, 2, 4, 8, 16, 32,
 *              64, 128].
 * @param       ctrl optional AMBA&nbsp;4 control information (set to @c NULL if
 *              unused).
 */
inline amba_pv_transaction *
amba_pv_trans_pool::allocate(unsigned int size,
                             const amba_pv_control * ctrl) {
    return (allocate(1, size, ctrl, AMBA_PV_INCR));
}

/**
 * @brief       Returns whether this manager's pool is empty (i.e. whether its
 *              size is 0).
 */
inline bool
amba_pv_trans_pool::empty() const  {
    return (m_pool.empty());
}

/**
 * @brief       Returns the number of transactions in this manager's pool.
 */
inline size_t
amba_pv_trans_pool::size() const  {
    return (m_pool.size());
}

/*
 * Frees a previsouly allocated AMBA-PV transaction.
 */
inline void
amba_pv_trans_pool::free(amba_pv_transaction * trans) {
    if (trans != NULL) {
        sc_assert(trans->get_extension<amba_pv_extension>() != NULL);
        trans->reset();

        /* NOTE:    reset() does not reset all the transaction attributes... */
        trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
        trans->set_dmi_allowed(false);
        m_pool.push(trans);
    }
}

/* Functions - amba_pv_trans_ptr */

/**
 * @brief       Constructor.
 *
 * @param       trans transaction pointer to manage.
 */
inline
amba_pv_trans_ptr::amba_pv_trans_ptr(amba_pv_transaction * trans /* = NULL */):
    m_trans(trans) {
    if (m_trans != NULL) {
        m_trans->acquire();
    }
}

/**
 * @brief       Destructor.
 */
inline
amba_pv_trans_ptr::~amba_pv_trans_ptr() {
    if (m_trans != NULL) {
        m_trans->release();
    }
}

/**
 * @brief       Returns a pointer to the managed transaction and releases the
 *              ownership.
 */
inline amba_pv_transaction *
amba_pv_trans_ptr::release() {
    amba_pv_transaction * trans = m_trans;

    m_trans = NULL;
    return (trans);
}

/**
 * @brief       Replaces the managed transaction.
 *
 * @param       trans pointer to new transaction to manage.
 */
inline void
amba_pv_trans_ptr::reset(amba_pv_transaction * trans /* = NULL */) {
    amba_pv_transaction * old_trans = m_trans;

    m_trans = trans;
    if (m_trans != NULL) {
        m_trans->acquire();
    }
    if (old_trans != NULL) {
        old_trans->release();
    }
}

/**
 * @brief       Swaps the managed transactions.
 *
 * @param       ptr transaction smart pointer to swap managed transactions with.
 */
inline void
amba_pv_trans_ptr::swap(amba_pv_trans_ptr & ptr) {
    std::swap(m_trans, ptr.m_trans);
}

/*
 * @brief       Returns a pointer to the managed transaction.
 */
inline amba_pv_transaction *
amba_pv_trans_ptr::get() const {
    return (m_trans);
}

/*
 * @brief       Checks whether there is an associated managed transaction.
 */
inline
amba_pv_trans_ptr::operator bool() const {
    return (m_trans != NULL);
}

/*
 * @brief       Returns a reference to the managed transaction owned by this
 *              pointer.
 */
inline amba_pv_transaction &
amba_pv_trans_ptr::operator *() const {
    if (m_trans == NULL) {
        SC_REPORT_ERROR("amba_pv_trans_ptr",
                        "operator *(): no transaction owned");
    }
    return (* m_trans);
}

/*
 * @brief       Returns a pointer to the managed transaction.
 */
inline amba_pv_transaction *
amba_pv_trans_ptr::operator ->() const {
    return (m_trans);
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator ==(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (x.get() == y.get());
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator !=(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (! (x == y));
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator <(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (x.get() < y.get());
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator <=(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (! (y < x));
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator >(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (y < x);
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator >=(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (! (x < y));
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_MM__H) */
