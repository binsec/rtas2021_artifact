
/*
 *
 * SystemC TLM API Standard Proposal and Examples
 * Copyright Cadence Design Systems Inc 2004
 *
 */

#ifndef BUS_TYPES_HEADER
#define BUS_TYPES_HEADER

typedef unsigned int ADDRESS_TYPE;
typedef unsigned int DATA_TYPE;

#endif
