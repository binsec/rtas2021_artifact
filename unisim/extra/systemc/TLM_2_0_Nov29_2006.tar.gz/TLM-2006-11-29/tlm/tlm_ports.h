
namespace tlm_ports {

#include "tlm_ports/tlm_initiator_port.h"
#include "tlm_ports/tlm_target_port.h"

};
