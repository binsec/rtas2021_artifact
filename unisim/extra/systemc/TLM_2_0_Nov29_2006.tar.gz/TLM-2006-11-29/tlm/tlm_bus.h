
#ifndef TLM_BUS_HEADER
#define TLM_BUS_HEADER

#include <vector>

namespace tlm_bus {

#include "tlm_bus/tlm_request.h"
#include "tlm_bus/tlm_response.h"

}

#endif
