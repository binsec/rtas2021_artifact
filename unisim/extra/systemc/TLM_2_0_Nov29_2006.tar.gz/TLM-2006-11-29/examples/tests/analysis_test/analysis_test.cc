
#include "tlm.h"

using namespace tlm;

class producer : public sc_module {
public:
  analysis_port< int > int_ap;
  analysis_port< analysis_triple< int> > triple_ap;

  SC_HAS_PROCESS( producer );

  producer( sc_module_name nm ) : sc_module( nm ) {
    SC_THREAD( run );
  }

private:
  void run() {
    analysis_triple<int> triple( 3 );

    triple.start_time = sc_time( 10 , SC_NS );
    triple.end_time = sc_time( 20 , SC_NS );

    int_ap.write( 2 );
    triple_ap.write( triple );
    int_ap.write( 4 );

  }

};


template<typename T>
class consumer : public sc_module {
public:
  sc_port< tlm_blocking_get_if<T> >  p;

  SC_HAS_PROCESS( consumer );

  consumer( sc_module_name nm ) : sc_module( nm ) {
    SC_THREAD( run );
  }

private:
  void run() {
    T i;
    for(;;) {
      i = p->get();
      cout << i << endl;
    }

  }
};

int sc_main( int argc , char ** argv ) {

  producer p("producer");
  analysis_fifo<int> af;
  consumer<int> c("consumer0");

  p.int_ap( af );
  p.triple_ap( af );
  c.p( af );

  sc_start();
  return 0;
}
