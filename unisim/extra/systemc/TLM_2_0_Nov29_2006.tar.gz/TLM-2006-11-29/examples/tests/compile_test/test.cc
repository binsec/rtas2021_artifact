
#include "tlm.h"

class int_attribute : public tlm::tlm_custom_base {
public:
  int_attribute( int i = 0 ) : x( i ) {}
  int_attribute( const int_attribute &a ) : x( a.x ) {}

  tlm::tlm_custom_base *clone() {
    int_attribute *t = new int_attribute( x );
    return t;
  }

  int x;
};


int sc_main( int argc , char ** argv ) {

  std::vector< tlm::tlm_custom_base * > v( 1 ) , *dump_vector;
  int data[10];

  for( int i = 0; i < 10; i++ ) {
    data[i] = i;
  }

  /*
  tlm::tlm_response< int , tlm::TLM_PASS_BY_POINTER > a , b;
  tlm::tlm_response< int , tlm::TLM_PASS_BY_COPY > c;
  */

  tlm::tlm_request< int , int , tlm::TLM_PASS_BY_POINTER > a , b;
  tlm::tlm_request< int , int , tlm::TLM_PASS_BY_COPY > c;


  int_attribute attr( 3 );
  v[0] = &attr;

  a.set_data_array( 10 , data );
  a.set_custom_vector_ptr( &v );

  cout << "ok1" << endl;
  b = a;
  cout << "ok2" << endl;
  c = b;
  cout << "ok3" << endl;
  
  for( int i = 0; i < 10; i++ ) {
    data[i] = -i;
  }

  attr.x = 2;

  int i;

  for( i = 0; i < 10; i++ ) {
    cout << a.get_data( i ) << ",";
    cout << b.get_data( i ) << ",";
    cout << c.get_data( i ) << endl;
  }

  cout << "attributes :";

  dump_vector = a.get_custom_vector_ptr();
  i = (dynamic_cast< int_attribute * >( (*dump_vector)[0] ))->x;
  cout << i << ",";

  dump_vector = b.get_custom_vector_ptr();
  i = (dynamic_cast< int_attribute * >( (*dump_vector)[0] ))->x;
  cout << i << ",";

  dump_vector = c.get_custom_vector_ptr();
  i = (dynamic_cast< int_attribute * >( (*dump_vector)[0] ))->x;
  cout << i << endl;

  cout << "done" << endl;
  return 0;
}
