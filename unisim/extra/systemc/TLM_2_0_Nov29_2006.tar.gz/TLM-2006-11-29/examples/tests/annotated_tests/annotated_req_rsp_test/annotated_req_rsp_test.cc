
#include "tlm.h"

using namespace tlm;

class slave : public sc_module {
public:
  sc_port< tlm_annotated_nonblocking_slave_if< int , char > > p;

  SC_HAS_PROCESS( slave );

  slave( sc_module_name nm ) : sc_module( nm ) {}

  void end_of_elaboration() {

    SC_METHOD( run );
    dont_initialize();
    sensitive << p->ok_to_peek();

  }

  void run() {

    int i;

    if( !p->nb_peek( i ) ) {
      cout << name() << " cannot peak at " << sc_time_stamp() << endl;
      return;
    }

    cout << name() << " just peaked " << i << " at " << sc_time_stamp() << endl;
    p->nb_get( i , sc_time( 10 , SC_NS ) );
    p->nb_put( -i , sc_time( 20 , SC_NS ) );

  }

};

class master : public sc_module {
public:
  sc_port< tlm_annotated_nonblocking_master_if< int , char > > p;

  SC_HAS_PROCESS( master );

  master( sc_module_name nm ) : sc_module( nm ) {
    m_i = 0;
  }

  void end_of_elaboration() {
    SC_METHOD( req_method );
    sensitive << p->ok_to_put(); 
    SC_METHOD( rsp_method );
    sensitive << p->ok_to_get();
  }

private:
  int m_i;

  void req_method() {
    
    sc_time t( 20 , SC_NS );

    if( m_i != 10 ) {

      if( p->nb_put( m_i , t ) ) {

        cout << name() << " just posted " << m_i;
        cout << " at time " << sc_time_stamp();
        cout << " for time " << sc_time_stamp() + t << endl;

        m_i++;
      }

    }

  }

  void rsp_method() {

    char c;

    if( p->nb_get( c ) ) {
      cout << name() << "just got response " << (int)c << endl;
    }

  }

};

int sc_main( int argc , char ** argv ) {

  tlm_annotated_req_rsp_channel< int , char > channel("channel" , 1 , 1 );
  master m("master");
  slave s("slave");

  m.p( channel.master_export );
  s.p( channel.slave_export );

  sc_start();

  return 0;
}
