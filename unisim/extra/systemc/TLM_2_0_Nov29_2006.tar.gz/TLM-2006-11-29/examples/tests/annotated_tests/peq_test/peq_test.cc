
#include "tlm.h"

using namespace tlm;

template< typename T >
class listener :
  public sc_module ,
  public virtual analysis_if< T > {
public:
  sc_export< analysis_if< T > > analysis_export;

  listener( sc_module_name nm ) : sc_module( nm ) {
    analysis_export( *this );
  }

  void write( const T &t ) {
    cout << name() << " saw " << t << " at " << sc_time_stamp() << endl;
  }

};

class producer : public sc_module {
public:
  sc_port< delayed_analysis_if< int > > p;

  SC_HAS_PROCESS( producer );

  producer( sc_module_name nm ) : sc_module( nm ) {
    SC_THREAD( run );
  }

private:
  void run() {
    
    int i = 0;
    
    p->write( i++ , sc_time( 100 , SC_NS ) );
    p->write( i++ , sc_time( 90 , SC_NS ) );
    p->write( i++ , sc_time( 80 , SC_NS ) );
    p->write( i++ , sc_time( 70 , SC_NS ) );
    
    wait( 20 , SC_NS );

    p->write( i++ , sc_time( 90 , SC_NS ) );
    p->write( i++ , sc_time( 80 , SC_NS ) );
    p->write( i++ , sc_time( 70 , SC_NS ) );
 
    wait( 20 , SC_NS );

    p->write( i++ , SC_ZERO_TIME );
    p->write( i++ , SC_ZERO_TIME );
    p->write( i++ , SC_ZERO_TIME );
    
  }

};

int sc_main( int argc , char ** argv ) {

  tlm_peq<int> peq("peq");
  producer p("producer");
  listener<int> l("listener");

  p.p( peq.delayed_analysis_export );
  peq.ap( l.analysis_export );

  sc_start();

  return 0;
}
