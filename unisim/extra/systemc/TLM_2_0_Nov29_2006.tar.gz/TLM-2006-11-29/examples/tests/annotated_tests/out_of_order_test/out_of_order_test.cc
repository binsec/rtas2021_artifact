
#include "tlm.h"

using namespace tlm;

class consumer : public sc_module {
public:
  sc_port< tlm_annotated_get_peek_if< int > > p;

  SC_HAS_PROCESS( consumer );

  consumer( sc_module_name nm ) : sc_module( nm ) {}

  void end_of_elaboration() {

    SC_METHOD( run );
    dont_initialize();
    sensitive << p->ok_to_peek();

  }

  void run() {

    int i;

    if( !p->nb_peek( i ) ) {
      cout << name() << " cannot peak at " << sc_time_stamp() << endl;
      return;
    }

    cout << name() << " just peaked " << i << " at " << sc_time_stamp() << endl;
    p->nb_get( i , sc_time( 17 , SC_NS ) );

    if( !p->nb_peek( i ) ) {
      cout << name() << " cannot peak at " << sc_time_stamp() << endl;
      return;
    }

    cout << name() << " just peaked " << i << " at " << sc_time_stamp() << endl;
    p->nb_get( i , sc_time( 10 , SC_NS ) );
  }

};

class producer : public sc_module {
public:
  sc_port< tlm_blocking_put_if< int > > p;

  SC_HAS_PROCESS( producer );

  producer( sc_module_name nm ) : sc_module( nm ) {
    SC_THREAD( run );
  }



private:

  void run() {
    
    for( int i = 0; i < 10; i++ ) {
      p->put( i );
      cout << "Just put " << i << " at " << sc_time_stamp() << endl;
      i++;
      p->put( i );
      cout << "Just put " << i  << " at " << sc_time_stamp() << endl;
    }

  }

};

int sc_main( int argc , char ** argv ) {

  tlm_annotated_fifo< int > fifo("annotated_fifo" , 2 );
  producer p("producer");
  consumer c("consumer");

  p.p( fifo );
  c.p( fifo );

  sc_start();

  return 0;
}
