
#include "tlm.h"

using namespace tlm;

class consumer : public sc_module {
public:
  sc_port< tlm_annotated_get_peek_if< int > > p;

  SC_HAS_PROCESS( consumer );

  consumer( sc_module_name nm ) : sc_module( nm ) {}

  void end_of_elaboration() {

    SC_METHOD( run );
    dont_initialize();
    sensitive << p->ok_to_peek();

  }

  void run() {

    int i;

    if( !p->nb_peek( i ) ) {
      cout << name() << " cannot peak at " << sc_time_stamp() << endl;
      return;
    }

    cout << name() << " just peaked " << i << " at " << sc_time_stamp() << endl;
    p->nb_get( i , sc_time( 10 , SC_NS ) );

  }

};

class producer : public sc_module {
public:
  sc_port< tlm_annotated_put_if< int > > p;

  SC_HAS_PROCESS( producer );

  producer( sc_module_name nm ) : sc_module( nm ) {
    m_i = 0;
  }

  void end_of_elaboration() {
    SC_METHOD( run );
    sensitive << p->ok_to_put();
  }

private:
  int m_i;

  void run() {
    
    sc_time t( 20 , SC_NS );

    if( m_i != 10 ) {

      if( p->nb_put( m_i , t ) ) {

        cout << name() << " just posted " << m_i;
        cout << " at time " << sc_time_stamp();
        cout << " for time " << sc_time_stamp() + t << endl;

        m_i++;
      }

    }

  }

};

int sc_main( int argc , char ** argv ) {

  tlm_annotated_fifo< int > fifo("annotated_fifo" , 1 );
  producer p("producer");
  consumer c("consumer");

  p.p( fifo );
  c.p( fifo );

  sc_start();

  return 0;
}
