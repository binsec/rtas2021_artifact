// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//              Othman Fathy, Mentor Graphics
//              Trevor Wieman, Intel Corp.
//
// Description: simple PVT bus
//
// ============================================================================

#ifndef TLM_PVT_BUS_H
#define TLM_PVT_BUS_H

#define PVT_MAX_INITIATORS     32
#define PVT_MAX_TARGETS      32

using namespace tlm;

template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE = tlm::TLM_PASS_BY_POINTER>
class tlm_pvt_bus
  : public sc_module
{
public:
  
  typedef tlm::tlm_request<ADDRESS, DATA, DATA_MODE>               request_type;
  typedef tlm::tlm_response<DATA, DATA_MODE>                       response_type;

  typedef tlm::tlm_annotated_master_if<request_type, response_type> master_interface_type;
  typedef tlm::tlm_annotated_slave_if<request_type,response_type> slave_interface_type;

  sc_port<slave_interface_type,PVT_MAX_INITIATORS> p_tlm_s;
  sc_port<master_interface_type, PVT_MAX_TARGETS > p_tlm_m;
        
  // this module has SC processes
  SC_HAS_PROCESS(tlm_pvt_bus);
  
  // --------------------------------------------------------------------
  void request_thread();
  void response_thread();
   
  // -----------------------------------------------------------------------
  // constuctor
  // ---------------------------------------------------------------------
  tlm_pvt_bus(sc_module_name mod, 
	      unsigned int nbr_intiators, 
	      unsigned int nbr_targets);
    
  void end_of_elaboration();
private:
  // -----------------------------------------------------------------------
  // Internal class members 
  // -----------------------------------------------------------------------

  request_type	m_req;
  response_type	m_resp;
  
  unsigned int	m_index;
  unsigned int	m_previous_read_index;
  int		m_outstanding_reads;
  sc_event	m_resp_event;
  sc_time	m_clk_period;
  sc_time	m_request_transfer_delay;
  sc_time	m_response_transfer_delay;
  sc_fifo<unsigned int> m_fifo;

  const unsigned int	m_nbr_initiators;
  const unsigned int	m_nbr_targets;
  sc_time m_response_resource_busy_until;
};

#include "tlm_pvt_bus.cpp"
#endif
