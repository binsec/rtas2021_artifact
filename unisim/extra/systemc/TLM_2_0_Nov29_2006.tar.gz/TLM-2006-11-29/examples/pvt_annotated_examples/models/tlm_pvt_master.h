// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//              Holger Keding, Synopsys Inc.
//              Trevor Wieman, Intel Corp.
//
// Description: declaration of simple TLM PVT master
//
// ============================================================================

#ifndef TLM_PVT_MASTER_H
#define TLM_PVT_MASTER_H

#include "tlm.h"  
#include <list>

template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE = tlm::TLM_PASS_BY_POINTER>
class tlm_pvt_master : public sc_module
{
  typedef tlm::tlm_request<ADDRESS, DATA, DATA_MODE>               request_type;
  typedef tlm::tlm_response<DATA, DATA_MODE>                       response_type;
  typedef tlm::tlm_annotated_master_if<request_type,response_type> interface_type;
  typedef sc_port<interface_type>                                  port_type;

  static const int max_block_size = 100;

public:
  SC_HAS_PROCESS(tlm_pvt_master);
  
  port_type p_tlm;

  tlm_pvt_master(sc_module_name mod, 
		 int nbr_threads);
  ~tlm_pvt_master();

  void end_of_elaboration();

private:

  void send_request_method ();
  void get_response_method ();

  std::vector<request_type*> m_reqs;
  response_type m_resp;
  int m_thread;
  int m_req_delay;
  int m_resp_pop_delay;
  int m_nbr_threads;
  int m_count_sent;
  int m_count_reads; // example transactor only responds to reads.
  int m_count_received;

  // Very simple identification; master_thread_id is m_instance_id + 
  // local thread_id.  m_instance_id's spaced by 100 to allow that many
  // local threads.
  static unsigned instance_count;
  const unsigned m_instance_id;
  unsigned m_transaction_count; // to generate unique (per master) transaction id
  sc_time m_busy_until;
};

/*----------------------------------------------
  definitions
  -----------------------------------------------*/

inline unsigned int uint_rand(unsigned int min_val, unsigned int max_val) 
{
  // equally distributed values between min_val and max_val
  return min_val+(int) ((1.0+max_val-min_val)*rand()/(RAND_MAX+1.0));
}
             
template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
tlm_pvt_master<ADDRESS, DATA, DATA_MODE>::tlm_pvt_master(sc_module_name mod, 
					      int nbr_threads):
  sc_module(mod), 
  p_tlm("p_tlm"),
  m_nbr_threads(nbr_threads),
  m_count_sent(0),
  m_count_reads(0),
  m_count_received(0),
  m_instance_id(++instance_count * 100),
  m_transaction_count(0),
  m_busy_until(SC_ZERO_TIME)
{
  // initial allocation of the request objects
  assert(m_nbr_threads > 0);
  for (int i=0; i<m_nbr_threads; i++) {
    request_type* req = new request_type;
    if (DATA_MODE==tlm::TLM_PASS_BY_POINTER) {
      DATA* buffer = new DATA[max_block_size];
      req->set_data_array(max_block_size, buffer);
    }
    m_reqs.push_back(req);    
  }

  cout << "tlm_pvt_master(" << this->name() << ") generating addresses 0..256 with max block size of "
       << max_block_size << endl;
}

template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
tlm_pvt_master<ADDRESS,DATA,DATA_MODE>::~tlm_pvt_master()
{
  cout << name() << " sent : " << m_count_sent 
       << " (" << m_count_reads << " reads), received : " 
       << m_count_received << endl;
}

template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
void tlm_pvt_master<ADDRESS,DATA,DATA_MODE>::end_of_elaboration()
{
  // declare sensitive methods
  SC_METHOD(send_request_method);
  sensitive << p_tlm->ok_to_put();

  SC_METHOD(get_response_method);
  sensitive << p_tlm->ok_to_peek();
  dont_initialize();
}


template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
void tlm_pvt_master<ADDRESS, DATA, DATA_MODE>::send_request_method()
{
  int thread_id;
  thread_id = uint_rand(0,m_nbr_threads-1);

  m_reqs[thread_id]->set_command((tlm::tlm_command)uint_rand(0,1));
  m_reqs[thread_id]->set_address(uint_rand(0x0,0x100-1));
  m_reqs[thread_id]->set_block_size(uint_rand(1,max_block_size));
  m_reqs[thread_id]->set_master_thread_id(m_instance_id + thread_id);
  m_reqs[thread_id]->set_transaction_id(++m_transaction_count);

  m_req_delay = uint_rand(10,50);
  if (!p_tlm->nb_put(*m_reqs[thread_id], sc_time(m_req_delay,SC_NS))) {
    cerr << "ERROR: tlm_pvt_master(" << name()
         << ") nb_put failure while processing request." << endl;
  }
  m_count_sent++;
  if (!m_reqs[thread_id]->get_command())
    m_count_reads++;
     
#if (defined DEBUG_TLM_PVT_MASTER || defined DEBUG_ALL) 
  cout << sc_time_stamp() << " tlm_pvt_master(" << name() << ") sending "
       << (char *)(m_reqs[thread_id]->get_command() ? "write" : "read")
       << " request " 
       << m_reqs[thread_id]->get_master_thread_id()
       << "." << m_reqs[thread_id]->get_transaction_id()
       << " with delay " << m_req_delay<< " ns" << endl;
#endif
}

template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
void tlm_pvt_master<ADDRESS, DATA, DATA_MODE>::get_response_method()
{
  if (!p_tlm->nb_peek(m_resp) ) {
    cerr << sc_time_stamp() << " get_response_method " << name() 
	 << ", nb_peek fails\n";
    return;
  }
  sc_time now = sc_time_stamp();
  if (m_busy_until > now) {
    cerr << now << " get_response_method " << name() 
	 << ", busy until " << m_busy_until << endl;;
  }
  m_count_received++;
  m_resp_pop_delay = uint_rand(25,25);

#if (defined DEBUG_TLM_PVT_MASTER) || (defined DEBUG_ALL) 
  cout << sc_time_stamp() << " tlm_pvt_master(" << name() << ")"
       << " accepting response "
       << m_resp.get_master_thread_id()
       << "." << m_resp.get_transaction_id()
       << " with delay " << m_resp_pop_delay << " ns" << endl;
#endif

  if (!p_tlm->nb_get(m_resp,sc_time(m_resp_pop_delay,SC_NS))) {
    cerr << sc_time_stamp() << " get_response_method " << name() 
	 << ", annotated nb_get fails\n";
  }
  m_busy_until = now + sc_time(m_resp_pop_delay,SC_NS);
}

// This should not be in the header (will cause multiple definitions), but
// but is o.k. for purposes of this example.
template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
unsigned tlm_pvt_master<ADDRESS, DATA, DATA_MODE>::instance_count = 0;

#endif // TLM_PVT_MASTER_H
