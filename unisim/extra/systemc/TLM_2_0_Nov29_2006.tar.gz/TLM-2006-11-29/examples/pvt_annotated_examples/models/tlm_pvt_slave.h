// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//              Holger Keding, Synopsys Inc.
//              Trevor Wieman, Intel Corp.
//
// Description: declaration of simple PVT slave
//
// ============================================================================

#ifndef TLM_PVT_SLAVE_H
#define TLM_PVT_SLAVE_H

#include "tlm.h"  
 
template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE = tlm::TLM_PASS_BY_POINTER>
class tlm_pvt_slave : public sc_module
{
  typedef tlm::tlm_request<ADDRESS, DATA, DATA_MODE>              request_type;
  typedef tlm::tlm_response<DATA, DATA_MODE>                      response_type;
  typedef tlm::tlm_annotated_slave_if<request_type,response_type> interface_type;
  typedef sc_port<interface_type>                                 port_type;

public:
  // this module has SC processes
  SC_HAS_PROCESS(tlm_pvt_slave);

  port_type p_tlm;  

  tlm_pvt_slave(sc_module_name mod, 
		int max_nbr_threads=1, 
		int min_pop_delay=10,
		int max_pop_delay=50,
		int min_response_delay=10,
		int max_response_delay=100);

  ~tlm_pvt_slave();

  void end_of_elaboration();

private:

  void request_method();
  void response_done_method();

  sc_time  m_delay;
  sc_time  m_new_response_due;
  sc_time* m_previous_response_due;
  int      m_nbr_threads;
  int      m_min_pop_delay, m_max_pop_delay, m_pop_delay;
  int      m_min_response_delay, m_max_response_delay, m_response_delay;
  int      m_req_count;
  int      m_resp_count;
  request_type m_req;
  response_type m_resp;

};

/*--------------------------------------------------
  definitions
  -------------------------------------------------*/
template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
tlm_pvt_slave<ADDRESS, DATA, DATA_MODE>::tlm_pvt_slave(sc_module_name mod, 
					    int nbr_threads,
					    int min_pop_delay,
					    int max_pop_delay,
					    int min_response_delay,
					    int max_response_delay):
  sc_module(mod), 
  p_tlm("p_tlm"),
  m_new_response_due(SC_ZERO_TIME),
  m_nbr_threads(nbr_threads),
  m_min_pop_delay(min_pop_delay),
  m_max_pop_delay(max_pop_delay),
  m_min_response_delay(min_response_delay),
  m_max_response_delay(max_response_delay),
  m_req_count(0),
  m_resp_count(0)
{
  assert(nbr_threads > 0);
  m_previous_response_due = new sc_time[m_nbr_threads];
  for (int i=0; i < m_nbr_threads; i++) {
    m_previous_response_due[i] = SC_ZERO_TIME;
  }
}


template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
void tlm_pvt_slave<ADDRESS, DATA, DATA_MODE>::end_of_elaboration()
{
  SC_METHOD(request_method);
  sensitive << p_tlm->ok_to_peek();
  dont_initialize();

#if (defined DEBUG_TLM_PVT_SLAVE || defined DEBUG_ALL) 
  SC_METHOD(response_done_method);
  sensitive << p_tlm->ok_to_put();
  dont_initialize();
#endif
}


template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
tlm_pvt_slave<ADDRESS, DATA, DATA_MODE>::~tlm_pvt_slave()
{
  cout << name() << ", received : " << m_req_count 
       << ", sent : " << m_resp_count << endl;
  delete [] m_previous_response_due;
}

template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
void tlm_pvt_slave<ADDRESS, DATA, DATA_MODE>::request_method()
{
  int thread_id;
 
  if (! p_tlm->nb_peek(m_req) ) {
    cerr << "ERROR: tlm_pvt_slave(" << name() 
         << ") nb_peek failure while processing request." << endl;
  }
  m_req_count++;

  // handle pop delay, might depend on some attributes in m_req
  m_pop_delay = uint_rand(m_min_pop_delay, m_max_pop_delay);

#if (defined DEBUG_TLM_PVT_SLAVE || defined DEBUG_ALL) 
  cout << sc_time_stamp() << " tlm_pvt_slave(" << name() << ")" 
       << " got request "
       << m_req.get_master_thread_id() 
       << "." << m_req.get_transaction_id()
       << "; scheduling pop in "
       << m_pop_delay << " ns" << endl;
#endif

  if (!p_tlm->nb_get(m_req,sc_time(m_pop_delay,SC_NS))) {
    cerr << "ERROR: tlm_pvt_slave(" << name() 
         << ") nb_get failure while processing request." 
	 << m_req.get_master_thread_id()
	 << "." << m_req.get_transaction_id() << endl
	 << endl;
  }
  
  if (m_req.get_command() == tlm::READ) {
  
    // handle response delay
    thread_id = m_req.get_master_thread_id();
    m_resp.set_master_thread_id(thread_id);
    m_resp.set_transaction_id(m_req.get_transaction_id());
    m_resp.set_block_size(m_req.get_block_size());

    // remove master id (multiples of 100);
    while (thread_id >= 100) thread_id -= 100;
    do {
      m_response_delay = uint_rand(m_min_response_delay, m_max_response_delay);
      
      // calculate delay from current sim.time to start of response:
      m_new_response_due = sc_time_stamp() + sc_time(m_response_delay, SC_NS);
      // prohibit out-of-order within one thread
    } while (m_new_response_due < m_previous_response_due[thread_id]);
    m_previous_response_due[thread_id] = m_new_response_due;
    
    // increment response counter
    m_resp_count++;
    if (!p_tlm->nb_put(m_resp,sc_time(m_response_delay, SC_NS))) {
      cerr << "ERROR @ " << sc_time_stamp() << ": tlm_pvt_slave(" << name() 
           << ") nb_put failure while processing response " 
	   << m_resp.get_master_thread_id()
	   << "." << m_resp.get_transaction_id() << endl
           << "      try increasing response depth of the " << p_tlm.basename() 
           << " port's channel." << endl;
    }
    else {
#if (defined DEBUG_TLM_PVT_SLAVE || defined DEBUG_ALL) 
      cout << sc_time_stamp() << " tlm_pvt_slave(" << name() << ")" 
	   << " scheduling read response "
	   << m_req.get_master_thread_id() 
	   << "." << m_req.get_transaction_id()
	   << " in " << m_response_delay << " ns" << endl;
#endif
    }
  }
}
template <typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
void tlm_pvt_slave<ADDRESS, DATA, DATA_MODE>::response_done_method()
{
  cout << sc_time_stamp() << " tlm_pvt_slave(" << name() << ")" 
       << " response_done\n";
}

#endif // TLM_PVT_SLAVE_H
