// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//              Holger Keding, Synopsys Inc.
//              Trevor Wieman, Intel Corp.
//
// Description: simple byte addressed PV memory declaration
//
// ============================================================================

#ifndef _TLM_PV_MEMORY_H
#define _TLM_PV_MEMORY_H

#include "tlm.h"
template<typename ADDRESS, typename DATA,
         tlm::tlm_data_mode DATA_MODE = tlm::TLM_PASS_BY_POINTER>
class tlm_pv_memory : 
  public sc_module, 
  public tlm::tlm_delayed_transport_if<tlm::tlm_request<ADDRESS, DATA, DATA_MODE>, tlm::tlm_response<DATA, DATA_MODE> >
{ 
  typedef tlm::tlm_request<ADDRESS, DATA, DATA_MODE> request_type;
  typedef tlm::tlm_response<DATA, DATA_MODE>         response_type;
  typedef tlm::tlm_delayed_transport_if<request_type, response_type>
					             interface_type;
  typedef sc_export<interface_type>                  target_export_type;

public :
  // Declare the PV interface port
  target_export_type p_pv;
    
  SC_HAS_PROCESS(tlm_pv_memory);
  
  tlm_pv_memory(sc_module_name name,
		unsigned int Size,
		unsigned int NumWaitStates = 0,
		double ClockPeriod = 1.0,
		bool UseExplicitTiming = false);
    
  // --- Destructor
  ~tlm_pv_memory();

  response_type transport(const request_type& req) 
  { cerr << "not implemented\n"; }
  
  void transport(const request_type& req, 
		 response_type& rsp,
		 sc_time& delay );

private : 
  unsigned int m_Size;
  unsigned int m_NumWaitStates;
  DATA*        m_MemoryBank;
  bool         m_UseExplicitTiming;
  sc_time      m_Delay;

}; // end class tlm_pv_memory


/*--------------------------------------------------------
  definitions
  -------------------------------------------------------*/

template<typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
tlm_pv_memory<ADDRESS, DATA, DATA_MODE>::tlm_pv_memory(sc_module_name   name,
unsigned int Size, unsigned int NumWaitStates, double ClockPeriod,
bool UseExplicitTiming)
  : sc_module(name)
  , p_pv("p_pv")	
  , m_Size(Size)
  , m_NumWaitStates(NumWaitStates)
  , m_UseExplicitTiming(UseExplicitTiming)
  , m_Delay(ClockPeriod, SC_NS)
{  
  p_pv.bind(*this);
  m_MemoryBank = new DATA[Size];
  
  if (m_UseExplicitTiming) {
    cout << "tlm_pv_memory(" << this->name() << ") will use explicit timing delay";
  } else {
    cout << "tlm_pv_memory(" << this->name() << ") will use implicit timing delay";
  }
  cout << "; size is " << m_Size << endl;
}

template<typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
tlm_pv_memory<ADDRESS, DATA, DATA_MODE>::~tlm_pv_memory() {
  delete [] m_MemoryBank;
}

template< typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
void
tlm_pv_memory<ADDRESS, DATA, DATA_MODE>::transport(const request_type& req, 
response_type& rsp, sc_time& delay) 
{
  ADDRESS      Addr;
  unsigned int BurstCount;
  
  Addr       = req.get_address();
  BurstCount = req.get_block_size();
  if (Addr + BurstCount >= m_Size)
     cout << "Addr: " << Addr << ", Block Size: " << BurstCount << endl;
  assert (Addr + BurstCount < m_Size);

  // Transfer pertinent fields from request to response (there may be a 
  // helper method provided for this in the future).
  rsp.set_block_size(req.get_block_size());
  rsp.set_priority(req.get_priority());
  rsp.set_master_thread_id(req.get_master_thread_id());
  rsp.set_transaction_id(req.get_transaction_id());
  
  if (req.get_command() == tlm::WRITE) {
    memcpy(m_MemoryBank + Addr, req.get_data_ptr(), BurstCount * sizeof(DATA));
  } else {
    if (DATA_MODE == tlm::TLM_PASS_BY_COPY) {
      rsp.set_data_array(BurstCount, m_MemoryBank + Addr);
    }
    else {
      DATA *pData = const_cast<DATA *>(req.get_data_ptr());
      // According to tlm_bus pointer mode rules, the slave must copy data
      // pointers from the request to the response.
      rsp.set_data_array(BurstCount, pData);
      memcpy(pData, m_MemoryBank + Addr, BurstCount * sizeof(DATA));
    }
  }
 
 if (m_UseExplicitTiming) {
    wait(m_Delay * m_NumWaitStates * BurstCount);
    delay = SC_ZERO_TIME;
 } else {
   delay = m_Delay * m_NumWaitStates * BurstCount;
 }
 tlm::tlm_status status;
 status.set_ok();
 rsp.set_status(status);  
}

#endif //_TLM_PV_MEMORY_H
