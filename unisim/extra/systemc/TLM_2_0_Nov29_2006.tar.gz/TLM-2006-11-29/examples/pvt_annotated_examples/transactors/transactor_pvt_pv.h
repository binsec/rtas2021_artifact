// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//
// Description: Definition of PVT slave to PV master transactor
//
// ============================================================================

#ifndef _TRANSACTOR_PVT_PV_H
#define _TRANSACTOR_PVT_PV_H

#include "tlm.h"  
  
template< typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE = tlm::TLM_PASS_BY_POINTER>
class transactor_pvt_pv : public sc_module 
{    
  typedef tlm::tlm_request<ADDRESS, DATA, DATA_MODE>                   request_type;
  typedef tlm::tlm_response<DATA, DATA_MODE>                           response_type;
  
  typedef tlm::tlm_annotated_slave_if<request_type, response_type>     pvt_interface_type;
  typedef tlm::tlm_delayed_transport_if<request_type,response_type>  pv_interface_type;
  
public:
  SC_HAS_PROCESS( transactor_pvt_pv ); 
  
  // Constructor
  transactor_pvt_pv( sc_module_name nm,
		     sc_time pop_delay = SC_ZERO_TIME,
		     sc_time response_delay = SC_ZERO_TIME);
  
  // Destructor
  virtual ~transactor_pvt_pv();
    
  sc_port<pvt_interface_type> p_tlm_pvt;
  sc_port<pv_interface_type>  p_tlm_pv;
  
protected:
  void end_of_elaboration();
  
private:
  // Process thread & method bodies
  void request_thread();
  void send_response_thread();
  
  request_type  m_req;
  response_type m_resp;
  
  sc_time m_pop_delay;
  sc_time m_response_delay;
  sc_time m_annotation;

  // disable default and copy constructors
  transactor_pvt_pv();
  transactor_pvt_pv( const transactor_pvt_pv & );          
  transactor_pvt_pv & operator= ( const transactor_pvt_pv & );
  
};// end class definition

/*-------------------------------------------------
  definitions
  -----------------------------------------------*/

template< typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
inline
transactor_pvt_pv<ADDRESS, DATA, DATA_MODE>::transactor_pvt_pv( sc_module_name nm,
								sc_time pop_delay,
								sc_time response_delay )
  : sc_module( nm )
  , p_tlm_pvt("p_tlm_pvt")
  , p_tlm_pv("p_tlm_pv")
  , m_pop_delay(pop_delay)
  , m_response_delay(response_delay)
  , m_annotation(SC_ZERO_TIME)
{
}				      

template< typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
inline void transactor_pvt_pv<ADDRESS, DATA, DATA_MODE>::end_of_elaboration()
{
  SC_THREAD(request_thread); // thread to allow PV slave to call wait
  sensitive << p_tlm_pvt->ok_to_peek(); 
  dont_initialize();
}


template< typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
inline transactor_pvt_pv<ADDRESS, DATA, DATA_MODE>::~transactor_pvt_pv() 
{}


//----------------------------------------------------------------------------------------------------
// request_thread()
// Process method triggered by PVT channel Request Start Event
//
template< typename ADDRESS, typename DATA, tlm::tlm_data_mode DATA_MODE>
inline
void transactor_pvt_pv<ADDRESS, DATA, DATA_MODE>::request_thread() 
{
  while(1) {
#if (defined DEBUG_TRANSACTOR_PVT_PV) || (defined DEBUG_ALL)  
    cout << sc_time_stamp() << " transactor_pvt_pv(" << name() << ")"
         << " received request start M->S event" << endl;
#endif
    if (!p_tlm_pvt->nb_peek( m_req)) {
      cerr << "ERROR: " << sc_time_stamp() 
	   << " transactor_pvt_pv(" << name() << ")"
	   << " nb_peek fails\n";
      return;
    }
    p_tlm_pv->transport(m_req,m_resp,m_annotation);
    if (!p_tlm_pvt->nb_get(m_req,m_pop_delay)) {
      cerr << "ERROR: " << sc_time_stamp() 
	   << " transactor_pvt_pv(" << name() << ")"
	   << " nb_get with delay " << m_pop_delay << " fails\n";
      return;
    }
    
    if (m_req.get_command() == tlm::READ) {
      // we need to send a response
      if (p_tlm_pvt->nb_can_put(m_annotation + m_response_delay )) {
	p_tlm_pvt->nb_put( m_resp, m_annotation + m_response_delay );
#if (defined DEBUG_TRANSACTOR_PVT_PV) || (defined DEBUG_ALL)  
	cout << sc_time_stamp() << " transactor_pvt_pv(" << name() << ")"
	     << " scheduling read response with delay " 
	     << m_annotation + m_response_delay << endl;
#endif	
      } else {
	cerr << "ERROR: " << sc_time_stamp() 
	     << " transactor_pvt_pv(" << name() << ")"
	     << " scheduling read response with delay " 
	     << m_annotation + m_response_delay << endl;
      }
    }
    wait(); // wait for next request event	  
  } // end while(1)
}


#endif // _TRANSACTOR_PVT_PV_H

