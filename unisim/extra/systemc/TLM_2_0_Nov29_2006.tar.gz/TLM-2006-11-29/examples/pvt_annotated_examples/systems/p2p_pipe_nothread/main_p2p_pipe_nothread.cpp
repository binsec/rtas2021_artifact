// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//              Holger Keding, Synopsys Inc.
//              Trevor Wieman, Intel Corp.
//
// Description: simple point-to-point PVT example system
//
// ============================================================================

#include "tlm.h"  

#include "tlm_pvt_master.h"
#include "tlm_pvt_slave.h"
#include "tlm_pvt_annotated_fifo.h"

int sc_main(int, char*[])
{
  int sim_time = 50000;

  typedef unsigned int addr_type;
  typedef unsigned int data_type;
#ifdef PASS_BY_COPY
  const tlm::tlm_data_mode data_mode = tlm::TLM_PASS_BY_COPY ;
#else
  const tlm::tlm_data_mode data_mode = tlm::TLM_PASS_BY_POINTER ;
#endif

  typedef tlm::tlm_request<addr_type,data_type,data_mode> request_type;
  typedef tlm::tlm_response<data_type,data_mode>          response_type;

  typedef tlm_pvt_master<addr_type, data_type, data_mode> master_type;
  typedef tlm_pvt_slave<addr_type, data_type, data_mode>  slave_type;

  typedef tlm_pvt_annotated_fifo<request_type> request_fifo_type;
  typedef tlm_pvt_annotated_fifo<response_type> response_fifo_type;

  typedef tlm::tlm_annotated_req_rsp_channel<request_type,response_type,request_fifo_type,response_fifo_type> channel_type;

  channel_type channel("channel",1,-1); // unbounded response fifo required

  int nbr_threads = 1;

  master_type master("master",nbr_threads);
  slave_type slave("slave",nbr_threads,10,10,50,50);
  // response-delay > pop-delay models pipelined target

  master.p_tlm(channel.master_export);
  slave.p_tlm(channel.slave_export);

  // Starts simulation 
  sc_start(sim_time, SC_NS);

  return (0);
};
