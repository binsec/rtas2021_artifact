// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//              Othman Fathy, Mentor Graphics
//              Trevor Wieman, Intel Corp.
//
// Description: simple PVT bus based example with 2 masters and 3 slaves
//
// ============================================================================

#include "tlm.h"  
#include "tlm_pvt_master.h"
#include "tlm_pvt_slave.h"
#include "tlm_pvt_bus.h"
#include "tlm_pvt_annotated_fifo.h"

int sc_main(int, char*[])
{
  int sim_time = 36000;

  typedef unsigned int addr_type;
  typedef unsigned int data_type;
#ifdef PASS_BY_COPY
  const tlm::tlm_data_mode data_mode = tlm::TLM_PASS_BY_COPY ;
#else
  const tlm::tlm_data_mode data_mode = tlm::TLM_PASS_BY_POINTER ;
#endif
  
  typedef tlm::tlm_request<addr_type,data_type,data_mode> request_type;
  typedef tlm::tlm_response<data_type,data_mode>          response_type;

  typedef tlm_pvt_master<addr_type, data_type, data_mode> master_type;
  typedef tlm_pvt_slave<addr_type, data_type, data_mode>  slave_type;
  typedef tlm_pvt_bus<addr_type, data_type, data_mode>    bus_type;

  typedef tlm_pvt_annotated_fifo<request_type> request_fifo_type;
  typedef tlm_pvt_annotated_fifo<response_type> response_fifo_type;
  typedef tlm::tlm_annotated_req_rsp_channel<request_type,response_type,request_fifo_type,response_fifo_type> channel_type;

  bus_type bus("bus",2,3);

  channel_type ch_m0("ch_m0",1,1);
  channel_type ch_m1("ch_m1",1,1);
  channel_type ch_s0("ch_s0",1,5);
  channel_type ch_s1("ch_s1",1,6);
  channel_type ch_s2("ch_s2",1,5);

  int max_nbr_threads = 1;

  master_type m0("m0",max_nbr_threads);
  master_type m1("m1",max_nbr_threads);
  slave_type s0("s0",max_nbr_threads,10,10,10,10);
  slave_type s1("s1",max_nbr_threads,10,10,10,10);
  slave_type s2("s2",max_nbr_threads,10,10,10,10);

  m0.p_tlm(ch_m0.master_export);
  m1.p_tlm(ch_m1.master_export);
  bus.p_tlm_s(ch_m0.slave_export);
  bus.p_tlm_s(ch_m1.slave_export);

  bus.p_tlm_m(ch_s0.master_export);
  bus.p_tlm_m(ch_s1.master_export);
  bus.p_tlm_m(ch_s2.master_export);
  s0.p_tlm(ch_s0.slave_export);
  s1.p_tlm(ch_s1.slave_export);
  s2.p_tlm(ch_s2.slave_export);

  // Starts simulation 
  sc_start(sim_time, SC_NS);

  return (0);
};
