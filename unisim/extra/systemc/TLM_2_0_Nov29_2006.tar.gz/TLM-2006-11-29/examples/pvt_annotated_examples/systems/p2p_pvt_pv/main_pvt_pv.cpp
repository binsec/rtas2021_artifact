// ============================================================================
//
//     Project: OSCI TLM WG, PVT Examples
//
//     Authors: Tim Kogel, CoWare Inc.
//              Holger Keding, Synopsys Inc.
//              Trevor Wieman, Intel Corp.
//
// Description: simple point-to-point PV/PVT example system
//
// ============================================================================

#include "tlm.h"  

#include "tlm_pvt_master.h"
#include "tlm_pv_memory.h"
#include "tlm_pvt_annotated_fifo.h"
#include "transactor_pvt_pv.h"

int sc_main(int, char*[])
{
  int sim_time = 50000;

  typedef unsigned int addr_type;
  typedef unsigned int data_type;
#ifdef PASS_BY_COPY
  const tlm::tlm_data_mode data_mode = tlm::TLM_PASS_BY_COPY ;
#else
  const tlm::tlm_data_mode data_mode = tlm::TLM_PASS_BY_POINTER ;
#endif

  typedef tlm::tlm_request<addr_type,data_type,data_mode>    request_type;
  typedef tlm::tlm_response<data_type,data_mode>             response_type;

  typedef tlm_pvt_master<addr_type, data_type, data_mode>    master_type;
  typedef tlm_pv_memory<addr_type, data_type, data_mode>     slave_type;
  typedef transactor_pvt_pv<addr_type, data_type, data_mode> transactor_type;

  typedef tlm_pvt_annotated_fifo<request_type>  request_fifo_type;
  typedef tlm_pvt_annotated_fifo<response_type> response_fifo_type;
  typedef tlm::tlm_annotated_req_rsp_channel<request_type,response_type,request_fifo_type,response_fifo_type> channel_type;


  channel_type channel("channel",1,-1);

  int nbr_threads = 1;

  sc_time pop_delay = sc_time(5,SC_NS);
  sc_time response_delay = sc_time(5,SC_NS);

  master_type master("master",nbr_threads);
  slave_type slave("slave", 356, 1); // 256 addr range & 100 max block size; 
                                     // 1 wait state
  
  transactor_type transactor("transactor",pop_delay,response_delay);

  master.p_tlm(channel.master_export);
  transactor.p_tlm_pvt(channel.slave_export);
  transactor.p_tlm_pv(slave.p_pv);

  // Starts simulation 
  sc_start(sim_time, SC_NS);

  return (0);
};
