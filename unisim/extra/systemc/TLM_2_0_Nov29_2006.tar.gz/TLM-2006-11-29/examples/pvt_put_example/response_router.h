/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/


#ifndef _RESPONSE_ROUTER_H_
#define _RESPONSE_ROUTER_H_

#include <vector>
#include "systemc.h"
#include "tlm.h"

template <typename ADDRESS, 
          typename DATA>
class response_router : 
  public sc_module,
  public virtual tlm::tlm_blocking_put_if <tlm::tlm_response<DATA> >
{
  typedef tlm::tlm_response<DATA>                               response_type;
  typedef tlm::tlm_blocking_put_if<response_type>               interface_response_type;
  typedef tlm::tlm_initiator_port<interface_response_type, 1 >  initiator_port_type;
  typedef tlm::tlm_target_port<interface_response_type >        target_port_type;

public:

  /// time delay to propagate the response
  sc_time response_router_delay;

  /// Store target responses
  std::deque<response_type> response_q;
  sc_event response_event;
  sc_event event_sent;

  /// Initiator ports (to connect to the target IP)
  std::vector<initiator_port_type *> initiator_port_list; 

  /// Target ports (to connect to the Initiator IP)
  std::vector<target_port_type *> target_port_list;

  SC_HAS_PROCESS(response_router);
  response_router(sc_module_name module_name,
		  int nb_initiator_port,
		  int nb_target_port
		  );
  
  ~response_router();

  void end_of_elaboration();

  /// Receive response from slave
  virtual void put( const response_type &t );

  /// Send response to traffic generator
  void route();

};

// Include implementation
#include "./response_router.tpp"

#endif /* _RESPONSE_ROUTER_H_ */


