/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/


#include "slave.h"

slave::slave(sc_module_name module_name,
	     unsigned int fifo_size
	     ) :
  sc_module(module_name),
  m_request_fifo(fifo_size),
  slave_delay(2, SC_NS),
  reception_delay(2, SC_NS),
  request_port("request_port"),
  response_port("response_port"){

  SC_THREAD(send_response);

  // Bind tac target sc_export to the slave 
  request_port(*this);

  cout << name() << " creation" << endl;
}


slave::~slave() {

  cout << name() << ": Destructor called, slave released" << endl;
}

/// Receive request from initiator through the router
void slave::put(const request_type& request) {

  /// Modeled propagation delay of the transaction between the router and the slave
  wait(reception_delay);

  cout << name() << ": received a request" << endl;
  m_request_fifo.put(request);

}


/// Send response to the initiator through the router
void slave::send_response()
{
  request_type request;
  int data = 0x10;
  tlm::tlm_status status;

  while (1) {// main loop

    request = m_request_fifo.get();
  
    if (request.get_command() == tlm::READ) {// send the response
      response_type response;

      status.set_ok();
      response.set_master_thread_id(request.get_master_thread_id());
      response.set_transaction_id(request.get_transaction_id());
      response.set_status(status);
      response.set_data(data);
      
      cout << name() << ": Read " << std::showbase << hex << data << " at " << request.get_address() << endl;

      /// Modeled the processing delay to compute the response
      wait(slave_delay);
      
      // Send response to the initiator
      response_port->put(response);
    }
  }
}

/* END of slave.cpp */
