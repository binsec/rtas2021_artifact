/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/


#include "traffic_generator.h"

using namespace std;
using tlm::tlm_mode;

traffic_generator::traffic_generator(sc_module_name module_name,
				     int mem_base) :
  sc_module(module_name),
  m_mem_base(mem_base),
  traffic_generator_delay(3, SC_NS),
  request_port("request_port"),
  response_port("response_port") {

  // Bind response target sc_export to the slave 
  response_port(*this);

  // Traffic generator thread
  SC_THREAD(run);
  m_transaction_id = 0x0;
  master_thread_id = 0x1000;

  cout << name() << " creation" << endl;
  
}
    
traffic_generator::~traffic_generator() {
  cout << name() << ": Destructor called" << endl;
} 

/// Receive responses sent by the slave through the router
void traffic_generator::put(const response_type& response) {

  wait(traffic_generator_delay);

  cout << name() << ": received a response with id " << response.get_transaction_id() 
       << " T:" << sc_time_stamp() << endl;
}

/// Initiator thread sending requests through the router
void traffic_generator::run() {

  unsigned int transaction_id;
  request_type request;
  tlm::tlm_command command;

  for (int i=0; i<4; i++) {
    transaction_id = m_transaction_id;
    m_transaction_id++;
    command = i%2?tlm::WRITE:tlm::READ;

    request.set_command(command);
    if(command == tlm::WRITE)
      request.set_data(i);
    request.set_address(m_mem_base+i*sizeof(int));
    request.set_transaction_id(transaction_id);
    request.set_master_thread_id(master_thread_id);

    // Send request to the target
    request_port->put(request);

    cout << name() << ": Request sent" << endl;
  }
}

/* END of traffic_generator.cpp */
