/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

#ifndef _TRAFFIC_GENERATOR_H_
#define _TRAFFIC_GENERATOR_H_

/*------------------------------------------------------------------------------
 * Includes
 *----------------------------------------------------------------------------*/ 
#include <iostream>

#include "systemc.h"
#include "tlm.h"

//---------------------------------------------------------------------------- 

/// Class traffic_generator
/**
 * \n The traffic_generator is doing Write/Read Access into the
 * \n slave component.
**/
//---------------------------------------------------------------------------- 

class traffic_generator : 
  public sc_module,
  public tlm::tlm_blocking_put_if<tlm::tlm_response<int> >
{
  
  typedef tlm::tlm_request<int, int>                       request_type;
  typedef tlm::tlm_response<int>                           response_type;
  typedef tlm::tlm_blocking_put_if<response_type>          interface_response_type;
  typedef tlm::tlm_blocking_put_if<request_type>           interface_request_type;

  int m_mem_base;                        ///< slave read/write test base address

private:

  /// time delay for response
  sc_time traffic_generator_delay;

  unsigned int m_transaction_id;
  unsigned int master_thread_id;

public :

  tlm::tlm_initiator_port<interface_request_type, 1>  request_port;
  tlm::tlm_target_port<interface_response_type>       response_port;

  SC_HAS_PROCESS(traffic_generator);
  traffic_generator(sc_module_name module_name,
		     int mem_base = 0);
    
  ~traffic_generator();

  /// Receive responses sent by the slave through the router
  virtual void put(const response_type& response);

  /// Initiator thread sending requests through the router
  void run();

};


#endif /* _TRAFFIC_GENERATOR_H_ */
