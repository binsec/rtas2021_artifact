/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/


#ifndef _SLAVE_H_
#define _SLAVE_H_

#include <exception>
#include <iostream>
#include <iomanip>
#include "systemc.h"
#include "tlm.h"

class slave : 
  public sc_module,
  public tlm::tlm_blocking_put_if<tlm::tlm_request<int, int> >
{

  typedef tlm::tlm_request<int, int >                         request_type;
  typedef tlm::tlm_response<int >                             response_type;
  typedef tlm::tlm_blocking_put_if<request_type >             interface_request_type;
  typedef tlm::tlm_blocking_put_if<response_type >            interface_response_type;

private:

  tlm::tlm_fifo<tlm::tlm_request<int, int> > m_request_fifo;

  sc_time slave_delay;
  sc_time reception_delay;

public :

  tlm::tlm_target_port<interface_request_type >         request_port;
  tlm::tlm_initiator_port<interface_response_type, 1 >  response_port;

  SC_HAS_PROCESS(slave);
  slave(sc_module_name module_name,
	unsigned int fifo_size = 1);  

  ~slave();

  /// Send response to the initiator through the router
  void send_response();

  /// Receive request from initiator through the router
  virtual void put(const request_type& request);

};

#endif /* _SLAVE_H_ */


