/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

#include "slave.h"



//-----------------------------------------------------------------------------------
slave::slave(sc_module_name module_name) :
  sc_module( module_name ),
  target_port1("target_port1"),
  target_port2("target_port2") {

  target_port1(*this);
  target_port2(*this);

  // export ID must be defined before end of elaboration
  target_port1.set_tlm_export_id(PORT1_ID); 
  target_port2.set_tlm_export_id(PORT2_ID);

}


//-----------------------------------------------------------------------------------
slave::~slave() {}

//-----------------------------------------------------------------------------------
tlm::tlm_response<int> slave::transport(const tlm::tlm_request<int,int>& request) {

  tlm::tlm_response<int> response;



  switch(request.get_tlm_export_id()) {
    
  case PORT1_ID:

    std::cout << "Slave has received a request through its first target port" <<  std::endl;

    break;

  case PORT2_ID:
    std::cout << "Slave has received a request through its second target port" <<  std::endl;
    break;
  
  default:
    std::cout << "Slave has received a request with an unknown tlm_export_id" <<  std::endl;
    break;
  }
  
  return(response);
}


/* END of slave.cpp */
