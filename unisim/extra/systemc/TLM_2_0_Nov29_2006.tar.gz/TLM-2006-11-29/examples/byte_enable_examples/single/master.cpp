/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

#include "master.h"

//-----------------------------------------------------------------------------------
master::master(sc_module_name module_name,
	       tlm::tlm_endianness endian) :
  sc_module( module_name ), 
  initiator_port("initiator_port"),
  m_endian(endian) {

  SC_THREAD( run );
}

//-----------------------------------------------------------------------------------
master::~master() {}


//-----------------------------------------------------------------------------------
void master::print_result(int address,tlm::tlm_response<int>& response) {
  if (response.get_status().is_ok()) {
    std::cout << "Result: \n";
    for (unsigned int i =0;i< response.get_block_size();i++) {
      std::cout << std::hex << resetiosflags (std::ios_base::showbase) << "\t0x" << (address+i*tlm::get_nb_byte<int>())
		<< ": 0x" << std::setfill('0') << std::setw(2*tlm::get_nb_byte<int>()) 
		<< response.get_data(i) << std::endl;
    }
  }
  else std::cout << "ERROR during target access" << std::endl;
}

//-----------------------------------------------------------------------------------
void master::run() {

  std::cout << std::showbase << std::hex << std::endl; 
  
  tlm::tlm_request<int,int> request;
  tlm::tlm_response<int> response;

  int value = 0x11;
  int address = 0x0;
  int offset = 1;

  std::cout << "-----------------------------------------------\n" ;
  std::cout << "Master is going to write at word address " << address << " the byte (value: " << value << ") \nwith a byte address offset of " << offset << std::endl;

  request.set_command( tlm::WRITE );
  request.set_address( address );
  request.set_data( tlm::align_byte_to_tlm<int,int>( address + offset, value, m_endian ) ); 
  request.set_byte_enable( tlm::be_byte<int,int>( address + offset ) );

  response = initiator_port->transport( request );

  std::cout << "-----------------------------------------------\n" ;
  address += tlm::get_nb_byte<int>();
  value = 0x22;
  offset = 3;
  std::cout << "Master is going to write at word address " << address << " the byte (value: " << value << ") \nwith a byte address offset of " << offset <<  std::endl;

  request.set_command( tlm::WRITE );
  request.set_address( address );
  request.set_data( tlm::align_byte_to_tlm<int,int>( address + offset, value, m_endian ) ); 
  request.set_byte_enable( tlm::be_byte<int,int>( address + offset ) );

  response = initiator_port->transport( request );


  std::cout << "-----------------------------------------------\n" ;
  address += tlm::get_nb_byte<int>();
  offset = 1;
  value = 0x3333;
  std::cout << "Master is going to write at word address " << address << " the half-word (value: " << value << ") \nwith a half-word address offset of " << offset << std::endl;

  request.set_command( tlm::WRITE );
  request.set_address( address );
  request.set_data( tlm::align_short_to_tlm<int,int>( address + offset, value, m_endian ) ); 
  request.set_byte_enable( tlm::be_short<int,int>( address + offset ) );

  response = initiator_port->transport( request );

  std::cout << "-----------------------------------------------\n" ;
  address += tlm::get_nb_byte<int>();
  value = 0x10203040;
  std::cout << "Master is going to write at word address " << address << " the byte located at address + 1 \nand the byte located at address + 3 of the word: " << value << std::endl;

  request.set_command( tlm::WRITE );
  request.set_address( address );
  request.set_data( value );
  request.set_byte_enable( tlm::be_byte<int,int>( address + 1 ) |
			   tlm::be_byte<int,int>( address + 3 )
			   );

  response = initiator_port->transport( request );
    


  std::cout << "-----------------------------------------------\n" ;
  std::cout << "Master is going to read the four word previously written: \n";

  address = 0x0;
  request.set_command( tlm::READ );
  request.set_address( address );
  request.set_byte_enable( tlm::NO_BE );
  request.set_block_size( 4 );
  request.set_block_mode( tlm::INCREMENT );
  request.set_block_address_incr( tlm::get_nb_byte<int>() );

  response = initiator_port->transport(request);
    
  print_result( address,response );


  std::cout << std::endl; 
}


/* END of master.cpp */
