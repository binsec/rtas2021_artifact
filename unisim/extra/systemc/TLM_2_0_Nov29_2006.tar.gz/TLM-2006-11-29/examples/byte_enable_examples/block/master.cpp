/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

#include "master.h"


//-----------------------------------------------------------------------------------
master::master(sc_module_name module_name,
	       tlm::tlm_endianness endian) :
  sc_module( module_name ), 
  initiator_port("initiator_port"),
  m_endian(endian) {

  SC_THREAD( run );
}


//-----------------------------------------------------------------------------------
master::~master() {}


//-----------------------------------------------------------------------------------
void master::print_result(int address,tlm::tlm_response<int>& response) {
  if (response.get_status().is_ok()) {
    std::cout << "Result: \n";
    for (unsigned int i =0;i< response.get_block_size();i++) {
      std::cout << std::hex << resetiosflags (std::ios_base::showbase) << "\t0x" << (address+i*tlm::get_nb_byte<int>())
		<< ": 0x" << std::setfill('0') << std::setw(2*tlm::get_nb_byte<int>()) 
		<< response.get_data(i) << std::endl;
    }
  }
  else std::cout << "ERROR during target access" << std::endl;
}

//-----------------------------------------------------------------------------------
void master::run() {

  std::cout << std::showbase << std::hex << std::endl; 

  tlm::tlm_request<int,int> request;
  tlm::tlm_response<int> response;

  int address = 0x0;
  const int BLOCK_SIZE = 4;
  int block_value[BLOCK_SIZE];
  unsigned int block_byte_enable[BLOCK_SIZE];

  std::cout << "-----------------------------------------------\n" ;
  std::cout << "Master is going to write block of four words pattern at word address " << address <<  std::endl;

  block_value[0] = 0x01020304;
  block_value[1] = 0x11121314;
  block_value[2] = 0x21222324;
  block_value[3] = 0x31323334;

  request.set_command( tlm::WRITE );
  request.set_address( address );
  request.set_data_array( BLOCK_SIZE, block_value );
  request.set_byte_enable_array( 0 ); // Clears the byte_enable array

  /* Note : NULL request's m_byte_enable_array means NO_BE (no byte_enable) 
     for all word of the block 
  */

  request.set_block_mode( tlm::INCREMENT );
  request.set_block_address_incr( tlm::get_nb_byte<int>() );

  response = initiator_port->transport( request );


  std::cout << "-----------------------------------------------\n" ;
  std::cout << "Master is going to read a block of four words at word address " << address << " using byte enable.\nThe byte enable is different for each read word of the block.\n " << std::endl;

  request.set_command( tlm::READ );
  block_byte_enable[0] = tlm::be_byte<int,int>(1);
  block_byte_enable[1] = tlm::be_byte<int,int>(0) | tlm::be_byte<int,int>(2);
  block_byte_enable[2] = tlm::be_short<int,int>(1);
  block_byte_enable[3] = tlm::NO_BE;
  request.set_byte_enable_array( BLOCK_SIZE,block_byte_enable );

  response = initiator_port->transport( request );

  print_result( address,response );  

  std::cout << "-----------------------------------------------\n" ;
  std::cout << "Master is going to read a block of four words at word address " << address << " using byte enable.\nThe byte enable is the same for all read word of the block.\n " << std::endl;

  block_byte_enable[0] = tlm::be_byte<int,int>(2);
  request.set_byte_enable_array( BLOCK_SIZE,block_byte_enable );
  request.set_byte_enable_period( 1 ); // Period of the byte_enable pattern. 

  /* Note that the size parameter of set_byte_enable_array(size,src_be_ptr) could 
     be used to set the m_byte_enable_array size AND the m_byte_enable_period 
     request's attributes.

     Reminder: if m_byte_enable_period is not null, the size of the byte_enable_array is
               m_byte_enable_period, m_block_size is used otherwise.               
  */


  response = initiator_port->transport( request );
  

  print_result(address,response);
  

  std::cout << "-----------------------------------------------\n" ;
  std::cout << "Master is going to read a block of four words at word address " << address << " using byte enable.\nThe byte enable used is a pattern of 2 byte_enable values applied to the block.\n " << std::endl;

  block_byte_enable[0] = tlm::be_byte<int,int>(0);
  block_byte_enable[1] = tlm::be_byte<int,int>(3);
  request.set_byte_enable_array(2,block_byte_enable); // Sets the byte_enable_array AND the byte_enable_period

  response = initiator_port->transport( request );
  
  print_result(address,response);

 
  std::cout << std::endl; 

}


/* END of master.cpp */
