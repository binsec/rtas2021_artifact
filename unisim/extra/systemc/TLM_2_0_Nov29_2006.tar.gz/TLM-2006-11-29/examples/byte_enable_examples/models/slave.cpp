/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

#include "slave.h"


//-----------------------------------------------------------------------------------
const int slave::m_memory_size = 0x10;

//-----------------------------------------------------------------------------------
slave::slave(sc_module_name module_name,
	     tlm::tlm_endianness endian) :
  sc_module( module_name ),
  target_port("target_port"),
  m_endian(endian) {

  target_port(*this);

  m_memory = new int[m_memory_size/tlm::get_nb_byte<int>()];

  memset(m_memory,0,m_memory_size/tlm::get_nb_byte<int>());
}


//-----------------------------------------------------------------------------------
slave::~slave() {
  delete [] m_memory;
}


//-----------------------------------------------------------------------------------
int slave::read(int address,unsigned int byte_enable) {

  int data = 0;
  int tmp = m_memory[address/tlm::get_nb_byte<int>()];

  std::cout << std::showbase << std::hex;
  std::cout << "Slave has received a read request at " << address;

  if (!tlm::is_no_be<int>(byte_enable)) {
    std::cout << " (with byte_enable: " << byte_enable << ")";
    
    if (m_endian == tlm::TLM_BIG_ENDIAN ) {
      if (byte_enable & tlm::BYTE_LANE_0) data |= tmp & 0xff000000;
      if (byte_enable & tlm::BYTE_LANE_1) data |= tmp & 0x00ff0000;
      if (byte_enable & tlm::BYTE_LANE_2) data |= tmp & 0x0000ff00;
      if (byte_enable & tlm::BYTE_LANE_3) data |= tmp & 0x000000ff;
    }
    else {
      if (byte_enable & tlm::BYTE_LANE_0) data |= tmp & 0x000000ff;
      if (byte_enable & tlm::BYTE_LANE_1) data |= tmp & 0x0000ff00;
      if (byte_enable & tlm::BYTE_LANE_2) data |= tmp & 0x00ff0000;
      if (byte_enable & tlm::BYTE_LANE_3) data |= tmp & 0xff000000;
    }
  }
  else data = tmp;

  std::cout << ", returns: " << data << std::endl;      

  return(data);
}



//-----------------------------------------------------------------------------------
void slave::write(int address,int data,unsigned int byte_enable) {

  std::cout << std::showbase << std::hex;
  std::cout << "Slave has received a write request at " << address << ": " << data;
  
  if (!tlm::is_no_be<int>(byte_enable)) {
    
    std::cout <<" (with byte_enable: " << byte_enable <<  ")";

    int tmp = m_memory[address/tlm::get_nb_byte<int>()];
    
    if (m_endian == tlm::TLM_BIG_ENDIAN ) {
      if (byte_enable & tlm::BYTE_LANE_0) tmp = (tmp & 0x00ffffff) | (data & 0xff000000);
      if (byte_enable & tlm::BYTE_LANE_1) tmp = (tmp & 0xff00ffff) | (data & 0x00ff0000);
      if (byte_enable & tlm::BYTE_LANE_2) tmp = (tmp & 0xffff00ff) | (data & 0x0000ff00);
      if (byte_enable & tlm::BYTE_LANE_3) tmp = (tmp & 0xffffff00) | (data & 0x000000ff);
    }
    else {
      if (byte_enable & tlm::BYTE_LANE_0) tmp = (tmp & 0xffffff00) | (data & 0x000000ff);
      if (byte_enable & tlm::BYTE_LANE_1) tmp = (tmp & 0xffff00ff) | (data & 0x0000ff00);
      if (byte_enable & tlm::BYTE_LANE_2) tmp = (tmp & 0xff00ffff) | (data & 0x00ff0000);
      if (byte_enable & tlm::BYTE_LANE_3) tmp = (tmp & 0x00ffffff) | (data & 0xff000000);
    }
    m_memory[address/tlm::get_nb_byte<int>()] = tmp; 
  }
  else m_memory[address/tlm::get_nb_byte<int>()] = data;
  
  std::cout << std::endl;
}




//-----------------------------------------------------------------------------------
tlm::tlm_response<int> slave::transport(const tlm::tlm_request<int,int>& request) {

  tlm::tlm_response<int> response;
  int address = request.get_address();
  int block_size = request.get_block_size();
  unsigned int byte_enable_period = request.get_byte_enable_period();

  if ( (address +  (int)(block_size*tlm::get_nb_byte<int>()-1)) >= m_memory_size ) {
    std::cout << std::showbase << std::hex;
    std::cout << "Slave has received a request with input address out of range, start: " 
	      << address << " end: " << (address +  block_size*tlm::get_nb_byte<int>()-1)
	      << std::endl;
    return(response);
  }

  switch(request.get_command()) {
    
  case tlm::READ:
    
    for(int i = 0;i < block_size;i++) {
      response.set_data(this->read(address,request.get_byte_enable(byte_enable_period?i%byte_enable_period:i)),i);
      if (request.get_block_mode() == tlm::INCREMENT) address += request.get_block_address_incr();
    }
    response.get_status().set_ok();
    break;

  case tlm::WRITE:	

    for(int i = 0;i < block_size;i++) {
      this->write(address,request.get_data(i),request.get_byte_enable(byte_enable_period?i%byte_enable_period:i));
      if (request.get_block_mode() == tlm::INCREMENT) address += request.get_block_address_incr();
    }
    response.get_status().set_ok();
    break;
  
  default:
    std::cout << "Slave has received an unknown tlm_command type" <<  std::endl;
    break;
  }
  
  return(response);
}


/* END of slave.cpp */
