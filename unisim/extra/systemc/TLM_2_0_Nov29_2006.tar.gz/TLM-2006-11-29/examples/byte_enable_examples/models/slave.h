/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2004 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.4 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/
#ifndef _SLAVE_H_
#define _SLAVE_H_

#include <sstream>

#include "systemc.h"

#include "tlm.h"


//-----------------------------------------------------------------------------------
class slave : 
  public sc_module,
  public tlm::tlm_transport_if<tlm::tlm_request<int,int>,
			       tlm::tlm_response<int> > {
public:
  tlm::tlm_target_port<tlm::tlm_transport_if<tlm::tlm_request<int,int>,
					     tlm::tlm_response<int> > > target_port;

  slave(sc_module_name module_name,
	tlm::tlm_endianness endian = TLM_HOST_ENDIAN);

  ~slave();
  
  tlm::tlm_response<int> transport(const tlm::tlm_request<int,int>& request);


protected:

  static const int m_memory_size;

  tlm::tlm_endianness m_endian;

  int * m_memory;

  int read(int address,unsigned int byte_enable);
  void write(int address,int data,unsigned int byte_enable);

  
};


#endif /* _SLAVE_H_ */


